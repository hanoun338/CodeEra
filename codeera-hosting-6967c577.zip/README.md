# CodeEra: website + Admin Dashboard (ordinary hosting version)

This runs on normal web hosting with a normal domain (cPanel, Hostinger, Namecheap, GoDaddy, Bluehost, etc.).
You do NOT need Node, a command line, or your own server. It needs PHP 8.0 or newer with SQLite, which almost every host has by default.

## Upload (about 5 minutes)
1. In your host control panel, open **Select PHP Version** (or MultiPHP Manager) and pick PHP 8.1 or newer for your domain. Make sure `pdo_sqlite` is ticked (it usually is).
2. Open **File Manager**, go to the folder of your domain (usually `public_html`).
3. Upload `codeera-hosting.zip` there and click **Extract**. Move everything so that `index.php`, `app.html`, `.htaccess`, `api/`, `assets/` and `uploads/` sit directly inside `public_html` (not inside another folder). Turn on "Show hidden files" so you can see `.htaccess`.
4. Open `https://yourdomain.com/admin`. First time only, you see a setup screen: choose your own username and password (10+ characters). That account is the Super Admin. Nothing is preset.
5. In **General Settings** set your WhatsApp number, email and logo. In **Websites** set your real prices.

Turn on the free SSL certificate in your host panel (AutoSSL / Let's Encrypt). After it works, open `.htaccess` and remove the `#` from the three lines under "force https".

## Where the data lives (important)
- Database: a folder named `codeera-data`, created next to `public_html` (outside the public web folder). If the host does not allow that, it uses `api/data` (protected by `.htaccess`).
- Uploaded images: `public_html/uploads`.
- **Back up both** now and then (download them from File Manager).

## Rules this version follows
- Passwords are hashed. Login uses a protected session cookie, CSRF protection and a limit on wrong attempts.
- Roles are enforced on the server: Super Admin, Admin, Editor, Order Manager (edit them in Users & Permissions).
- The database file is never reachable from a browser on Apache/LiteSpeed. On an Nginx-only host, `.htaccess` is ignored: keep the data folder outside the web folder and add these rules to the server config:
      location ~ ^/(api/(?!index\.php)|app\.html) { return 404; }
      location /uploads/ { location ~ \.php$ { return 404; } }
      location / { try_files $uri /index.php?$query_string; }
      location /api/ { try_files $uri /api/index.php?$query_string; }

## What is real
- 16 dashboard sections with real create / edit / delete, saved in SQLite.
- Orders and contact messages from the public site appear in the dashboard. Analytics come from real orders.
- Admin changes (websites, homepage text, colors, SEO, settings) show on the public site.
- CSV exports, image upload (PNG, JPG, WebP, GIF, ICO, 5 MB), activity log, robots.txt and sitemap.xml.

## Limits
- No payment gateway. You confirm payments by hand in Orders.
- No automatic email or WhatsApp sending. Replies are only recorded in the dashboard. The SMTP fields are stored but not used yet.
- Arabic (RTL) covers navigation, titles and common labels. Some text is still English.
- Only "Akl Baity" is a real product. The other sample websites are concept demos with placeholder prices. Edit them in Websites.
- It must sit at the root of a domain or subdomain (not in a sub-folder like `/shop/`).

## Changing the design later
`source-web/` holds the React source of the site and dashboard (needs Node only if you want to edit it: `npm install`, `npm run build`, then copy `dist/assets` to `assets/` and `dist/index.html` to `app.html`).
