<?php
// All /api/admin routes. Every route requires a signed-in user; writes also need the CSRF header; each route checks a permission.
declare(strict_types=1);

class Resp { public function __construct(public $data, public int $status = 200, public ?string $csv = null, public ?string $file = null) {} }
function created($d): Resp { return new Resp($d, 201); }
function csvResp(string $csv, string $name): Resp { return new Resp(null, 200, $csv, $name); }

const ORDER_STATUSES = ['new', 'pending_confirmation', 'awaiting_payment', 'processing', 'completed', 'cancelled', 'refunded'];
const PAY_STATUSES = ['unpaid', 'pending', 'paid', 'failed', 'refunded'];
const PRODUCT_JSON = ['gallery', 'features', 'technologies', 'tags', 'pages', 'customization', 'included', 'faq'];
const REVENUE = "o.payment_status = 'paid' AND o.status NOT IN ('cancelled','refunded')";

function adminRoutes(): Router {
  $r = new Router();
  $can = fn(array $c, string $a) => in_array($a . '.view', $c['perms'], true);

  $r->add('GET', '/me', fn($p, $c) => ['user' => $c['user'], 'permissions' => $c['perms'], 'csrf' => $c['csrf']]);

  // ---- overview
  $r->add('GET', '/overview', function ($p, $c) use ($can) {
    $out = ['can' => (object) []];
    if ($can($c, 'products')) {
      $out['products'] = ['total' => (int) val_('SELECT COUNT(*) FROM products'), 'published' => (int) val_("SELECT COUNT(*) FROM products WHERE status='published'"), 'draft' => (int) val_("SELECT COUNT(*) FROM products WHERE status='draft'")];
      $out['mostViewed'] = all_('SELECT p.id,p.name,SUM(v.count) views FROM views v JOIN products p ON p.id=v.product_id GROUP BY p.id ORDER BY views DESC LIMIT 5');
    }
    if ($can($c, 'orders')) {
      $out['orders'] = ['total' => (int) val_('SELECT COUNT(*) FROM orders'), 'pending' => (int) val_("SELECT COUNT(*) FROM orders WHERE status IN ('new','pending_confirmation','awaiting_payment')")];
      $out['recentOrders'] = all_('SELECT o.id,o.code,o.product_name,o.amount,o.status,o.payment_status,o.created_at,c.name customer FROM orders o LEFT JOIN customers c ON c.id=o.customer_id ORDER BY o.created_at DESC LIMIT 6');
      $out['bestSelling'] = all_('SELECT product_name name, COUNT(*) sales, SUM(amount) revenue FROM orders o WHERE ' . REVENUE . ' GROUP BY product_name ORDER BY sales DESC, revenue DESC LIMIT 5');
    }
    if ($can($c, 'analytics') || $can($c, 'orders')) {
      $out['revenue'] = val_('SELECT COALESCE(SUM(amount),0) FROM orders o WHERE ' . REVENUE) + 0;
      $out['sales'] = (int) val_('SELECT COUNT(*) FROM orders o WHERE ' . REVENUE);
      $visits = (int) val_('SELECT COALESCE(SUM(count),0) FROM views WHERE product_id = 0'); $ordersAll = (int) val_('SELECT COUNT(*) FROM orders');
      $out['views'] = $visits; $out['conversion'] = $visits ? round($ordersAll / $visits * 1000) / 10 : 0;
      $since = gmdate('Y-m-d', time() - 29 * 86400);
      $map = []; foreach (all_('SELECT substr(created_at,1,10) d, SUM(amount) revenue, COUNT(*) orders FROM orders o WHERE ' . REVENUE . ' AND substr(created_at,1,10) >= ? GROUP BY d', [$since]) as $x) $map[$x['d']] = $x;
      $chart = []; for ($i = 0; $i < 30; $i++) { $d = gmdate('Y-m-d', time() - (29 - $i) * 86400); $chart[] = ['date' => $d, 'revenue' => isset($map[$d]) ? $map[$d]['revenue'] + 0 : 0, 'orders' => isset($map[$d]) ? (int) $map[$d]['orders'] : 0]; }
      $out['chart'] = $chart;
    }
    if ($can($c, 'customers')) $out['customers'] = (int) val_('SELECT COUNT(*) FROM customers');
    if ($can($c, 'logs')) $out['activity'] = all_('SELECT * FROM activity ORDER BY id DESC LIMIT 8');
    $out['badges'] = badges();
    return $out;
  });
  $r->add('GET', '/badges', fn() => badges());
  $r->add('GET', '/search', function ($p, $c) use ($can) {
    $qs = trim((string) qget('q')); if (mb_strlen($qs) < 2) return ['results' => []];
    $like = "%$qs%"; $res = [];
    if ($can($c, 'products')) foreach (all_('SELECT id,name FROM products WHERE name LIKE ? OR slug LIKE ? LIMIT 5', [$like, $like]) as $x) $res[] = ['type' => 'products', 'id' => $x['id'], 'title' => $x['name']];
    if ($can($c, 'orders')) foreach (all_('SELECT id,code,product_name FROM orders WHERE code LIKE ? OR product_name LIKE ? LIMIT 5', [$like, $like]) as $x) $res[] = ['type' => 'orders', 'id' => $x['id'], 'title' => $x['code'], 'sub' => $x['product_name']];
    if ($can($c, 'customers')) foreach (all_('SELECT id,name,email FROM customers WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? LIMIT 5', [$like, $like, $like]) as $x) $res[] = ['type' => 'customers', 'id' => $x['id'], 'title' => $x['name'], 'sub' => $x['email']];
    if ($can($c, 'messages')) foreach (all_('SELECT id,name,subject FROM messages WHERE name LIKE ? OR subject LIKE ? OR body LIKE ? LIMIT 5', [$like, $like, $like]) as $x) $res[] = ['type' => 'messages', 'id' => $x['id'], 'title' => $x['subject'] ?: $x['name'], 'sub' => $x['name']];
    return ['results' => $res];
  });

  // ---- categories
  $catBody = function (array $b, int $id = 0) {
    return ['name' => vstr($b['name'] ?? null, ['required' => true, 'max' => 80, 'label' => 'Name']), 'name_ar' => vstr($b['name_ar'] ?? null, ['max' => 80]), 'description' => vstr($b['description'] ?? null, ['max' => 400]),
      'icon' => vstr($b['icon'] ?? null, ['max' => 30]) ?: 'code', 'sort' => vnum($b['sort'] ?? 0, ['min' => 0, 'max' => 9999, 'label' => 'Order']), 'visible' => vbool($b['visible'] ?? 0),
      'slug' => uniqueSlug('categories', vstr($b['slug'] ?? null) ?: (string) ($b['name'] ?? ''), $id)];
  };
  $r->add('GET', '/categories', function () { return array_map(fn($x) => $x + [], array_map(function ($x) { $x['visible'] = !empty($x['visible']); return $x; }, all_('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) website_count FROM categories c ORDER BY sort, id'))); }, 'categories.view');
  $r->add('POST', '/categories', function ($p, $c) use ($catBody) { $v = $catBody(bodyIn()); $id = run_('INSERT INTO categories(name,name_ar,slug,description,icon,sort,visible) VALUES(?,?,?,?,?,?,?)', [$v['name'], $v['name_ar'], $v['slug'], $v['description'], $v['icon'], $v['sort'], $v['visible']]); logAct($c['user'], 'category.created', 'category', $id, $v['name']); return created(['id' => $id]); }, 'categories.edit');
  $r->add('PUT', '/categories/:id', function ($p, $c) use ($catBody) { $id = (int) $p['id']; if (!val_('SELECT id FROM categories WHERE id=?', [$id])) throw notFound(); $v = $catBody(bodyIn(), $id); run_('UPDATE categories SET name=?,name_ar=?,slug=?,description=?,icon=?,sort=?,visible=? WHERE id=?', [$v['name'], $v['name_ar'], $v['slug'], $v['description'], $v['icon'], $v['sort'], $v['visible'], $id]); logAct($c['user'], 'category.updated', 'category', $id, $v['name']); return ['ok' => true]; }, 'categories.edit');
  $r->add('DELETE', '/categories/:id', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT name FROM categories WHERE id=?', [$id]); if ($n === null) throw notFound(); run_('DELETE FROM categories WHERE id=?', [$id]); logAct($c['user'], 'category.deleted', 'category', $id, $n); return ['ok' => true]; }, 'categories.edit');

  // ---- products
  $productBody = function (array $b, int $id = 0) {
    $price = vnum($b['price'] ?? null, ['min' => 0, 'max' => 1e7, 'label' => 'Price', 'required' => true]);
    $dp = vnum($b['discount_price'] ?? null, ['min' => 0, 'max' => 1e7, 'label' => 'Sale price', 'nullable' => true]);
    if ($dp !== null && $dp >= $price) throw bad('Sale price must be lower than the price.');
    $name = vstr($b['name'] ?? null, ['required' => true, 'max' => 120, 'label' => 'Name']);
    $faq = []; if (isset($b['faq']) && is_array($b['faq'])) foreach (array_slice($b['faq'], 0, 20) as $f) { $qq = vstr($f['q'] ?? null, ['max' => 200]); if ($qq !== '') $faq[] = ['q' => $qq, 'a' => vstr($f['a'] ?? null, ['max' => 800])]; }
    return ['name' => $name, 'slug' => uniqueSlug('products', vstr($b['slug'] ?? null) ?: $name, $id), 'category_id' => !empty($b['category_id']) ? (int) $b['category_id'] : null,
      'short_desc' => vstr($b['short_desc'] ?? null, ['max' => 300]), 'full_desc' => vstr($b['full_desc'] ?? null, ['max' => 8000]), 'price' => $price, 'discount_price' => $dp,
      'thumbnail' => vurl($b['thumbnail'] ?? null, 'Thumbnail') ?: null, 'gallery' => jenc(vlist($b['gallery'] ?? null, 12, 500)), 'demo_url' => vurl($b['demo_url'] ?? null, 'Demo URL') ?: null,
      'purchase_type' => voneOf(($b['purchase_type'] ?? '') ?: 'license', ['license', 'customization', 'source', 'subscription'], 'Purchase type'),
      'features' => jenc(vlist($b['features'] ?? null)), 'technologies' => jenc(vlist($b['technologies'] ?? null, 30, 60)), 'tags' => jenc(vlist($b['tags'] ?? null, 30, 40)),
      'pages' => jenc(vlist($b['pages'] ?? null)), 'customization' => jenc(vlist($b['customization'] ?? null)), 'included' => jenc(vlist($b['included'] ?? null)), 'faq' => jenc($faq),
      'status' => voneOf(($b['status'] ?? '') ?: 'draft', ['draft', 'published'], 'Status'), 'featured' => vbool($b['featured'] ?? 0),
      'availability' => voneOf(($b['availability'] ?? '') ?: 'available', ['available', 'sold_out', 'coming_soon'], 'Availability'), 'visibility' => voneOf(($b['visibility'] ?? '') ?: 'public', ['public', 'hidden'], 'Visibility'),
      'seo_title' => vstr($b['seo_title'] ?? null, ['max' => 120]), 'seo_desc' => vstr($b['seo_desc'] ?? null, ['max' => 300]),
      'accent' => vstr($b['accent'] ?? null, ['max' => 20]) ?: null, 'hue' => vstr($b['hue'] ?? null, ['max' => 20]) ?: null, 'kind' => vstr($b['kind'] ?? null, ['max' => 30]) ?: null,
      'concept' => vbool($b['concept'] ?? 0), 'sort' => vnum($b['sort'] ?? 0, ['min' => 0, 'max' => 9999])];
  };
  $r->add('GET', '/products', function () {
    $extra = []; $params = [];
    if (qget('featured') === '1') $extra[] = 'p.featured = 1';
    if (qget('category') !== '' && qget('category') !== 'all') { $extra[] = 'p.category_id = ?'; $params[] = (int) qget('category'); }
    return paged(['select' => 'p.*, c.name category_name, COALESCE((SELECT SUM(count) FROM views v WHERE v.product_id=p.id),0) views, (SELECT COUNT(*) FROM orders o WHERE o.product_id=p.id) orders_count',
      'from' => 'products p LEFT JOIN categories c ON c.id=p.category_id', 'searchCols' => ['p.name', 'p.slug', 'p.short_desc', 'p.tags'],
      'filters' => ['status' => 'p.status', 'availability' => 'p.availability', 'visibility' => 'p.visibility'],
      'sorts' => ['created' => 'p.created_at', 'name' => 'p.name', 'price' => 'p.price', 'status' => 'p.status', 'updated' => 'p.updated_at', 'views' => 'views'], 'defaultSort' => 'created', 'where' => $extra, 'params' => $params, 'json' => PRODUCT_JSON, 'bools' => ['featured', 'concept']]);
  }, 'products.view');
  $r->add('GET', '/products/:id', function ($p) { $x = one_('SELECT * FROM products WHERE id=?', [(int) $p['id']]); if (!$x) throw notFound(); return parseRow($x, PRODUCT_JSON, ['featured', 'concept']); }, 'products.view');
  $r->add('POST', '/products/bulk', function ($p, $c) {
    $b = bodyIn(); $ids = array_slice(array_values(array_filter(array_map('intval', is_array($b['ids'] ?? null) ? $b['ids'] : []))), 0, 200);
    $action = voneOf($b['action'] ?? null, ['publish', 'unpublish', 'feature', 'unfeature', 'delete'], 'Action');
    if (!$ids) throw bad('Select at least one website.');
    tx(function () use ($ids, $action) { foreach ($ids as $id) {
      if ($action === 'delete') run_('DELETE FROM products WHERE id=?', [$id]);
      elseif ($action === 'publish') run_("UPDATE products SET status='published',updated_at=? WHERE id=?", [now_(), $id]);
      elseif ($action === 'unpublish') run_("UPDATE products SET status='draft',updated_at=? WHERE id=?", [now_(), $id]);
      else run_('UPDATE products SET featured=?,updated_at=? WHERE id=?', [$action === 'feature' ? 1 : 0, now_(), $id]);
    } });
    logAct($c['user'], 'product.bulk_' . $action, 'product', implode(',', $ids), count($ids) . ' website(s)'); return ['ok' => true, 'count' => count($ids)];
  }, 'products.edit');
  $r->add('POST', '/products', function ($p, $c) use ($productBody) {
    $v = $productBody(bodyIn()); $t = now_(); $cols = array_keys($v);
    $id = run_('INSERT INTO products(' . implode(',', $cols) . ',created_at,updated_at) VALUES(' . implode(',', array_fill(0, count($cols), '?')) . ',?,?)', array_merge(array_values($v), [$t, $t]));
    logAct($c['user'], 'product.created', 'product', $id, $v['name']); return created(['id' => $id]);
  }, 'products.edit');
  $r->add('PUT', '/products/:id', function ($p, $c) use ($productBody) {
    $id = (int) $p['id']; $old = one_('SELECT * FROM products WHERE id=?', [$id]); if (!$old) throw notFound();
    $v = $productBody(bodyIn(), $id);
    run_('UPDATE products SET ' . implode(',', array_map(fn($k) => "$k=?", array_keys($v))) . ',updated_at=? WHERE id=?', array_merge(array_values($v), [now_(), $id]));
    logAct($c['user'], 'product.updated', 'product', $id, $v['name'] . ($old['status'] !== $v['status'] ? " ({$old['status']} → {$v['status']})" : '')); return ['ok' => true];
  }, 'products.edit');
  $r->add('POST', '/products/:id/duplicate', function ($p, $c) {
    $x = one_('SELECT * FROM products WHERE id=?', [(int) $p['id']]); if (!$x) throw notFound(); $t = now_();
    unset($x['id']); $x['name'] .= ' (copy)'; $x['slug'] = uniqueSlug('products', $x['name']); $x['status'] = 'draft'; $x['featured'] = 0; $x['created_at'] = $x['updated_at'] = $t;
    $cols = array_keys($x); $id = run_('INSERT INTO products(' . implode(',', $cols) . ') VALUES(' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($x));
    logAct($c['user'], 'product.duplicated', 'product', $id, 'from ' . $x['name']); return created(['id' => $id]);
  }, 'products.edit');
  $r->add('DELETE', '/products/:id', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT name FROM products WHERE id=?', [$id]); if ($n === null) throw notFound(); run_('DELETE FROM products WHERE id=?', [$id]); logAct($c['user'], 'product.deleted', 'product', $id, $n); return ['ok' => true]; }, 'products.edit');
  $r->add('GET', '/export/products.csv', fn() => csvResp(toCsv(all_('SELECT p.*, c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id'), ['name', 'slug', 'category', 'price', 'discount_price', 'status', 'featured', 'demo_url', 'created_at']), 'websites.csv'), 'products.view');

  // ---- customers
  $custStats = 'c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id=c.id) orders_count, (SELECT COALESCE(SUM(amount),0) FROM orders o WHERE o.customer_id=c.id AND ' . REVENUE . ') total_spent';
  $r->add('GET', '/customers', fn() => paged(['select' => $custStats, 'from' => 'customers c', 'searchCols' => ['c.name', 'c.email', 'c.phone'], 'sorts' => ['created' => 'c.created_at', 'name' => 'c.name', 'orders' => 'orders_count', 'spent' => 'total_spent'], 'defaultSort' => 'created']), 'customers.view');
  $r->add('GET', '/customers/:id', function ($p) use ($custStats) {
    $x = one_("SELECT $custStats FROM customers c WHERE c.id=?", [(int) $p['id']]); if (!$x) throw notFound();
    $x['orders'] = all_('SELECT id,code,product_name,amount,status,payment_status,created_at FROM orders WHERE customer_id=? ORDER BY created_at DESC', [$x['id']]);
    $x['messages'] = all_("SELECT id,subject,type,created_at FROM messages WHERE email = ? AND email != '' ORDER BY created_at DESC LIMIT 10", [$x['email'] ?? '']);
    return $x;
  }, 'customers.view');
  $custBody = fn(array $b) => ['name' => vstr($b['name'] ?? null, ['required' => true, 'max' => 100, 'label' => 'Name']), 'email' => vemail($b['email'] ?? null), 'phone' => vstr($b['phone'] ?? null, ['max' => 40]), 'notes' => vstr($b['notes'] ?? null, ['max' => 3000])];
  $r->add('POST', '/customers', function ($p, $c) use ($custBody) { $v = $custBody(bodyIn()); $t = now_(); $id = run_('INSERT INTO customers(name,email,phone,notes,created_at,last_activity) VALUES(?,?,?,?,?,?)', [$v['name'], $v['email'], $v['phone'], $v['notes'], $t, $t]); logAct($c['user'], 'customer.created', 'customer', $id, $v['name']); return created(['id' => $id]); }, 'customers.edit');
  $r->add('PUT', '/customers/:id', function ($p, $c) use ($custBody) { $id = (int) $p['id']; if (!val_('SELECT id FROM customers WHERE id=?', [$id])) throw notFound(); $v = $custBody(bodyIn()); run_('UPDATE customers SET name=?,email=?,phone=?,notes=? WHERE id=?', [$v['name'], $v['email'], $v['phone'], $v['notes'], $id]); logAct($c['user'], 'customer.updated', 'customer', $id, $v['name']); return ['ok' => true]; }, 'customers.edit');
  $r->add('DELETE', '/customers/:id', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT name FROM customers WHERE id=?', [$id]); if ($n === null) throw notFound(); run_('DELETE FROM customers WHERE id=?', [$id]); logAct($c['user'], 'customer.deleted', 'customer', $id, $n); return ['ok' => true]; }, 'customers.edit');
  $r->add('GET', '/export/customers.csv', fn() => csvResp(toCsv(all_("SELECT $custStats FROM customers c ORDER BY c.id"), ['name', 'email', 'phone', 'orders_count', 'total_spent', 'created_at']), 'customers.csv'), 'customers.view');

  // ---- orders
  $r->add('GET', '/orders', function () {
    $w = []; $pr = [];
    if (qget('from') !== '') { $w[] = 'substr(o.created_at,1,10) >= ?'; $pr[] = substr((string) qget('from'), 0, 10); }
    if (qget('to') !== '') { $w[] = 'substr(o.created_at,1,10) <= ?'; $pr[] = substr((string) qget('to'), 0, 10); }
    return paged(['select' => 'o.*, c.name customer_name, c.email customer_email, c.phone customer_phone', 'from' => 'orders o LEFT JOIN customers c ON c.id=o.customer_id', 'searchCols' => ['o.code', 'o.product_name', 'c.name', 'c.email'],
      'filters' => ['status' => 'o.status', 'payment_status' => 'o.payment_status', 'payment_method' => 'o.payment_method'], 'sorts' => ['created' => 'o.created_at', 'amount' => 'o.amount', 'status' => 'o.status', 'code' => 'o.code'], 'defaultSort' => 'created', 'where' => $w, 'params' => $pr, 'json' => ['notes', 'history']]);
  }, 'orders.view');
  $r->add('GET', '/orders/:id', function ($p) { $o = one_('SELECT o.*, c.name customer_name, c.email customer_email, c.phone customer_phone FROM orders o LEFT JOIN customers c ON c.id=o.customer_id WHERE o.id=?', [(int) $p['id']]); if (!$o) throw notFound(); return parseRow($o, ['notes', 'history']); }, 'orders.view');
  $r->add('POST', '/orders', function ($p, $c) {
    $b = bodyIn(); $pr = one_('SELECT * FROM products WHERE id=?', [(int) ($b['product_id'] ?? 0)]); if (!$pr) throw bad('Choose a website.');
    $cname = vstr($b['customer_name'] ?? null, ['required' => true, 'max' => 100, 'label' => 'Customer name']); $cemail = vemail($b['customer_email'] ?? null);
    $amount = (!isset($b['amount']) || $b['amount'] === '') ? ($pr['discount_price'] ?? $pr['price']) : vnum($b['amount'], ['min' => 0, 'label' => 'Amount']); $t = now_();
    $out = tx(function () use ($b, $pr, $cname, $cemail, $amount, $t, $c) {
      $cid = $cemail ? val_('SELECT id FROM customers WHERE email=?', [$cemail]) : null;
      if (!$cid) $cid = run_('INSERT INTO customers(name,email,phone,created_at,last_activity) VALUES(?,?,?,?,?)', [$cname, $cemail, vstr($b['customer_phone'] ?? null, ['max' => 40]), $t, $t]);
      $code = newOrderCode();
      $id = run_("INSERT INTO orders(code,customer_id,product_id,product_name,category_id,purchase_type,amount,payment_method,customization,history,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        [$code, $cid, $pr['id'], $pr['name'], $pr['category_id'], $pr['purchase_type'], $amount, vstr($b['payment_method'] ?? null, ['max' => 40]) ?: null, vstr($b['customization'] ?? null, ['max' => 3000]), jenc([['at' => $t, 'by' => $c['user']['username'], 'text' => 'Order created by admin']]), $t, $t]);
      return ['id' => $id, 'code' => $code];
    });
    logAct($c['user'], 'order.created', 'order', $out['id'], $out['code']); return created($out);
  }, 'orders.edit');
  $r->add('PUT', '/orders/:id', function ($p, $c) {
    $id = (int) $p['id']; $o = one_('SELECT * FROM orders WHERE id=?', [$id]); if (!$o) throw notFound(); $b = bodyIn();
    $hist = jdec($o['history'], []); $changes = [];
    $status = array_key_exists('status', $b) ? voneOf($b['status'], ORDER_STATUSES, 'Status') : $o['status'];
    $pay = array_key_exists('payment_status', $b) ? voneOf($b['payment_status'], PAY_STATUSES, 'Payment status') : $o['payment_status'];
    if ($status !== $o['status']) { $hist[] = ['at' => now_(), 'by' => $c['user']['username'], 'text' => "Status: {$o['status']} → $status"]; $changes[] = "status {$o['status']} → $status"; }
    if ($pay !== $o['payment_status']) { $hist[] = ['at' => now_(), 'by' => $c['user']['username'], 'text' => "Payment: {$o['payment_status']} → $pay" . ($pay === 'paid' ? ' (confirmed by admin)' : '')]; $changes[] = "payment {$o['payment_status']} → $pay"; }
    $method = array_key_exists('payment_method', $b) ? (vstr($b['payment_method'], ['max' => 40]) ?: null) : $o['payment_method'];
    run_('UPDATE orders SET status=?,payment_status=?,payment_method=?,history=?,updated_at=? WHERE id=?', [$status, $pay, $method, jenc($hist), now_(), $id]);
    if ($changes) logAct($c['user'], 'order.updated', 'order', $o['code'], implode('; ', $changes));
    return ['ok' => true];
  }, 'orders.edit');
  $r->add('POST', '/orders/:id/notes', function ($p, $c) {
    $id = (int) $p['id']; $o = one_('SELECT * FROM orders WHERE id=?', [$id]); if (!$o) throw notFound();
    $text = vstr(bodyIn()['text'] ?? null, ['required' => true, 'max' => 2000, 'label' => 'Note']); $notes = jdec($o['notes'], []); $notes[] = ['at' => now_(), 'by' => $c['user']['username'], 'text' => $text];
    run_('UPDATE orders SET notes=?,updated_at=? WHERE id=?', [jenc($notes), now_(), $id]); logAct($c['user'], 'order.note_added', 'order', $o['code'], ''); return created(['ok' => true]);
  }, 'orders.edit');
  $r->add('DELETE', '/orders/:id', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT code FROM orders WHERE id=?', [$id]); if ($n === null) throw notFound(); run_('DELETE FROM orders WHERE id=?', [$id]); logAct($c['user'], 'order.deleted', 'order', $n, ''); return ['ok' => true]; }, 'orders.edit');
  $r->add('GET', '/export/orders.csv', fn() => csvResp(toCsv(all_('SELECT o.*, c.name customer, c.email email FROM orders o LEFT JOIN customers c ON c.id=o.customer_id ORDER BY o.created_at DESC'), ['code', 'customer', 'email', 'product_name', 'amount', 'discount', 'coupon_code', 'payment_method', 'payment_status', 'status', 'created_at']), 'orders.csv'), 'orders.view');

  // ---- analytics
  $r->add('GET', '/analytics', function () {
    $re = '/^\d{4}-\d{2}-\d{2}$/'; $to = preg_match($re, (string) qget('to')) ? (string) qget('to') : gmdate('Y-m-d'); $from = preg_match($re, (string) qget('from')) ? (string) qget('from') : gmdate('Y-m-d', time() - 29 * 86400);
    $day = 86400; $days = max(1, (int) round((strtotime($to) - strtotime($from)) / $day) + 1); if ($days > 732) throw bad('Date range is too long.');
    $prevTo = gmdate('Y-m-d', strtotime($from) - $day); $prevFrom = gmdate('Y-m-d', strtotime($from) - $days * $day);
    $series = function (string $a, string $b) use ($days, $day) {
      $m = []; foreach (all_('SELECT substr(o.created_at,1,10) d, COUNT(*) orders, SUM(CASE WHEN ' . REVENUE . ' THEN o.amount ELSE 0 END) revenue FROM orders o WHERE substr(o.created_at,1,10) BETWEEN ? AND ? GROUP BY d', [$a, $b]) as $x) $m[$x['d']] = $x;
      $o = []; for ($i = 0; $i < $days; $i++) { $d = gmdate('Y-m-d', strtotime($a) + $i * $day); $o[] = ['date' => $d, 'orders' => isset($m[$d]) ? (int) $m[$d]['orders'] : 0, 'revenue' => isset($m[$d]) ? $m[$d]['revenue'] + 0 : 0]; } return $o;
    };
    $cur = $series($from, $to); $prev = $series($prevFrom, $prevTo); $sum = fn($s, $k) => array_sum(array_column($s, $k));
    $acq = []; foreach (all_('SELECT substr(created_at,1,10) d, COUNT(*) n FROM customers WHERE substr(created_at,1,10) BETWEEN ? AND ? GROUP BY d', [$from, $to]) as $x) $acq[$x['d']] = (int) $x['n'];
    $visits = (int) val_('SELECT COALESCE(SUM(count),0) FROM views WHERE product_id=0 AND day BETWEEN ? AND ?', [$from, $to]); $ordersN = $sum($cur, 'orders');
    return ['from' => $from, 'to' => $to, 'days' => $days, 'series' => $cur, 'previous' => $prev,
      'totals' => ['revenue' => $sum($cur, 'revenue'), 'orders' => $ordersN, 'previousRevenue' => $sum($prev, 'revenue'), 'previousOrders' => $sum($prev, 'orders'), 'visits' => $visits, 'conversion' => $visits ? round($ordersN / $visits * 1000) / 10 : 0],
      'ranking' => all_('SELECT o.product_name name, COUNT(*) sales, SUM(o.amount) revenue FROM orders o WHERE ' . REVENUE . ' AND substr(o.created_at,1,10) BETWEEN ? AND ? GROUP BY o.product_name ORDER BY revenue DESC LIMIT 10', [$from, $to]),
      'byCategory' => all_("SELECT COALESCE(c.name,'Uncategorised') name, SUM(o.amount) revenue, COUNT(*) sales FROM orders o LEFT JOIN categories c ON c.id=o.category_id WHERE " . REVENUE . ' AND substr(o.created_at,1,10) BETWEEN ? AND ? GROUP BY name ORDER BY revenue DESC', [$from, $to]),
      'mostViewed' => all_('SELECT p.name, SUM(v.count) views FROM views v JOIN products p ON p.id=v.product_id WHERE v.day BETWEEN ? AND ? GROUP BY p.id ORDER BY views DESC LIMIT 10', [$from, $to]),
      'customers' => array_map(fn($x) => ['date' => $x['date'], 'customers' => $acq[$x['date']] ?? 0], $cur)];
  }, 'analytics.view');
  $r->add('GET', '/export/analytics.csv', function () {
    $from = substr((string) (qget('from') ?: '2000-01-01'), 0, 10); $to = substr((string) (qget('to') ?: '2999-01-01'), 0, 10);
    return csvResp(toCsv(all_('SELECT substr(o.created_at,1,10) date, COUNT(*) orders, SUM(CASE WHEN ' . REVENUE . ' THEN o.amount ELSE 0 END) revenue FROM orders o WHERE substr(o.created_at,1,10) BETWEEN ? AND ? GROUP BY date ORDER BY date', [$from, $to]), ['date', 'orders', 'revenue']), 'sales-report.csv');
  }, 'analytics.view');

  // ---- coupons
  $couponBody = function (array $b, int $id = 0) {
    $type = voneOf($b['type'] ?? null, ['percent', 'fixed'], 'Type'); $value = vnum($b['value'] ?? null, ['min' => 0.01, 'max' => $type === 'percent' ? 100 : 1e7, 'label' => 'Value', 'required' => true]);
    $code = preg_replace('/[^A-Z0-9_-]/', '', strtoupper(vstr($b['code'] ?? null, ['required' => true, 'max' => 40, 'label' => 'Code']))); if ($code === '') throw bad('Code may contain letters, numbers, - and _.');
    if (val_('SELECT id FROM coupons WHERE code=? AND id != ?', [$code, $id])) throw bad('A coupon with this code already exists.');
    return ['code' => $code, 'type' => $type, 'value' => $value, 'expires_at' => vstr($b['expires_at'] ?? null, ['max' => 30]) ?: null,
      'usage_limit' => (!isset($b['usage_limit']) || $b['usage_limit'] === '') ? null : vnum($b['usage_limit'], ['min' => 1, 'max' => 1e7, 'label' => 'Usage limit']),
      'min_purchase' => vnum($b['min_purchase'] ?? 0, ['min' => 0, 'label' => 'Minimum purchase']), 'product_ids' => jenc(array_values(array_filter(array_map('intval', is_array($b['product_ids'] ?? null) ? $b['product_ids'] : [])))), 'active' => vbool($b['active'] ?? 0)];
  };
  $r->add('GET', '/coupons', fn() => paged(['select' => "c.*, (SELECT COALESCE(SUM(discount),0) FROM orders o WHERE o.coupon_code=c.code AND o.status NOT IN ('cancelled','refunded')) discount_given, (SELECT COALESCE(SUM(amount),0) FROM orders o WHERE o.coupon_code=c.code AND " . REVENUE . ') revenue', 'from' => 'coupons c', 'searchCols' => ['c.code'], 'sorts' => ['created' => 'c.created_at', 'used' => 'c.used', 'code' => 'c.code'], 'defaultSort' => 'created', 'json' => ['product_ids'], 'bools' => ['active']]), 'coupons.view');
  $r->add('POST', '/coupons', function ($p, $c) use ($couponBody) { $v = $couponBody(bodyIn()); $id = run_('INSERT INTO coupons(code,type,value,expires_at,usage_limit,min_purchase,product_ids,active,created_at) VALUES(?,?,?,?,?,?,?,?,?)', [$v['code'], $v['type'], $v['value'], $v['expires_at'], $v['usage_limit'], $v['min_purchase'], $v['product_ids'], $v['active'], now_()]); logAct($c['user'], 'coupon.created', 'coupon', $id, $v['code']); return created(['id' => $id]); }, 'coupons.edit');
  $r->add('PUT', '/coupons/:id', function ($p, $c) use ($couponBody) { $id = (int) $p['id']; if (!val_('SELECT id FROM coupons WHERE id=?', [$id])) throw notFound(); $v = $couponBody(bodyIn(), $id); run_('UPDATE coupons SET code=?,type=?,value=?,expires_at=?,usage_limit=?,min_purchase=?,product_ids=?,active=? WHERE id=?', [$v['code'], $v['type'], $v['value'], $v['expires_at'], $v['usage_limit'], $v['min_purchase'], $v['product_ids'], $v['active'], $id]); logAct($c['user'], 'coupon.updated', 'coupon', $id, $v['code']); return ['ok' => true]; }, 'coupons.edit');
  $r->add('DELETE', '/coupons/:id', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT code FROM coupons WHERE id=?', [$id]); if ($n === null) throw notFound(); run_('DELETE FROM coupons WHERE id=?', [$id]); logAct($c['user'], 'coupon.deleted', 'coupon', $id, $n); return ['ok' => true]; }, 'coupons.edit');

  // ---- reviews
  $r->add('GET', '/reviews', function () {
    $out = paged(['select' => 'r.*, p.name product_name', 'from' => 'reviews r LEFT JOIN products p ON p.id=r.product_id', 'searchCols' => ['r.name', 'r.text', 'p.name'], 'filters' => ['status' => 'r.status', 'rating' => 'r.rating'], 'sorts' => ['created' => 'r.created_at', 'rating' => 'r.rating'], 'defaultSort' => 'created']);
    $s = one_("SELECT COUNT(*) total, COALESCE(ROUND(AVG(rating),2),0) avg, SUM(status='pending') pending, SUM(status='approved') approved FROM reviews");
    $out['stats'] = ['total' => (int) $s['total'], 'avg' => $s['avg'] + 0, 'pending' => (int) ($s['pending'] ?? 0), 'approved' => (int) ($s['approved'] ?? 0), 'distribution' => all_('SELECT rating, COUNT(*) n FROM reviews GROUP BY rating')];
    return $out;
  }, 'reviews.view');
  $r->add('POST', '/reviews', function ($p, $c) { $b = bodyIn(); $pid = val_('SELECT id FROM products WHERE id=?', [(int) ($b['product_id'] ?? 0)]); if (!$pid) throw bad('Choose a website.');
    $id = run_("INSERT INTO reviews(product_id,name,rating,text,status,created_at) VALUES(?,?,?,?,'approved',?)", [$pid, vstr($b['name'] ?? null, ['required' => true, 'max' => 80, 'label' => 'Name']), vnum($b['rating'] ?? null, ['min' => 1, 'max' => 5, 'required' => true, 'label' => 'Rating']), vstr($b['text'] ?? null, ['required' => true, 'max' => 2000, 'label' => 'Review']), now_()]);
    logAct($c['user'], 'review.created', 'review', $id, ''); return created(['id' => $id]); }, 'reviews.edit');
  $r->add('PUT', '/reviews/:id', function ($p, $c) { $id = (int) $p['id']; $rv = one_('SELECT * FROM reviews WHERE id=?', [$id]); if (!$rv) throw notFound(); $b = bodyIn();
    $status = array_key_exists('status', $b) ? voneOf($b['status'], ['pending', 'approved', 'rejected', 'hidden'], 'Status') : $rv['status']; $reply = array_key_exists('reply', $b) ? vstr($b['reply'], ['max' => 1500]) : $rv['reply'];
    run_('UPDATE reviews SET status=?,reply=? WHERE id=?', [$status, $reply, $id]); logAct($c['user'], 'review.updated', 'review', $id, $status !== $rv['status'] ? "{$rv['status']} → $status" : 'reply'); return ['ok' => true]; }, 'reviews.edit');
  $r->add('DELETE', '/reviews/:id', function ($p, $c) { $id = (int) $p['id']; run_('DELETE FROM reviews WHERE id=?', [$id]); logAct($c['user'], 'review.deleted', 'review', $id, ''); return ['ok' => true]; }, 'reviews.edit');

  // ---- messages
  $r->add('GET', '/messages', function () { $w = []; if (qget('unread') === '1') $w[] = 'm.read = 0';
    return paged(['select' => 'm.*', 'from' => 'messages m', 'searchCols' => ['m.name', 'm.email', 'm.subject', 'm.body'], 'filters' => ['type' => 'm.type', 'status' => 'm.status', 'priority' => 'm.priority'],
      'sorts' => ['created' => 'm.created_at', 'priority' => "CASE m.priority WHEN 'high' THEN 3 WHEN 'normal' THEN 2 ELSE 1 END"], 'defaultSort' => 'created', 'where' => $w, 'json' => ['notes', 'replies'], 'bools' => ['read']]); }, 'messages.view');
  $r->add('GET', '/messages/:id', function ($p) { $m = one_('SELECT * FROM messages WHERE id=?', [(int) $p['id']]); if (!$m) throw notFound(); return parseRow($m, ['notes', 'replies'], ['read']); }, 'messages.view');
  $r->add('PUT', '/messages/:id', function ($p, $c) { $id = (int) $p['id']; $m = one_('SELECT * FROM messages WHERE id=?', [$id]); if (!$m) throw notFound(); $b = bodyIn();
    $read = array_key_exists('read', $b) ? vbool($b['read']) : (int) $m['read']; $status = array_key_exists('status', $b) ? voneOf($b['status'], ['new', 'in_progress', 'replied', 'closed'], 'Status') : $m['status']; $prio = array_key_exists('priority', $b) ? voneOf($b['priority'], ['low', 'normal', 'high'], 'Priority') : $m['priority'];
    run_('UPDATE messages SET read=?,status=?,priority=? WHERE id=?', [$read, $status, $prio, $id]);
    if ($status !== $m['status'] || $prio !== $m['priority']) logAct($c['user'], 'message.updated', 'message', $id, "{$m['status']}/{$m['priority']} → $status/$prio"); return ['ok' => true]; }, 'messages.edit');
  $r->add('POST', '/messages/:id/notes', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT notes FROM messages WHERE id=?', [$id]); if ($n === null) throw notFound(); $notes = jdec($n, []);
    $notes[] = ['at' => now_(), 'by' => $c['user']['username'], 'text' => vstr(bodyIn()['text'] ?? null, ['required' => true, 'max' => 2000, 'label' => 'Note'])]; run_('UPDATE messages SET notes=? WHERE id=?', [jenc($notes), $id]); return created(['ok' => true]); }, 'messages.edit');
  // Reply tracking only: records that a reply was sent (WhatsApp, email...). It does not send anything itself.
  $r->add('POST', '/messages/:id/replies', function ($p, $c) { $id = (int) $p['id']; $n = val_('SELECT replies FROM messages WHERE id=?', [$id]); if ($n === null) throw notFound(); $b = bodyIn(); $rep = jdec($n, []);
    $rep[] = ['at' => now_(), 'by' => $c['user']['username'], 'channel' => voneOf(($b['channel'] ?? '') ?: 'whatsapp', ['whatsapp', 'email', 'phone', 'other'], 'Channel'), 'text' => vstr($b['text'] ?? null, ['required' => true, 'max' => 3000, 'label' => 'Reply'])];
    run_("UPDATE messages SET replies=?,status='replied',read=1 WHERE id=?", [jenc($rep), $id]); logAct($c['user'], 'message.replied', 'message', $id, ''); return created(['ok' => true]); }, 'messages.edit');
  $r->add('DELETE', '/messages/:id', function ($p, $c) { $id = (int) $p['id']; run_('DELETE FROM messages WHERE id=?', [$id]); logAct($c['user'], 'message.deleted', 'message', $id, ''); return ['ok' => true]; }, 'messages.edit');

  // ---- media
  $usage = function (): string { $b = ''; foreach (all_('SELECT thumbnail, gallery FROM products') as $x) $b .= ' ' . implode(' ', $x); foreach (all_('SELECT value FROM settings') as $x) $b .= ' ' . $x['value']; return $b; };
  $withUrl = fn(array $m) => $m + ['url' => '/uploads/' . $m['filename']];
  $rmMedia = function (array $m) { @unlink(uploadDir() . '/' . basename($m['filename'])); run_('DELETE FROM media WHERE id=?', [$m['id']]); };
  $r->add('GET', '/media', function () use ($withUrl) { $w = []; $pr = []; if (qget('folder') !== '' && qget('folder') !== 'all') { $w[] = 'm.folder = ?'; $pr[] = qget('folder'); }
    $out = paged(['select' => 'm.*', 'from' => 'media m', 'searchCols' => ['m.original', 'm.filename'], 'sorts' => ['created' => 'm.created_at', 'size' => 'm.size', 'name' => 'm.original'], 'defaultSort' => 'created', 'where' => $w, 'params' => $pr]);
    $out['rows'] = array_map($withUrl, $out['rows']); $out['folders'] = all_('SELECT folder name, COUNT(*) n FROM media GROUP BY folder ORDER BY folder'); return $out; }, 'media.view');
  $r->add('POST', '/media', function ($p, $c) {
    $f = $_FILES['files'] ?? null; if (!$f) throw bad('Choose at least one image.');
    $names = (array) $f['name']; $tmps = (array) $f['tmp_name']; $errs = (array) $f['error']; $sizes = (array) $f['size'];
    if (!$names || $names[0] === '') throw bad('Choose at least one image.');
    $folder = preg_replace('/[^\w \-]/', '', vstr($_POST['folder'] ?? null, ['max' => 40])) ?: 'General'; $out = [];
    $ext = ['image/png' => '.png', 'image/jpeg' => '.jpg', 'image/webp' => '.webp', 'image/gif' => '.gif', 'image/x-icon' => '.ico'];
    foreach (array_slice(array_keys($names), 0, 10) as $i) {
      if ($errs[$i] === UPLOAD_ERR_INI_SIZE || $errs[$i] === UPLOAD_ERR_FORM_SIZE || $sizes[$i] > 5 * 1024 * 1024) throw bad('File is larger than 5 MB.');
      if ($errs[$i] !== UPLOAD_ERR_OK) throw bad('Upload failed. Try again.');
      $buf = file_get_contents($tmps[$i]); $h = substr($buf, 0, 12); $mime = null;
      if (str_starts_with($h, "\x89PNG\r\n\x1a\n")) $mime = 'image/png'; elseif (str_starts_with($h, "\xff\xd8")) $mime = 'image/jpeg'; elseif (substr($h, 0, 4) === 'RIFF' && substr($h, 8, 4) === 'WEBP') $mime = 'image/webp'; elseif (str_starts_with($h, 'GIF')) $mime = 'image/gif'; elseif (str_starts_with($h, "\x00\x00\x01\x00")) $mime = 'image/x-icon';
      if (!$mime) throw bad("{$names[$i]}: only PNG, JPG, WebP, GIF or ICO images are allowed.");
      $fn = bin2hex(random_bytes(12)) . $ext[$mime]; if (file_put_contents(uploadDir() . '/' . $fn, $buf) === false) throw new RuntimeException('Cannot write to the uploads folder.');
      $id = run_('INSERT INTO media(filename,original,mime,size,folder,created_at) VALUES(?,?,?,?,?,?)', [$fn, mb_substr(basename((string) $names[$i]), 0, 120), $mime, strlen($buf), $folder, now_()]); $out[] = ['id' => $id, 'url' => '/uploads/' . $fn];
    }
    logAct($c['user'], 'media.uploaded', 'media', implode(',', array_column($out, 'id')), count($out) . ' file(s)'); return created(['files' => $out]);
  }, 'media.edit');
  $r->add('GET', '/media/unused', function () use ($usage, $withUrl) { $b = $usage(); return array_values(array_map($withUrl, array_filter(all_('SELECT * FROM media'), fn($m) => !str_contains($b, $m['filename'])))); }, 'media.view');
  $r->add('DELETE', '/media/unused', function ($p, $c) use ($usage, $rmMedia) { $b = $usage(); $un = array_filter(all_('SELECT * FROM media'), fn($m) => !str_contains($b, $m['filename'])); foreach ($un as $m) $rmMedia($m); logAct($c['user'], 'media.cleanup', 'media', '', count($un) . ' unused file(s) deleted'); return ['deleted' => count($un)]; }, 'media.edit');
  $r->add('PUT', '/media/:id', function ($p) { run_('UPDATE media SET folder=? WHERE id=?', [preg_replace('/[^\w \-]/', '', vstr(bodyIn()['folder'] ?? null, ['max' => 40])) ?: 'General', (int) $p['id']]); return ['ok' => true]; }, 'media.edit');
  $r->add('DELETE', '/media/:id', function ($p, $c) use ($usage, $rmMedia) { $m = one_('SELECT * FROM media WHERE id=?', [(int) $p['id']]); if (!$m) throw notFound();
    if (str_contains($usage(), $m['filename']) && qget('force') !== '1') throw new HttpErr(409, 'This file is used on the site. Remove it there first, or delete anyway.');
    $rmMedia($m); logAct($c['user'], 'media.deleted', 'media', $m['id'], $m['original']); return ['ok' => true]; }, 'media.edit');

  // ---- settings groups
  foreach (['homepage' => 'homepage', 'seo' => 'seo', 'appearance' => 'appearance', 'general' => 'settings'] as $group => $area) {
    $r->add('GET', "/settings/$group", function () use ($group) {
      $s = getSetting($group);
      if ($group === 'general' && isset($s['emailConfig'])) $s['emailConfig'] = $s['emailConfig'] + ['passwordSet' => val_("SELECT value FROM settings WHERE key='secret.smtp'") !== null];
      return $s;
    }, "$area.view");
    $r->add('PUT', "/settings/$group", function ($p, $c) use ($group) {
      $body = bodyIn(); if (!$body || !isAssoc($body)) throw bad('Invalid settings.'); if (strlen(jenc($body)) > 200000) throw bad('Settings are too large.');
      if ($group === 'general') {
        if (isset($body['emailConfig']) && is_array($body['emailConfig'])) { $pw = $body['emailConfig']['password'] ?? null; unset($body['emailConfig']['password'], $body['emailConfig']['passwordSet']); if (is_string($pw) && $pw !== '') setSetting('secret.smtp', ['password' => $pw]); }
        if (array_key_exists('whatsapp', $body)) $body['whatsapp'] = substr(preg_replace('/\D/', '', (string) $body['whatsapp']), 0, 20);
        if (!empty($body['email'])) vemail($body['email']);
        foreach (['logo', 'favicon'] as $k) if (!empty($body[$k])) vurl($body[$k], $k);
      }
      if ($group === 'appearance' && isset($body['colors']) && is_array($body['colors'])) foreach ($body['colors'] as $v) if (!is_string($v) || !preg_match('/^#[0-9a-fA-F]{3,8}$/', $v)) throw bad('Colors must be hex values like #1677FF.');
      setSetting($group, deepMerge(getSetting($group), $body)); logAct($c['user'], 'settings.updated', 'settings', $group, implode(', ', array_keys($body))); return ['ok' => true];
    }, "$area.edit");
  }
  $r->add('GET', '/seo/status', function () { $s = getSetting('seo'); $pub = (int) val_("SELECT COUNT(*) FROM products WHERE status='published' AND visibility='public'");
    return ['sitemap' => $s['sitemapEnabled'], 'sitemapUrls' => $pub + 1, 'robots' => $s['robotsIndex'] ? 'Indexing allowed' : 'Search engines blocked', 'siteUrl' => $s['siteUrl'] ?: '(auto-detected from the request)']; }, 'seo.view');

  // ---- users & roles
  $r->add('GET', '/roles', fn() => ['roles' => array_map(fn($x) => ['name' => $x['name'], 'label' => $x['label'], 'permissions' => jdec($x['permissions'], []), 'locked' => !empty($x['locked'])], all_('SELECT * FROM roles')), 'areas' => AREAS], 'users.view');
  $r->add('PUT', '/roles/:name', function ($p, $c) { $role = one_('SELECT * FROM roles WHERE name=?', [$p['name']]); if (!$role) throw notFound(); if ($role['locked']) throw bad('The Super Admin role cannot be changed.');
    $b = bodyIn(); $perms = array_values(array_filter(is_array($b['permissions'] ?? null) ? $b['permissions'] : [], fn($x) => in_array($x, allPerms(), true))); $set = $perms;
    foreach ($perms as $x) if (str_ends_with($x, '.edit')) $set[] = str_replace('.edit', '.view', $x); $set = array_values(array_unique($set));
    run_('UPDATE roles SET permissions=?, label=? WHERE name=?', [jenc($set), vstr($b['label'] ?? null, ['max' => 40]) ?: $role['label'], $role['name']]); logAct($c['user'], 'permissions.changed', 'role', $role['name'], count($set) . ' permissions'); return ['ok' => true]; }, 'users.edit');
  $r->add('GET', '/users', fn() => array_map(function ($x) { $x['active'] = !empty($x['active']); return $x; }, all_('SELECT id,username,name,email,role,active,created_at,last_login FROM users ORDER BY id')), 'users.view');
  $roleOk = function ($n) { if (!is_string($n) || !val_('SELECT name FROM roles WHERE name=?', [$n])) throw bad('Unknown role.'); return $n; };
  $superCount = fn() => (int) val_("SELECT COUNT(*) FROM users WHERE role='super_admin' AND active=1");
  $r->add('POST', '/users', function ($p, $c) use ($roleOk) {
    $b = bodyIn(); $username = vstr($b['username'] ?? null, ['required' => true, 'min' => 3, 'max' => 32, 'label' => 'Username']);
    if (!preg_match('/^[A-Za-z0-9_.-]+$/', $username)) throw bad('Username may only contain letters, numbers, dot, dash and underscore.');
    if (val_('SELECT id FROM users WHERE username=?', [$username])) throw bad('That username is taken.');
    $role = $roleOk($b['role'] ?? null); if ($role === 'super_admin' && !in_array('users.edit', $c['perms'], true)) throw new HttpErr(403, 'Not allowed.');
    $err = validatePassword($b['password'] ?? null); if ($err) throw bad($err);
    $id = run_('INSERT INTO users(username,name,email,password_hash,role,active,created_at) VALUES(?,?,?,?,?,1,?)', [$username, vstr($b['name'] ?? null, ['required' => true, 'max' => 80, 'label' => 'Name']), vemail($b['email'] ?? null), hashPassword($b['password']), $role, now_()]);
    logAct($c['user'], 'user.created', 'user', $id, "$username ($role)"); return created(['id' => $id]);
  }, 'users.edit');
  $r->add('PUT', '/users/:id', function ($p, $c) use ($roleOk, $superCount) {
    $id = (int) $p['id']; $u = one_('SELECT * FROM users WHERE id=?', [$id]); if (!$u) throw notFound(); $b = bodyIn();
    $role = array_key_exists('role', $b) ? $roleOk($b['role']) : $u['role']; $active = array_key_exists('active', $b) ? vbool($b['active']) : (int) $u['active'];
    if ($u['role'] === 'super_admin' && ($role !== 'super_admin' || !$active) && $superCount() <= 1) throw bad('There must always be at least one active Super Admin.');
    if ($id === $c['user']['id'] && !$active) throw bad('You cannot deactivate your own account.');
    if ($role === 'super_admin' && $u['role'] !== 'super_admin' && $c['user']['role'] !== 'super_admin') throw new HttpErr(403, 'Only a Super Admin can create another Super Admin.');
    $hash = $u['password_hash']; if (!empty($b['password'])) { $err = validatePassword($b['password']); if ($err) throw bad($err); $hash = hashPassword($b['password']); }
    run_('UPDATE users SET name=?,email=?,role=?,active=?,password_hash=? WHERE id=?', [array_key_exists('name', $b) ? vstr($b['name'], ['required' => true, 'max' => 80, 'label' => 'Name']) : $u['name'], array_key_exists('email', $b) ? vemail($b['email']) : $u['email'], $role, $active, $hash, $id]);
    if (!$active || !empty($b['password'])) run_('DELETE FROM sessions WHERE user_id=?', [$id]);
    logAct($c['user'], $role !== $u['role'] ? 'permissions.changed' : 'user.updated', 'user', $id, $u['username'] . ($role !== $u['role'] ? ": {$u['role']} → $role" : '') . (!empty($b['password']) ? ' (password reset)' : '')); return ['ok' => true];
  }, 'users.edit');
  $r->add('DELETE', '/users/:id', function ($p, $c) use ($superCount) { $id = (int) $p['id']; $u = one_('SELECT * FROM users WHERE id=?', [$id]); if (!$u) throw notFound();
    if ($id === $c['user']['id']) throw bad('You cannot delete your own account.'); if ($u['role'] === 'super_admin' && $superCount() <= 1) throw bad('There must always be at least one active Super Admin.');
    run_('DELETE FROM users WHERE id=?', [$id]); logAct($c['user'], 'user.deleted', 'user', $id, $u['username']); return ['ok' => true]; }, 'users.edit');
  $r->add('POST', '/account/password', function ($p, $c) { $b = bodyIn(); $u = one_('SELECT * FROM users WHERE id=?', [$c['user']['id']]);
    if (!password_verify((string) ($b['current'] ?? ''), $u['password_hash'])) throw bad('Current password is wrong.'); $err = validatePassword($b['password'] ?? null); if ($err) throw bad($err);
    run_('UPDATE users SET password_hash=? WHERE id=?', [hashPassword($b['password']), $u['id']]); run_('DELETE FROM sessions WHERE user_id=? AND csrf != ?', [$u['id'], $c['csrf']]); logAct($c['user'], 'user.password_changed', 'user', $u['id'], ''); return ['ok' => true]; });

  // ---- activity
  $r->add('GET', '/activity', function () { $w = []; $pr = []; if (qget('entity') !== '' && qget('entity') !== 'all') { $w[] = 'entity = ?'; $pr[] = qget('entity'); }
    return paged(['select' => 'a.*', 'from' => 'activity a', 'searchCols' => ['a.username', 'a.action', 'a.details', 'a.entity_id'], 'filters' => ['user' => 'a.username'], 'sorts' => ['created' => 'a.id'], 'defaultSort' => 'created', 'where' => $w, 'params' => $pr]); }, 'logs.view');
  return $r;
}
function badges(): array { return ['orders' => (int) val_("SELECT COUNT(*) FROM orders WHERE status IN ('new','pending_confirmation')"), 'reviews' => (int) val_("SELECT COUNT(*) FROM reviews WHERE status='pending'"), 'messages' => (int) val_('SELECT COUNT(*) FROM messages WHERE read=0')]; }
