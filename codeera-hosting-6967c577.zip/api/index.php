<?php
// API entry point. Everything under /api/ lands here (see .htaccess).
declare(strict_types=1);
require __DIR__ . '/lib.php'; require __DIR__ . '/admin.php'; require __DIR__ . '/public.php'; require __DIR__ . '/page.php';
ini_set('display_errors', '0');
securityHeaders();
try {
  $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'; $pos = strpos($uri, '/api/');
  $path = rtrim($pos === false ? '/' : substr($uri, $pos + 4), '/') ?: '/'; $method = $_SERVER['REQUEST_METHOD'] ?? 'GET'; if ($method === 'HEAD') $method = 'GET';
  $hdr = fn(string $n) => $_SERVER['HTTP_' . strtoupper(str_replace('-', '_', $n))] ?? '';
  $userCount = fn() => (int) val_('SELECT COUNT(*) FROM users');

  if ($path === '/auth/status' && $method === 'GET') { sendJson(['needsSetup' => $userCount() === 0, 'signedIn' => loadUser() !== null]); }
  if ($path === '/auth/setup' && $method === 'POST') {
    if ($userCount() > 0) throw new HttpErr(403, 'Setup is already complete.');
    $b = bodyIn(); $username = vstr($b['username'] ?? null, ['required' => true, 'min' => 3, 'max' => 32, 'label' => 'Username']);
    if (!preg_match('/^[A-Za-z0-9_.-]+$/', $username)) throw bad('Username may only contain letters, numbers, dot, dash and underscore.');
    $err = validatePassword($b['password'] ?? null); if ($err) throw bad($err); if (($b['password'] ?? '') !== ($b['confirm'] ?? null)) throw bad('Passwords do not match.');
    $id = tx(function () use ($userCount, $b, $username) { if ($userCount() > 0) throw new HttpErr(403, 'Setup is already complete.');
      return run_("INSERT INTO users(username,name,email,password_hash,role,active,created_at,last_login) VALUES(?,?,?,?,'super_admin',1,?,?)", [$username, vstr($b['name'] ?? null, ['max' => 80]) ?: $username, vemail($b['email'] ?? null), hashPassword($b['password']), now_(), now_()]); });
    logAct(['id' => $id, 'username' => $username], 'user.setup', 'user', $id, 'Super Admin created during first-run setup');
    sendJson(['ok' => true, 'csrf' => createSession($id)], 201);
  }
  if ($path === '/auth/login' && $method === 'POST') {
    $b = bodyIn(); $username = strtolower(substr(trim((string) ($b['username'] ?? '')), 0, 64)); $ip = clientIp(); $k1 = $ip . '|' . $username; $k2 = $ip;
    $wait = max(throttleWait($k1), throttleWait($k2)); if ($wait) throw new HttpErr(429, "Too many failed attempts. Try again in $wait minute(s).");
    $u = one_('SELECT * FROM users WHERE username = ?', [$username]);
    $ok = password_verify((string) ($b['password'] ?? ''), $u ? $u['password_hash'] : '$2y$12$C6UzMDM.H6dfI/f/IKcEeO5jJ3nY3Q9m8y0pQ0j5yq2yQZ1kqJ1hSuuuuuuuuuuuuuuuuu');
    if (!$u || !$ok || !$u['active']) { throttleFail($k1); if ($u && !$u['active'] && $ok) throw new HttpErr(403, 'This account is disabled.'); logAct(['username' => $username ?: '?'], 'user.login_failed', 'user', $u['id'] ?? '', ''); throw new HttpErr(401, 'Wrong username or password.'); }
    throttleClear($k1); run_('UPDATE users SET last_login=? WHERE id=?', [now_(), $u['id']]); logAct($u, 'user.login', 'user', $u['id'], '');
    sendJson(['ok' => true, 'csrf' => createSession((int) $u['id'])]);
  }
  if ($path === '/auth/logout' && $method === 'POST') { $s = loadUser(); if ($s && hash_equals($s['csrf'], $hdr('X-CSRF-Token'))) { logAct($s['user'], 'user.logout', 'user', $s['user']['id'], ''); destroySession(); } sendJson(['ok' => true]); }

  if (str_starts_with($path, '/public/')) {
    $m = publicRoutes()->match($method, substr($path, 7)); if (!$m) throw notFound();
    $out = $m[0]($m[1]); if ($out instanceof Resp) sendJson($out->data, $out->status); sendJson($out);
  }
  if (str_starts_with($path, '/admin/') || $path === '/admin') {
    $s = loadUser(); if (!$s) throw new HttpErr(401, 'Not signed in.');
    if (!in_array($method, ['GET', 'HEAD', 'OPTIONS'], true) && !hash_equals($s['csrf'], $hdr('X-CSRF-Token'))) throw new HttpErr(403, 'Security check failed. Reload the page.');
    $m = adminRoutes()->match($method, substr($path, 6)); if (!$m) throw notFound();
    [$fn, $params, $perm] = $m; if ($perm && !in_array($perm, $s['perms'], true)) throw new HttpErr(403, 'You do not have permission to do this.');
    $out = $fn($params, $s);
    if ($out instanceof Resp) {
      if ($out->csv !== null) { header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $out->file . '"'); echo $out->csv; exit; }
      sendJson($out->data, $out->status);
    }
    sendJson($out);
  }
  throw notFound();
} catch (HttpErr $e) { sendJson(['error' => $e->getMessage()], $e->status);
} catch (PDOException $e) { if (str_contains($e->getMessage(), 'UNIQUE') || str_contains($e->getMessage(), 'constraint')) sendJson(['error' => 'That value conflicts with existing data (duplicate or in use).'], 400); error_log('CodeEra DB: ' . $e->getMessage()); sendJson(['error' => 'Something went wrong on the server.'], 500);
} catch (Throwable $e) { error_log('CodeEra: ' . $e->getMessage()); sendJson(['error' => 'Something went wrong on the server.'], 500); }
