<?php
// CodeEra backend core: config, database, helpers, auth. PHP 8.0+ with PDO SQLite (standard on almost all hosts).
declare(strict_types=1);

class HttpErr extends Exception { public int $status; public function __construct(int $s, string $m) { parent::__construct($m); $this->status = $s; } }
function bad(string $m): HttpErr { return new HttpErr(400, $m); }
function notFound(string $m = 'Not found.'): HttpErr { return new HttpErr(404, $m); }

// ---------------------------------------------------------------- config
$CFG = ['data_dir' => null, 'upload_dir' => null, 'secure_cookies' => null, 'trust_proxy' => false, 'session_hours' => 12];
if (is_file(__DIR__ . '/config.php')) { $user = include __DIR__ . '/config.php'; if (is_array($user)) $CFG = array_merge($CFG, $user); }
$SITE_ROOT = dirname(__DIR__);
function cfg(string $k) { global $CFG; return $CFG[$k] ?? null; }
function dataDir(): string {
  static $d = null; if ($d) return $d;
  $cands = [];
  if (cfg('data_dir')) $cands[] = cfg('data_dir');
  $cands[] = dirname($GLOBALS['SITE_ROOT']) . '/codeera-data';   // outside the public web folder (best)
  $cands[] = __DIR__ . '/data';                                   // fallback, protected by .htaccess
  foreach ($cands as $c) { if (!is_dir($c)) @mkdir($c, 0750, true); if (is_dir($c) && is_writable($c)) { $d = rtrim($c, '/\\'); break; } }
  if (!$d) throw new RuntimeException('No writable data folder. Set data_dir in api/config.php.');
  if (!is_file($d . '/.htaccess')) @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
  return $d;
}
function uploadDir(): string { $u = cfg('upload_dir') ?: $GLOBALS['SITE_ROOT'] . '/uploads'; if (!is_dir($u)) @mkdir($u, 0755, true); return rtrim($u, '/\\'); }
function isHttps(): bool { return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') || (($_SERVER['SERVER_PORT'] ?? '') === '443'); }
function clientIp(): string { if (cfg('trust_proxy') && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]); return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }

// ---------------------------------------------------------------- permissions
const AREAS = ['products', 'categories', 'orders', 'customers', 'analytics', 'coupons', 'reviews', 'messages', 'homepage', 'media', 'seo', 'appearance', 'settings', 'users', 'logs'];
function allPerms(): array { $o = []; foreach (AREAS as $a) { $o[] = $a . '.view'; $o[] = $a . '.edit'; } return $o; }
function only(array $areas, ?array $edit = null): array { $edit = $edit ?? $areas; return array_merge(array_map(fn($a) => $a . '.view', $areas), array_map(fn($a) => $a . '.edit', $edit)); }
function defaultRoles(): array {
  $all = allPerms();
  return [
    'super_admin' => ['label' => 'Super Admin', 'locked' => 1, 'permissions' => $all],
    'admin' => ['label' => 'Admin', 'locked' => 0, 'permissions' => array_values(array_filter($all, fn($p) => $p !== 'users.edit'))],
    'editor' => ['label' => 'Editor', 'locked' => 0, 'permissions' => array_merge(only(['products', 'categories', 'reviews', 'homepage', 'media', 'seo', 'appearance']), ['messages.view', 'analytics.view'])],
    'order_manager' => ['label' => 'Order Manager', 'locked' => 0, 'permissions' => array_merge(only(['orders', 'customers', 'coupons', 'messages']), ['products.view', 'reviews.view', 'analytics.view'])],
  ];
}

// ---------------------------------------------------------------- database
function db(): PDO {
  static $pdo = null; if ($pdo) return $pdo;
  $file = dataDir() . '/codeera.sqlite';
  $fresh = !is_file($file);
  $pdo = new PDO('sqlite:' . $file, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
  if ($fresh) @chmod($file, 0640);
  $pdo->exec('PRAGMA foreign_keys = ON'); $pdo->exec('PRAGMA busy_timeout = 5000');
  try { $pdo->exec('PRAGMA journal_mode = WAL'); } catch (Throwable $e) {}
  $pdo->exec(SCHEMA);
  seedIfEmpty($pdo);
  return $pdo;
}
const SCHEMA = <<<'SQL'
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE, name TEXT NOT NULL, email TEXT, password_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, last_login TEXT);
CREATE TABLE IF NOT EXISTS roles (name TEXT PRIMARY KEY, label TEXT NOT NULL, permissions TEXT NOT NULL, locked INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, csrf TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS throttle (k TEXT PRIMARY KEY, n INTEGER NOT NULL, first_at INTEGER NOT NULL, until_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS ratelimit (k TEXT NOT NULL, at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_ratelimit ON ratelimit(k, at);
CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY, name TEXT NOT NULL, name_ar TEXT, slug TEXT UNIQUE NOT NULL, description TEXT, icon TEXT, sort INTEGER NOT NULL DEFAULT 0, visible INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL, short_desc TEXT, full_desc TEXT, price REAL NOT NULL DEFAULT 0, discount_price REAL, thumbnail TEXT, gallery TEXT NOT NULL DEFAULT '[]', demo_url TEXT, purchase_type TEXT NOT NULL DEFAULT 'license', features TEXT NOT NULL DEFAULT '[]', technologies TEXT NOT NULL DEFAULT '[]', tags TEXT NOT NULL DEFAULT '[]', pages TEXT NOT NULL DEFAULT '[]', customization TEXT NOT NULL DEFAULT '[]', included TEXT NOT NULL DEFAULT '[]', faq TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'draft', featured INTEGER NOT NULL DEFAULT 0, availability TEXT NOT NULL DEFAULT 'available', visibility TEXT NOT NULL DEFAULT 'public', seo_title TEXT, seo_desc TEXT, accent TEXT, hue TEXT, kind TEXT, concept INTEGER NOT NULL DEFAULT 0, sort INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT COLLATE NOCASE, phone TEXT, notes TEXT, created_at TEXT NOT NULL, last_activity TEXT);
CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL, product_id INTEGER REFERENCES products(id) ON DELETE SET NULL, product_name TEXT NOT NULL, category_id INTEGER, purchase_type TEXT NOT NULL DEFAULT 'license', amount REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, coupon_code TEXT, payment_method TEXT, payment_status TEXT NOT NULL DEFAULT 'unpaid', status TEXT NOT NULL DEFAULT 'new', customization TEXT, notes TEXT NOT NULL DEFAULT '[]', history TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS coupons (id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL COLLATE NOCASE, type TEXT NOT NULL, value REAL NOT NULL, expires_at TEXT, usage_limit INTEGER, used INTEGER NOT NULL DEFAULT 0, min_purchase REAL NOT NULL DEFAULT 0, product_ids TEXT NOT NULL DEFAULT '[]', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY, product_id INTEGER REFERENCES products(id) ON DELETE CASCADE, name TEXT NOT NULL, rating INTEGER NOT NULL, text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', reply TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, type TEXT NOT NULL DEFAULT 'contact', name TEXT NOT NULL, email TEXT, phone TEXT, subject TEXT, body TEXT NOT NULL, project_type TEXT, budget TEXT, read INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'new', priority TEXT NOT NULL DEFAULT 'normal', notes TEXT NOT NULL DEFAULT '[]', replies TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS media (id INTEGER PRIMARY KEY, filename TEXT UNIQUE NOT NULL, original TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, folder TEXT NOT NULL DEFAULT 'General', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY, user_id INTEGER, username TEXT, action TEXT NOT NULL, entity TEXT, entity_id TEXT, details TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_activity_created ON activity(created_at);
CREATE TABLE IF NOT EXISTS views (day TEXT NOT NULL, product_id INTEGER NOT NULL DEFAULT 0, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day, product_id));
SQL;

function q(string $sql, array $p = []): PDOStatement { $s = db()->prepare($sql); $s->execute(array_values($p)); return $s; }
function all_(string $sql, array $p = []): array { return q($sql, $p)->fetchAll(); }
function one_(string $sql, array $p = []): ?array { $r = q($sql, $p)->fetch(); return $r === false ? null : $r; }
function val_(string $sql, array $p = []) { $r = q($sql, $p)->fetch(PDO::FETCH_NUM); return $r ? $r[0] : null; }
function run_(string $sql, array $p = []): int { q($sql, $p); return (int) db()->lastInsertId(); }
function tx(callable $fn) { $pdo = db(); $pdo->beginTransaction(); try { $r = $fn(); $pdo->commit(); return $r; } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; } }
function now_(): string { $t = microtime(true); return gmdate('Y-m-d\TH:i:s', (int) $t) . sprintf('.%03dZ', (int) (($t - floor($t)) * 1000)); }
function jenc($v): string { return json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION); }
function jdec($s, $d = []) { if ($s === null || $s === '') return $d; $r = json_decode((string) $s, true); return $r === null ? $d : $r; }
function parseRow(?array $row, array $json = [], array $bools = []): ?array {
  if ($row === null) return null;
  foreach ($json as $c) $row[$c] = jdec($row[$c] ?? '[]', []);
  foreach ($bools as $c) $row[$c] = !empty($row[$c]);
  return $row;
}
function parseRows(array $rows, array $json = [], array $bools = []): array { return array_map(fn($r) => parseRow($r, $json, $bools), $rows); }

// ---------------------------------------------------------------- settings
function defaultSettings(): array {
  static $d = null; if ($d) return $d;
  $seed = jdec(file_get_contents(__DIR__ . '/seed-products.json'), []);
  $services = array_map(fn($s) => $s + ['visible' => true], $seed['services'] ?? []);
  return $d = [
    'general' => ['siteName' => 'CodeEra', 'logo' => '', 'favicon' => '', 'email' => '', 'phone' => '', 'address' => '', 'whatsapp' => '201070245860', 'currency' => 'USD', 'currencySymbol' => '$',
      'paymentMethods' => [['id' => 'bank', 'label' => 'Bank transfer', 'enabled' => true], ['id' => 'wallet', 'label' => 'Mobile wallet', 'enabled' => true], ['id' => 'whatsapp', 'label' => 'Arranged on WhatsApp', 'enabled' => true]],
      'social' => ['handle' => 'codeerateam', 'instagram' => 'https://www.instagram.com/codeerateam', 'tiktok' => 'https://www.tiktok.com/@codeerateam', 'facebook' => 'https://www.facebook.com/codeerateam'],
      'maintenance' => false, 'maintenanceMessage' => 'We are making CodeEra even better. Back soon.', 'emailConfig' => ['host' => '', 'port' => 587, 'secure' => false, 'user' => '', 'from' => '']],
    'homepage' => ['announcement' => ['enabled' => false, 'text' => '', 'link' => ''],
      'hero' => ['label' => 'DIGITAL ARCHITECTURE · NEXT GENERATION', 'headline1' => 'Ancient roots.', 'headline2' => 'Future code.', 'subtitle' => 'We build digital experiences designed to turn ideas into powerful online realities.', 'primaryCta' => 'Explore Our Work', 'secondaryCta' => 'Build Your Website', 'image' => ''],
      'exploreTitle1' => 'Digital creations.', 'exploreTitle2' => 'Ready for your next era.', 'exploreSubtitle' => 'Explore our collection of digital experiences, crafted for businesses, brands, and ambitious ideas.',
      'featuredProductIds' => [], 'showCategoryFilters' => true, 'featuredOnly' => false, 'services' => $services,
      'about' => ['kicker' => 'ABOUT CODEERA', 'headline1' => "We don't just build websites.", 'headline2' => 'We build digital civilizations.', 'text' => 'CodeEra transforms ideas into digital products — combining design, technology, and intelligent systems to create experiences built for tomorrow.', 'arabic' => 'جذور قديمة. كود المستقبل.'],
      'testimonials' => ['enabled' => true, 'useApprovedReviews' => true, 'manual' => []],
      'statistics' => ['enabled' => true, 'items' => [['label' => 'Websites ready', 'source' => 'products'], ['label' => 'Happy customers', 'source' => 'customers'], ['label' => 'Orders delivered', 'source' => 'orders_completed']]],
      'footer' => ['tagline' => 'Ancient roots. Future code.', 'text' => '']],
    'seo' => ['siteTitle' => 'CodeEra | Ancient roots. Future code.', 'titleTemplate' => '%s | CodeEra', 'description' => 'CodeEra is a digital studio that creates, develops and sells ready-made websites and customized website solutions.',
      'ogImage' => '', 'ogTitle' => '', 'ogDescription' => '', 'twitterCard' => 'summary_large_image', 'robotsIndex' => true, 'robotsExtra' => '', 'sitemapEnabled' => true, 'siteUrl' => '', 'pages' => ['home' => ['title' => '', 'description' => '']]],
    'appearance' => ['colors' => ['navy' => '#020817', 'dark' => '#07152E', 'blue' => '#1677FF', 'cyan' => '#28D9FF', 'gold' => '#C8A45D', 'white' => '#F4F7FF'],
      'font' => 'inter', 'buttonStyle' => 'pill', 'radius' => 'lg', 'animations' => 'full', 'defaultTheme' => 'dark', 'allowThemeToggle' => true,
      'header' => ['transparent' => true, 'showCta' => false, 'ctaLabel' => 'Build Your Website'], 'footerStyle' => 'centered'],
  ];
}
function isAssoc($a): bool { return is_array($a) && $a !== [] && array_keys($a) !== range(0, count($a) - 1); }
function deepMerge($base, $over) {
  if (!is_array($over)) return $over;
  if (!isAssoc($over) && $over !== []) return $over;               // lists replace
  if ($over === [] ) return (is_array($base) && isAssoc($base)) ? $base : $over;
  if (!is_array($base) || !isAssoc($base)) return $over;
  foreach ($over as $k => $v) $base[$k] = array_key_exists($k, $base) ? deepMerge($base[$k], $v) : $v;
  return $base;
}
function getSetting(string $key): array {
  $raw = val_('SELECT value FROM settings WHERE key = ?', [$key]);
  $saved = $raw ? jdec($raw, []) : [];
  $base = defaultSettings()[$key] ?? [];
  return is_array($saved) ? deepMerge($base, $saved) : $base;
}
function setSetting(string $key, $value): void { run_('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', [$key, jenc($value)]); }

// ---------------------------------------------------------------- seed
function slugify(string $s): string {
  $s = mb_strtolower($s); $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s); if ($t !== false && $t !== '') $s = $t;
  $s = preg_replace('/[^\w\s-]/u', '', $s); $s = trim($s); $s = preg_replace('/[\s_]+/', '-', $s); $s = preg_replace('/-+/', '-', $s); $s = trim($s, '-');
  return $s === '' ? 'item' : $s;
}
function seedIfEmpty(PDO $pdo): void {
  foreach (defaultRoles() as $name => $r) if (!val_('SELECT name FROM roles WHERE name = ?', [$name])) run_('INSERT INTO roles(name,label,permissions,locked) VALUES(?,?,?,?)', [$name, $r['label'], jenc($r['permissions']), $r['locked']]);
  $seed = jdec(file_get_contents(__DIR__ . '/seed-products.json'), []);
  $ICONS = ['E-commerce' => 'cart', 'Restaurants' => 'dish', 'Landing Pages' => 'rocket', 'Business Websites' => 'building', 'Portfolio' => 'pen', 'Booking Systems' => 'calendar', 'Dashboard Systems' => 'chart', 'Custom Solutions' => 'spark'];
  $AR = ['E-commerce' => 'متاجر إلكترونية', 'Restaurants' => 'مطاعم', 'Landing Pages' => 'صفحات هبوط', 'Business Websites' => 'مواقع شركات', 'Portfolio' => 'معارض أعمال', 'Booking Systems' => 'أنظمة حجز', 'Dashboard Systems' => 'لوحات تحكم', 'Custom Solutions' => 'حلول مخصصة'];
  if ((int) val_('SELECT COUNT(*) FROM categories') === 0) {
    $i = 0; foreach ($seed['categories'] ?? [] as $c) { if ($c === 'All') continue; run_('INSERT INTO categories(name,name_ar,slug,description,icon,sort,visible) VALUES(?,?,?,?,?,?,1)', [$c, $AR[$c] ?? '', slugify($c), '', $ICONS[$c] ?? 'code', $i++]); }
  }
  if ((int) val_('SELECT COUNT(*) FROM products') === 0) {
    $i = 0; $t = now_();
    foreach ($seed['products'] ?? [] as $p) {
      $cat = val_('SELECT id FROM categories WHERE name = ?', [$p['category'] ?? '']);
      run_("INSERT INTO products(name,slug,category_id,short_desc,full_desc,price,gallery,demo_url,purchase_type,features,technologies,tags,pages,customization,included,faq,status,featured,availability,visibility,seo_title,seo_desc,accent,hue,kind,concept,sort,created_at,updated_at) VALUES(?,?,?,?,?,?,'[]',?,'license',?,?,'[]',?,?,?,?,'published',?,'available','public',?,?,?,?,?,?,?,?,?)",
        [$p['name'], slugify($p['name']), $cat ?: null, $p['blurb'] ?? '', $p['overview'] ?? '', $p['price'] ?? 0, $p['demoUrl'] ?? null, jenc($p['features'] ?? []), jenc($p['tech'] ?? []), jenc($p['pages'] ?? []), jenc($p['customization'] ?? []), jenc($p['included'] ?? []), jenc($p['faq'] ?? []),
         $i < 3 ? 1 : 0, $p['name'], $p['blurb'] ?? '', $p['accent'] ?? null, $p['hue'] ?? null, $p['kind'] ?? null, !empty($p['concept']) ? 1 : 0, $i, $t, $t]);
      $i++;
    }
  }
}
function uniqueSlug(string $table, string $base, int $ignore = 0): string {
  $slug = slugify($base); $n = 1;
  while (val_("SELECT id FROM $table WHERE slug = ? AND id != ?", [$slug, $ignore])) $slug = slugify($base) . '-' . (++$n);
  return $slug;
}
function logAct($user, string $action, string $entity, $entityId, string $details = ''): void {
  run_('INSERT INTO activity(user_id,username,action,entity,entity_id,details,created_at) VALUES(?,?,?,?,?,?,?)', [$user['id'] ?? null, $user['username'] ?? 'system', $action, $entity ?: null, $entityId === null ? null : (string) $entityId, $details ?: null, now_()]);
}

// ---------------------------------------------------------------- validation
function vstr($v, array $o = []): string {
  $min = $o['min'] ?? 0; $max = $o['max'] ?? 500; $label = $o['label'] ?? 'Value'; $req = $o['required'] ?? false;
  $s = $v === null || is_array($v) ? '' : trim((string) $v);
  if ($req && $s === '') throw bad("$label is required.");
  if ($s !== '' && mb_strlen($s) < $min) throw bad("$label must be at least $min characters.");
  if (mb_strlen($s) > $max) throw bad("$label must be at most $max characters.");
  return $s;
}
function vnum($v, array $o = []) {
  $min = $o['min'] ?? 0; $max = $o['max'] ?? 1e9; $label = $o['label'] ?? 'Number';
  if ($v === '' || $v === null) { if (!empty($o['required'])) throw bad("$label is required."); return !empty($o['nullable']) ? null : 0; }
  if (!is_numeric($v)) throw bad("$label must be a number.");
  $n = $v + 0; if ($n < $min || $n > $max) throw bad("$label must be between $min and $max.");
  return $n;
}
function voneOf($v, array $list, string $label = 'Value') { if (!in_array($v, $list, true)) throw bad("$label must be one of: " . implode(', ', $list) . '.'); return $v; }
function vlist($v, int $max = 60, int $itemMax = 200): array { if (!is_array($v)) return []; $o = []; foreach ($v as $x) { $s = trim(is_scalar($x) ? (string) $x : ''); if ($s !== '') $o[] = mb_substr($s, 0, $itemMax); } return array_slice($o, 0, $max); }
function vemail($v, bool $req = false): string {
  $s = vstr($v, ['max' => 200]);
  if ($s === '') { if ($req) throw bad('Email is required.'); return ''; }
  if (!preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $s)) throw bad('Enter a valid email address.');
  return $s;
}
function vurl($v, string $label = 'URL'): string {
  $s = vstr($v, ['max' => 500]); if ($s === '') return '';
  if (!preg_match('#^(https?://|/uploads/|/)#i', $s)) throw bad("$label must start with http://, https:// or /.");
  return $s;
}
function vbool($v): int { return ($v === true || $v === 1 || $v === '1' || $v === 'true') ? 1 : 0; }
function bodyIn(): array { static $b = null; if ($b !== null) return $b; $raw = file_get_contents('php://input'); if ($raw === '' || $raw === false) return $b = []; $j = json_decode($raw, true); if (!is_array($j)) throw bad('Invalid request body.'); return $b = $j; }
function qget(string $k, $d = '') { $v = $_GET[$k] ?? $d; return is_array($v) ? $d : $v; }

function paged(array $o): array {
  $searchCols = $o['searchCols'] ?? []; $filters = $o['filters'] ?? []; $sorts = $o['sorts']; $w = $o['where'] ?? []; $p = $o['params'] ?? [];
  $qs = trim((string) qget('q'));
  $page = max(1, (int) qget('page', 1)); $size = min(100, max(1, (int) qget('pageSize', 20)));
  if ($qs !== '' && $searchCols) { $w[] = '(' . implode(' OR ', array_map(fn($c) => "$c LIKE ?", $searchCols)) . ')'; foreach ($searchCols as $_) $p[] = "%$qs%"; }
  foreach ($filters as $key => $col) { $val = qget($key, null); if ($val !== null && $val !== '' && $val !== 'all') { $w[] = "$col = ?"; $p[] = $val; } }
  $sk = array_key_exists(qget('sort'), $sorts) ? qget('sort') : $o['defaultSort'];
  $dir = strtolower((string) qget('dir')) === 'asc' ? 'ASC' : 'DESC';
  $sql = 'FROM ' . $o['from'] . ($w ? ' WHERE ' . implode(' AND ', $w) : '');
  $total = (int) val_("SELECT COUNT(*) $sql", $p);
  $rows = all_("SELECT {$o['select']} $sql ORDER BY {$sorts[$sk]} $dir LIMIT ? OFFSET ?", array_merge($p, [$size, ($page - 1) * $size]));
  $rows = parseRows($rows, $o['json'] ?? [], $o['bools'] ?? []);
  return ['rows' => $rows, 'total' => $total, 'page' => $page, 'pageSize' => $size, 'pages' => max(1, (int) ceil($total / $size))];
}
function csvCell($v): string { $s = $v === null ? '' : (string) $v; $f = $s !== '' && strpos('=+-@', $s[0]) !== false; return (preg_match('/[",\n\r]/', $s) || $f) ? '"' . ($f ? "'" : '') . str_replace('"', '""', $s) . '"' : $s; }
function toCsv(array $rows, array $cols): string { $o = [implode(',', array_map('csvCell', $cols))]; foreach ($rows as $r) $o[] = implode(',', array_map(fn($c) => csvCell($r[$c] ?? null), $cols)); return implode("\r\n", $o); }

// ---------------------------------------------------------------- auth
function sha(string $s): string { return hash('sha256', $s); }
function hashPassword(string $p): string { return password_hash($p, PASSWORD_BCRYPT, ['cost' => 12]); }
function validatePassword($p): ?string {
  if (!is_string($p) || mb_strlen($p) < 10) return 'Password must be at least 10 characters.';
  if (mb_strlen($p) > 200) return 'Password is too long.';
  if (!preg_match('/[a-zA-Z]/', $p) || !preg_match('/[0-9]/', $p)) return 'Password must include letters and numbers.';
  return null;
}
function setSessionCookie(string $token, int $maxAge): void {
  setcookie('ce_sid', $token, ['expires' => $maxAge ? time() + $maxAge : time() - 3600, 'path' => '/', 'secure' => cfg('secure_cookies') ?? isHttps(), 'httponly' => true, 'samesite' => 'Lax']);
}
function createSession(int $userId): string {
  $token = bin2hex(random_bytes(32)); $csrf = bin2hex(random_bytes(16)); $h = (int) cfg('session_hours');
  run_('INSERT INTO sessions(token_hash,user_id,csrf,expires_at,created_at) VALUES(?,?,?,?,?)', [sha($token), $userId, $csrf, gmdate('Y-m-d\TH:i:s.000\Z', time() + $h * 3600), now_()]);
  setSessionCookie($token, $h * 3600);
  return $csrf;
}
function destroySession(): void { $t = $_COOKIE['ce_sid'] ?? ''; if ($t) run_('DELETE FROM sessions WHERE token_hash = ?', [sha($t)]); setSessionCookie('', 0); }
function loadUser(): ?array {
  $t = $_COOKIE['ce_sid'] ?? ''; if (!is_string($t) || $t === '') return null;
  $s = one_('SELECT * FROM sessions WHERE token_hash = ?', [sha($t)]); if (!$s) return null;
  if ($s['expires_at'] < now_()) { run_('DELETE FROM sessions WHERE token_hash = ?', [$s['token_hash']]); return null; }
  $u = one_('SELECT id,username,name,email,role,active FROM users WHERE id = ?', [$s['user_id']]);
  if (!$u || !$u['active']) return null;
  $r = val_('SELECT permissions FROM roles WHERE name = ?', [$u['role']]);
  $u['id'] = (int) $u['id']; $u['active'] = (int) $u['active'];
  return ['user' => $u, 'csrf' => $s['csrf'], 'perms' => $r ? jdec($r, []) : []];
}
function throttleWait(string $k): int { $r = one_('SELECT * FROM throttle WHERE k = ?', [$k]); if ($r && $r['until_at'] > time()) return (int) ceil(($r['until_at'] - time()) / 60); return 0; }
function throttleFail(string $k): void {
  $t = time(); $r = one_('SELECT * FROM throttle WHERE k = ?', [$k]); $n = 0; $first = $t;
  if ($r && $t - $r['first_at'] <= 900) { $n = (int) $r['n']; $first = (int) $r['first_at']; }
  $n++; $until = $n >= 6 ? $t + 900 : 0;
  run_('INSERT INTO throttle(k,n,first_at,until_at) VALUES(?,?,?,?) ON CONFLICT(k) DO UPDATE SET n=excluded.n, first_at=excluded.first_at, until_at=excluded.until_at', [$k, $n, $first, $until]);
}
function throttleClear(string $k): void { run_('DELETE FROM throttle WHERE k = ?', [$k]); }
function rateLimit(string $key, int $max, int $windowSec): void {
  $k = clientIp() . '|' . $key; $t = time();
  run_('DELETE FROM ratelimit WHERE at < ?', [$t - 3600]);
  if ((int) val_('SELECT COUNT(*) FROM ratelimit WHERE k = ? AND at > ?', [$k, $t - $windowSec]) >= $max) throw new HttpErr(429, 'Too many requests. Please try again in a few minutes.');
  run_('INSERT INTO ratelimit(k,at) VALUES(?,?)', [$k, $t]);
}
function newOrderCode(): string { for ($i = 0; $i < 20; $i++) { $c = 'CE-' . random_int(100000, 999999); if (!val_('SELECT id FROM orders WHERE code = ?', [$c])) return $c; } throw new RuntimeException('Could not allocate order code'); }

// ---------------------------------------------------------------- tiny router
class Router {
  public array $routes = [];
  function add(string $method, string $pattern, callable $fn, ?string $perm = null): void { $this->routes[] = [$method, $pattern, $fn, $perm]; }
  function match(string $method, string $path): ?array {
    foreach ($this->routes as [$m, $pat, $fn, $perm]) {
      if ($m !== $method) continue;
      $re = '#^' . preg_replace('#:(\w+)#', '(?P<$1>[^/]+)', $pat) . '$#';
      if (preg_match($re, $path, $mm)) { $params = array_filter($mm, 'is_string', ARRAY_FILTER_USE_KEY); return [$fn, $params, $perm]; }
    }
    return null;
  }
}
function sendJson($data, int $status = 200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo jenc($data); exit; }
