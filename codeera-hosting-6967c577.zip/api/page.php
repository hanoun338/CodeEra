<?php
// Serves the React app (app.html) with SEO tags from the dashboard, plus robots.txt and sitemap.xml.
declare(strict_types=1);
function siteOrigin(array $seo): string { $o = $seo['siteUrl'] ?: ((isHttps() ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')); return rtrim($o, '/'); }
function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function securityHeaders(): void {
  header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: strict-origin-when-cross-origin'); header('X-Frame-Options: SAMEORIGIN');
  header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; frame-src 'self' https:; frame-ancestors 'self'; base-uri 'self'; object-src 'none'; form-action 'self'");
  if (isHttps()) header('Strict-Transport-Security: max-age=31536000');
}
function servePage(string $path): never {
  securityHeaders();
  if ($path === '/robots.txt') {
    $seo = getSetting('seo'); $o = siteOrigin($seo); header('Content-Type: text/plain; charset=utf-8');
    $lines = ['User-agent: *', $seo['robotsIndex'] ? 'Allow: /' : 'Disallow: /', 'Disallow: /admin', 'Disallow: /api/', $seo['robotsExtra'] ?? '', $seo['sitemapEnabled'] ? "Sitemap: $o/sitemap.xml" : ''];
    echo implode("\n", array_filter($lines, fn($x) => $x !== '')) . "\n"; exit;
  }
  if ($path === '/sitemap.xml') {
    $seo = getSetting('seo'); if (!$seo['sitemapEnabled'] || !$seo['robotsIndex']) { http_response_code(404); echo 'Sitemap disabled'; exit; }
    $o = siteOrigin($seo); header('Content-Type: application/xml; charset=utf-8'); $x = fn($s) => str_replace(['&', '<'], ['&amp;', '&lt;'], $s);
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n<url><loc>" . $x($o) . "/</loc></url>\n";
    foreach (all_("SELECT slug, updated_at FROM products WHERE status='published' AND visibility='public'") as $p) echo '<url><loc>' . $x($o) . '/website/' . $x($p['slug']) . '</loc><lastmod>' . substr($p['updated_at'], 0, 10) . "</lastmod></url>\n";
    echo "</urlset>\n"; exit;
  }
  $file = dirname(__DIR__) . '/app.html';
  if (!is_file($file)) { http_response_code(503); header('Content-Type: text/plain'); echo 'app.html is missing. Upload every file from the CodeEra package.'; exit; }
  $seo = getSetting('seo'); $gen = getSetting('general'); $isAdmin = str_starts_with($path, '/admin');
  $title = $seo['siteTitle']; $desc = $seo['description']; $image = $seo['ogImage'];
  if (preg_match('#^/website/([^/]+)#', $path, $m)) { $p = one_("SELECT name,seo_title,seo_desc,short_desc,thumbnail FROM products WHERE slug=? AND status='published'", [urldecode($m[1])]); if ($p) { $title = $p['seo_title'] ?: str_replace('%s', $p['name'], $seo['titleTemplate']); $desc = $p['seo_desc'] ?: ($p['short_desc'] ?: $desc); $image = $p['thumbnail'] ?: $image; } }
  $robots = ($isAdmin || !$seo['robotsIndex']) ? 'noindex, nofollow' : 'index, follow';
  $tags = ['<title>' . esc($isAdmin ? 'CodeEra Admin' : $title) . '</title>', '<meta name="description" content="' . esc($desc) . '">', '<meta name="robots" content="' . $robots . '">',
    '<meta property="og:title" content="' . esc($seo['ogTitle'] ?: $title) . '">', '<meta property="og:description" content="' . esc($seo['ogDescription'] ?: $desc) . '">', '<meta property="og:type" content="website">',
    $image ? '<meta property="og:image" content="' . esc($image) . '">' : '', '<meta name="twitter:card" content="' . esc($seo['twitterCard']) . '">', !empty($gen['favicon']) ? '<link rel="icon" href="' . esc($gen['favicon']) . '">' : ''];
  $html = file_get_contents($file); $html = preg_replace('#<title>.*?</title>#s', '', $html); $html = str_replace('</head>', '    ' . implode("\n    ", array_filter($tags)) . "\n  </head>", $html);
  header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); echo $html; exit;
}
