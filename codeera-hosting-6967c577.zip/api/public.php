<?php
// Public (visitor) API: catalog, config, orders, messages, reviews.
declare(strict_types=1);
const PUB_JSON = ['gallery', 'features', 'technologies', 'tags', 'pages', 'customization', 'included', 'faq'];
function pubProduct(array $p): array { $x = parseRow($p, PUB_JSON, ['featured', 'concept']); $x['sale'] = ($x['discount_price'] !== null && $x['discount_price'] < $x['price']) ? $x['discount_price'] : null; return $x; }
function applyCoupon($code, array $product): array {
  $c = one_('SELECT * FROM coupons WHERE code=?', [trim((string) $code)]); $base = $product['discount_price'] ?? $product['price'];
  if (!$c || !$c['active']) return ['error' => 'This coupon code is not valid.'];
  if ($c['expires_at'] && $c['expires_at'] < substr(now_(), 0, 10)) return ['error' => 'This coupon has expired.'];
  if ($c['usage_limit'] !== null && $c['used'] >= $c['usage_limit']) return ['error' => 'This coupon has reached its usage limit.'];
  if ($base < $c['min_purchase']) return ['error' => 'Minimum purchase for this coupon is ' . ($c['min_purchase'] + 0) . '.'];
  $ids = jdec($c['product_ids'], []); if ($ids && !in_array((int) $product['id'], array_map('intval', $ids), true)) return ['error' => 'This coupon does not apply to this website.'];
  $discount = min($base, $c['type'] === 'percent' ? round($base * $c['value']) / 100 : $c['value']);
  return ['coupon' => $c, 'discount' => $discount, 'total' => max(0, round(($base - $discount) * 100) / 100)];
}
function publicRoutes(): Router {
  $r = new Router();
  $r->add('GET', '/config', function () {
    $g = getSetting('general'); $hp = getSetting('homepage'); $ap = getSetting('appearance'); $seo = getSetting('seo');
    $stats = []; foreach ($hp['statistics']['items'] ?? [] as $it) { $src = $it['source'] ?? '';
      $v = $src === 'products' ? (int) val_("SELECT COUNT(*) FROM products WHERE status='published' AND visibility='public'") : ($src === 'customers' ? (int) val_('SELECT COUNT(*) FROM customers') : ($src === 'orders_completed' ? (int) val_("SELECT COUNT(*) FROM orders WHERE status='completed'") : (is_numeric($it['value'] ?? null) ? $it['value'] + 0 : 0)));
      $stats[] = ['label' => $it['label'] ?? '', 'value' => $v]; }
    $approved = all_("SELECT r.name,r.rating,r.text,p.name product FROM reviews r LEFT JOIN products p ON p.id=r.product_id WHERE r.status='approved' ORDER BY r.created_at DESC LIMIT 6");
    unset($g['emailConfig']); $hp['statistics']['items'] = $stats;
    $hp['testimonialList'] = !empty($hp['testimonials']['enabled']) ? array_merge(!empty($hp['testimonials']['useApprovedReviews']) ? $approved : [], $hp['testimonials']['manual'] ?? []) : [];
    return ['general' => $g, 'homepage' => $hp, 'appearance' => $ap, 'seo' => ['siteTitle' => $seo['siteTitle'], 'ogImage' => $seo['ogImage']], 'categories' => all_('SELECT id,name,name_ar,slug,description,icon FROM categories WHERE visible=1 ORDER BY sort,id')];
  });
  $r->add('GET', '/products', fn() => array_map('pubProduct', all_("SELECT p.*, c.name category_name, c.slug category_slug, (SELECT ROUND(AVG(rating),1) FROM reviews v WHERE v.product_id=p.id AND v.status='approved') rating, (SELECT COUNT(*) FROM reviews v WHERE v.product_id=p.id AND v.status='approved') review_count FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='published' AND p.visibility='public' AND (c.id IS NULL OR c.visible=1) ORDER BY p.featured DESC, p.sort, p.id")));
  $r->add('GET', '/products/:slug', function ($p) {
    $x = one_("SELECT p.*, c.name category_name, c.slug category_slug FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.slug=? AND p.status='published'", [urldecode($p['slug'])]); if (!$x) throw notFound('Website not found.');
    return pubProduct($x) + ['reviews' => all_("SELECT name,rating,text,reply,created_at FROM reviews WHERE product_id=? AND status='approved' ORDER BY created_at DESC LIMIT 20", [$x['id']])];
  });
  $r->add('POST', '/track', function () {
    rateLimit('track', 120, 600); $b = bodyIn(); $pid = !empty($b['productId']) ? (int) $b['productId'] : 0;
    if ($pid && !val_('SELECT id FROM products WHERE id=?', [$pid])) return ['ok' => true];
    run_('INSERT INTO views(day,product_id,count) VALUES(?,?,1) ON CONFLICT(day,product_id) DO UPDATE SET count=count+1', [substr(now_(), 0, 10), $pid]); return ['ok' => true];
  });
  $r->add('POST', '/coupon/check', function () {
    rateLimit('coupon', 30, 600); $b = bodyIn(); $p = one_("SELECT * FROM products WHERE id=? AND status='published'", [(int) ($b['productId'] ?? 0)]); if (!$p) throw notFound();
    $o = applyCoupon($b['code'] ?? '', $p); if (isset($o['error'])) throw bad($o['error']); return ['discount' => $o['discount'], 'total' => $o['total']];
  });
  $r->add('POST', '/orders', function () {
    rateLimit('orders', 8, 3600); $b = bodyIn(); if (!empty($b['website'])) return ['ok' => true];
    $p = one_("SELECT * FROM products WHERE id=? AND status='published' AND availability='available'", [(int) ($b['productId'] ?? 0)]); if (!$p) throw bad('This website is not available to order.');
    $name = vstr($b['name'] ?? null, ['required' => true, 'max' => 100, 'label' => 'Name']); $email = vemail($b['email'] ?? null); $phone = vstr($b['phone'] ?? null, ['max' => 40]);
    if ($email === '' && $phone === '') throw bad('Add an email or a phone / WhatsApp number so we can reach you.');
    $amount = $p['discount_price'] ?? $p['price']; $discount = 0; $couponCode = null; $coupon = null;
    if (!empty($b['coupon'])) { $c = applyCoupon($b['coupon'], $p); if (isset($c['error'])) throw bad($c['error']); $amount = $c['total']; $discount = $c['discount']; $couponCode = $c['coupon']['code']; $coupon = $c['coupon']; }
    $methods = array_values(array_map(fn($m) => $m['id'], array_filter(getSetting('general')['paymentMethods'], fn($m) => !empty($m['enabled']))));
    $pm = in_array($b['paymentMethod'] ?? null, $methods, true) ? $b['paymentMethod'] : ($methods[0] ?? null); $t = now_();
    $code = tx(function () use ($p, $name, $email, $phone, $amount, $discount, $couponCode, $coupon, $pm, $t, $b) {
      $cid = ($email !== '' ? val_('SELECT id FROM customers WHERE email=?', [$email]) : null) ?: ($phone !== '' ? val_('SELECT id FROM customers WHERE phone=?', [$phone]) : null);
      if ($cid) run_('UPDATE customers SET last_activity=? WHERE id=?', [$t, $cid]); else $cid = run_('INSERT INTO customers(name,email,phone,created_at,last_activity) VALUES(?,?,?,?,?)', [$name, $email, $phone, $t, $t]);
      $code = newOrderCode();
      run_('INSERT INTO orders(code,customer_id,product_id,product_name,category_id,purchase_type,amount,discount,coupon_code,payment_method,customization,history,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [$code, $cid, $p['id'], $p['name'], $p['category_id'], $p['purchase_type'], $amount, $discount, $couponCode, $pm, vstr($b['customization'] ?? null, ['max' => 3000]), jenc([['at' => $t, 'by' => 'customer', 'text' => 'Order requested on the website']]), $t, $t]);
      if ($coupon) run_('UPDATE coupons SET used=used+1 WHERE id=?', [$coupon['id']]);
      return $code;
    });
    run_('INSERT INTO activity(username,action,entity,entity_id,details,created_at) VALUES(?,?,?,?,?,?)', ['customer', 'order.requested', 'order', $code, $p['name'], $t]);
    return created(['code' => $code, 'amount' => $amount]);
  });
  $r->add('POST', '/messages', function () {
    rateLimit('messages', 8, 3600); $b = bodyIn(); if (!empty($b['website'])) return ['ok' => true];
    $type = in_array($b['type'] ?? null, ['contact', 'custom_request', 'support', 'whatsapp'], true) ? $b['type'] : 'contact'; $email = vemail($b['email'] ?? null); $phone = vstr($b['phone'] ?? null, ['max' => 40]);
    if ($email === '' && $phone === '') throw bad('Add an email or a phone / WhatsApp number so we can reply.');
    $id = run_('INSERT INTO messages(type,name,email,phone,subject,body,project_type,budget,created_at) VALUES(?,?,?,?,?,?,?,?,?)', [$type, vstr($b['name'] ?? null, ['required' => true, 'max' => 100, 'label' => 'Name']), $email, $phone, vstr($b['subject'] ?? null, ['max' => 150]), vstr($b['message'] ?? null, ['required' => true, 'min' => 5, 'max' => 4000, 'label' => 'Message']), vstr($b['projectType'] ?? null, ['max' => 80]), vstr($b['budget'] ?? null, ['max' => 60]), now_()]);
    return created(['ok' => true, 'id' => $id]);
  });
  $r->add('POST', '/reviews', function () {
    rateLimit('reviews', 5, 3600); $b = bodyIn(); if (!empty($b['website'])) return ['ok' => true];
    $pid = val_("SELECT id FROM products WHERE id=? AND status='published'", [(int) ($b['productId'] ?? 0)]); if (!$pid) throw notFound();
    run_("INSERT INTO reviews(product_id,name,rating,text,status,created_at) VALUES(?,?,?,?,'pending',?)", [$pid, vstr($b['name'] ?? null, ['required' => true, 'max' => 80, 'label' => 'Name']), vnum($b['rating'] ?? null, ['min' => 1, 'max' => 5, 'required' => true, 'label' => 'Rating']), vstr($b['text'] ?? null, ['required' => true, 'min' => 5, 'max' => 2000, 'label' => 'Review']), now_()]);
    return created(['ok' => true, 'message' => 'Thanks! Your review will appear after it is approved.']);
  });
  return $r;
}
