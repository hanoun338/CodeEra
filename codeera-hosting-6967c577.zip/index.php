<?php
// Front controller: robots.txt, sitemap.xml and the React app (with SEO tags). Real files (assets, uploads) are served by the web server directly.
declare(strict_types=1);
require __DIR__ . '/api/lib.php'; require __DIR__ . '/api/page.php';
ini_set('display_errors', '0');
try { servePage(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'); }
catch (Throwable $e) { error_log('CodeEra: ' . $e->getMessage()); http_response_code(500); header('Content-Type: text/plain'); echo 'The site could not start. Check that the data folder is writable (see README).'; }
