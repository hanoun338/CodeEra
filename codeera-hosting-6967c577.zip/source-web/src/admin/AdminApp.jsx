import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Routes, Route, NavLink, Navigate, useNavigate, useLocation, Link } from 'react-router-dom';
import { api, setCsrf } from '../api.js';
import { AR } from './i18n.js';
import { AdminCtx, useAdmin, Icon, useOverlays, Skeleton, ErrorState, Btn, useFetch, useDebounced } from './ui.jsx';
import { Overview } from './pOverview.jsx';
import { Products, Categories } from './pCatalog.jsx';
import { Orders, Customers } from './pOrders.jsx';
import { Analytics, Coupons, Reviews, Messages } from './pSales.jsx';
import { HomepageEditor, MediaLibrary, SeoSettings, AppearanceSettings, GeneralSettings } from './pSite.jsx';
import { UsersPage, Logs } from './pUsers.jsx';
import './admin.css';

const NAV = [
  { path: '', label: 'Overview', icon: 'grid', area: null },
  { path: 'websites', label: 'Websites', icon: 'globe', area: 'products' },
  { path: 'categories', label: 'Categories', icon: 'tag', area: 'categories' },
  { path: 'orders', label: 'Orders', icon: 'cart', area: 'orders', badge: 'orders' },
  { path: 'customers', label: 'Customers', icon: 'users', area: 'customers' },
  { path: 'analytics', label: 'Sales & Analytics', icon: 'chart', area: 'analytics' },
  { path: 'coupons', label: 'Coupons & Offers', icon: 'coupon', area: 'coupons' },
  { path: 'reviews', label: 'Reviews', icon: 'star', area: 'reviews', badge: 'reviews' },
  { path: 'messages', label: 'Messages & Inquiries', icon: 'mail', area: 'messages', badge: 'messages' },
  { path: 'homepage', label: 'Homepage Editor', icon: 'layout', area: 'homepage' },
  { path: 'media', label: 'Media Library', icon: 'image', area: 'media' },
  { path: 'seo', label: 'SEO Settings', icon: 'search', area: 'seo' },
  { path: 'appearance', label: 'Appearance & Theme', icon: 'palette', area: 'appearance' },
  { path: 'settings', label: 'General Settings', icon: 'cog', area: 'settings' },
  { path: 'users', label: 'Users & Permissions', icon: 'shield', area: 'users' },
  { path: 'logs', label: 'Activity Logs', icon: 'list', area: 'logs' },
];

function AuthScreen({ needsSetup, onDone, t, lang, setLang }) {
  const [f, setF] = useState({ username: '', name: '', password: '', confirm: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { const r = await api.post(needsSetup ? '/api/auth/setup' : '/api/auth/login', f); setCsrf(r.csrf); onDone(); } catch (er) { setErr(er.message); setBusy(false); }
  };
  return (
    <div className="auth">
      <form className="auth-card card" onSubmit={submit}>
        <div className="brand big">Code<span>Era</span></div>
        <h1>{needsSetup ? t('Welcome to CodeEra') : t('Sign in to the CodeEra dashboard')}</h1>
        {needsSetup && <p className="muted">{t('Create the first administrator account')}. You choose the username and password here. They are stored hashed on your server and nowhere else.</p>}
        <div className="fld"><label htmlFor="u">{t('Username')}</label><input id="u" value={f.username} onChange={set('username')} autoComplete="username" autoFocus required /></div>
        {needsSetup && <div className="fld"><label htmlFor="n">{t('Name')}</label><input id="n" value={f.name} onChange={set('name')} autoComplete="name" /></div>}
        <div className="fld"><label htmlFor="p">{t('Password')}</label><input id="p" type="password" value={f.password} onChange={set('password')} autoComplete={needsSetup ? 'new-password' : 'current-password'} required /></div>
        {needsSetup && <><div className="fld"><label htmlFor="c">{t('Confirm password')}</label><input id="c" type="password" value={f.confirm} onChange={set('confirm')} autoComplete="new-password" required /><small className="muted">At least 10 characters, with letters and numbers.</small></div></>}
        {err && <p className="err-t" role="alert">{err}</p>}
        <Btn kind="primary" type="submit" busy={busy}>{busy ? t('Loading…') : needsSetup ? t('Create administrator') : t('Sign in')}</Btn>
        <button type="button" className="link-btn" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{lang === 'ar' ? 'English' : 'العربية'}</button>
      </form>
    </div>
  );
}

function Search({ go }) {
  const { t } = useAdmin(); const [q, setQ] = useState(''); const d = useDebounced(q); const [res, setRes] = useState([]); const [open, setOpen] = useState(false);
  useEffect(() => { if (d.length < 2) { setRes([]); return; } api.get('/api/admin/search', { q: d }).then((r) => setRes(r.results)).catch(() => setRes([])); }, [d]);
  const route = { products: 'websites', orders: 'orders', customers: 'customers', messages: 'messages' };
  return (
    <div className="gsearch" onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOpen(false); }}>
      <Icon n="search" /><input type="search" value={q} placeholder={t('Search everything')} aria-label={t('Search everything')} onFocus={() => setOpen(true)} onChange={(e) => { setQ(e.target.value); setOpen(true); }} />
      {open && q.length >= 2 && <div className="gs-pop">{res.length === 0 ? <p className="muted pad">No matches.</p> : res.map((r) => <button key={r.type + r.id} onClick={() => { go(`/admin/${route[r.type]}?open=${r.id}`); setOpen(false); setQ(''); }}><span className="gs-t">{r.type}</span>{r.title}{r.sub && <small className="muted"> · {r.sub}</small>}</button>)}</div>}
    </div>
  );
}

function Shell({ session, onLogout }) {
  const { t, lang, setLang, theme, setTheme, can, badges, user } = useAdmin(); const nav = useNavigate(); const loc = useLocation();
  const [open, setOpen] = useState(false); const [collapsed, setCollapsed] = useState(() => localStorage.getItem('ce-adm-collapsed') === '1');
  useEffect(() => setOpen(false), [loc.pathname]);
  const items = NAV.filter((n) => !n.area || can(n.area + '.view'));
  const cur = items.find((n) => n.path && loc.pathname.startsWith('/admin/' + n.path)) || items[0];
  const guard = (area, el) => (can(area + '.view') ? el : <div className="card pad"><ErrorState error="You do not have permission to view this page." /></div>);
  return (
    <div className={'shell' + (collapsed ? ' collapsed' : '') + (open ? ' open' : '')}>
      <aside className="side" aria-label="Main navigation">
        <div className="side-top"><Link to="/admin" className="brand">Code<span>Era</span></Link><button className="icon-btn only-m" onClick={() => setOpen(false)} aria-label={t('Close')}><Icon n="x" /></button></div>
        <nav>{items.map((n) => <NavLink key={n.path} to={'/admin' + (n.path ? '/' + n.path : '')} end={!n.path} className={({ isActive }) => 'nav-i' + (isActive ? ' on' : '')} title={t(n.label)}><Icon n={n.icon} /><span className="nav-l">{t(n.label)}</span>{badges[n.badge] > 0 && <b className="nbadge">{badges[n.badge]}</b>}</NavLink>)}</nav>
        <button className="nav-i collapse" onClick={() => { const v = !collapsed; setCollapsed(v); localStorage.setItem('ce-adm-collapsed', v ? '1' : '0'); }} aria-label={t('Collapse')}><Icon n="chevron" /><span className="nav-l">{t('Collapse')}</span></button>
      </aside>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}
      <div className="main">
        <header className="top">
          <button className="icon-btn only-m" onClick={() => setOpen(true)} aria-label={t('Menu')}><Icon n="menu" /></button>
          <Search go={nav} />
          <div className="grow" />
          <a className="btn sm hide-s" href="/" target="_blank" rel="noopener noreferrer"><Icon n="globe" size={15} />{t('View site')}</a>
          <button className="icon-btn" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} aria-label={t('Language')} title={t('Language')}><span className="lang-b">{lang === 'ar' ? 'EN' : 'ع'}</span></button>
          <button className="icon-btn" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={theme === 'dark' ? t('Light mode') : t('Dark mode')} title={theme === 'dark' ? t('Light mode') : t('Dark mode')}><Icon n={theme === 'dark' ? 'sun' : 'moon'} /></button>
          <div className="me"><span className="avatar">{(user.name || user.username)[0].toUpperCase()}</span><div className="me-t hide-s"><b>{user.name || user.username}</b><small>{user.role.replace('_', ' ')}</small></div></div>
          <button className="icon-btn" onClick={onLogout} aria-label={t('Sign out')} title={t('Sign out')}><Icon n="out" /></button>
        </header>
        <main className="content" id="content" key={loc.pathname}>
          <Routes>
            <Route index element={<Overview />} />
            <Route path="websites" element={guard('products', <Products />)} />
            <Route path="categories" element={guard('categories', <Categories />)} />
            <Route path="orders" element={guard('orders', <Orders />)} />
            <Route path="customers" element={guard('customers', <Customers />)} />
            <Route path="analytics" element={guard('analytics', <Analytics />)} />
            <Route path="coupons" element={guard('coupons', <Coupons />)} />
            <Route path="reviews" element={guard('reviews', <Reviews />)} />
            <Route path="messages" element={guard('messages', <Messages />)} />
            <Route path="homepage" element={guard('homepage', <HomepageEditor />)} />
            <Route path="media" element={guard('media', <MediaLibrary />)} />
            <Route path="seo" element={guard('seo', <SeoSettings />)} />
            <Route path="appearance" element={guard('appearance', <AppearanceSettings />)} />
            <Route path="settings" element={guard('settings', <GeneralSettings />)} />
            <Route path="users" element={guard('users', <UsersPage />)} />
            <Route path="logs" element={guard('logs', <Logs />)} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function AdminApp() {
  const [lang, setLangS] = useState(() => localStorage.getItem('ce-adm-lang') || 'en');
  const [theme, setThemeS] = useState(() => localStorage.getItem('ce-adm-theme') || 'dark');
  const [phase, setPhase] = useState('loading'); const [session, setSession] = useState(null); const [badges, setBadges] = useState({}); const [currency, setCurrency] = useState({ symbol: '$', code: 'USD' }); const [err, setErr] = useState('');
  const ov = useOverlays();
  const setLang = (l) => { setLangS(l); localStorage.setItem('ce-adm-lang', l); };
  const setTheme = (v) => { setThemeS(v); localStorage.setItem('ce-adm-theme', v); };
  const t = useCallback((s) => (lang === 'ar' && AR[s]) || s, [lang]);

  const boot = useCallback(async () => {
    try {
      const st = await api.get('/api/auth/status');
      if (st.needsSetup) { setPhase('setup'); return; }
      if (!st.signedIn) { setPhase('login'); return; }
      const me = await api.get('/api/admin/me'); setCsrf(me.csrf); setSession(me);
      try { const g = await api.get('/api/admin/settings/general'); setCurrency({ symbol: g.currencySymbol || '$', code: g.currency }); } catch { /* user may not see settings */ }
      setPhase('app');
    } catch (e) { setErr(e.message); setPhase('error'); }
  }, []);
  useEffect(() => { boot(); }, [boot]);
  useEffect(() => { const f = () => { setSession(null); setPhase('login'); }; window.addEventListener('ce-unauth', f); return () => window.removeEventListener('ce-unauth', f); }, []);
  useEffect(() => { document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; document.documentElement.lang = lang; return () => { document.documentElement.dir = 'ltr'; }; }, [lang]);
  const refreshBadges = useCallback(() => api.get('/api/admin/badges').then(setBadges).catch(() => {}), []);
  useEffect(() => { if (phase !== 'app') return; refreshBadges(); const i = setInterval(refreshBadges, 30000); return () => clearInterval(i); }, [phase, refreshBadges]);
  const logout = async () => { try { await api.post('/api/auth/logout'); } catch { /* ignore */ } setCsrf(''); setSession(null); setPhase('login'); };

  const ctx = useMemo(() => session && ({ t, lang, setLang, theme, setTheme, user: session.user, perms: session.permissions, can: (p) => session.permissions.includes(p), toast: ov.toast, confirm: ov.confirm, badges, refreshBadges, currency }), [t, lang, theme, session, ov.toast, ov.confirm, badges, refreshBadges, currency]); // eslint-disable-line
  const authCtx = { t, lang, setLang, theme, toast: ov.toast, confirm: ov.confirm };
  return (
    <div className={'adm ' + (theme === 'light' ? 'light' : 'dark')} dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      {phase === 'loading' && <div className="boot"><Skeleton rows={3} /></div>}
      {phase === 'error' && <div className="boot"><ErrorState error={err} onRetry={() => { setPhase('loading'); boot(); }} /></div>}
      {(phase === 'setup' || phase === 'login') && <AdminCtx.Provider value={authCtx}><AuthScreen needsSetup={phase === 'setup'} onDone={boot} t={t} lang={lang} setLang={setLang} /></AdminCtx.Provider>}
      {phase === 'app' && ctx && <AdminCtx.Provider value={ctx}><Shell session={session} onLogout={logout} />{ov.node}</AdminCtx.Provider>}
    </div>
  );
}
