import React, { useEffect, useRef, useState } from 'react';

const PL = 46, PR = 12, PT = 12, PB = 26;
const niceMax = (m) => { if (m <= 0) return 1; const p = 10 ** Math.floor(Math.log10(m)); const n = m / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p; };
const short = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(n >= 1e4 ? 0 : 1) + 'k' : String(Math.round(n * 10) / 10));

// data: [{ x: '2026-11-01', a: 10, b: 4 }]; lines: [{ key:'a', color, label, area? }]
export function LineChart({ data, lines, format = (v) => v, height = 230 }) {
  const [hover, setHover] = useState(null); const box = useRef(null); const [W, setW] = useState(640); const H = height - (lines.length > 1 ? 26 : 0);
  useEffect(() => { const el = box.current; if (!el) return; const ro = new ResizeObserver(() => setW(Math.max(280, Math.round(el.getBoundingClientRect().width)))); ro.observe(el); setW(Math.max(280, Math.round(el.getBoundingClientRect().width))); return () => ro.disconnect(); }, []);
  const n = data.length; const max = niceMax(Math.max(0, ...data.flatMap((d) => lines.map((l) => d[l.key] || 0))));
  const x = (i) => PL + (n <= 1 ? (W - PL - PR) / 2 : (i * (W - PL - PR)) / (n - 1)); const y = (v) => PT + (H - PT - PB) * (1 - v / max);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => t * max);
  const labelEvery = Math.max(1, Math.ceil(n / 7));
  const move = (e) => { const r = e.currentTarget.getBoundingClientRect(); const px = ((e.clientX - r.left) / r.width) * W; setHover(Math.max(0, Math.min(n - 1, Math.round(((px - PL) / (W - PL - PR)) * (n - 1))))); };
  if (!n) return null;
  return (
    <div className="chart" ref={box}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} onMouseMove={move} onMouseLeave={() => setHover(null)} role="img" aria-label="Line chart">
        {ticks.map((t) => <g key={t}><line x1={PL} x2={W - PR} y1={y(t)} y2={y(t)} className="grid" /><text x={PL - 6} y={y(t) + 4} textAnchor="end" className="axis">{short(t)}</text></g>)}
        {data.map((d, i) => i % labelEvery === 0 && <text key={i} x={x(i)} y={H - 6} textAnchor="middle" className="axis">{String(d.x).slice(5)}</text>)}
        {lines.map((l) => {
          const pts = data.map((d, i) => `${x(i)},${y(d[l.key] || 0)}`).join(' ');
          return <g key={l.key}>
            {l.area && <polygon points={`${x(0)},${y(0)} ${pts} ${x(n - 1)},${y(0)}`} fill={l.color} opacity=".12" />}
            <polyline points={pts} fill="none" stroke={l.color} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" strokeDasharray={l.dash} />
            {hover != null && <circle cx={x(hover)} cy={y(data[hover][l.key] || 0)} r="4" fill={l.color} />}
          </g>;
        })}
        {hover != null && <line x1={x(hover)} x2={x(hover)} y1={PT} y2={H - PB} className="cross" />}
      </svg>
      {hover != null && <div className="tip" style={{ left: Math.min(78, Math.max(8, (x(hover) / W) * 100)) + '%' }}><b>{data[hover].x}</b>{lines.map((l) => <div key={l.key}><i style={{ background: l.color }} />{l.label}: {format(data[hover][l.key] || 0, l.key)}</div>)}</div>}
      {lines.length > 1 && <div className="legend">{lines.map((l) => <span key={l.key}><i style={{ background: l.color }} />{l.label}</span>)}</div>}
    </div>
  );
}

export function BarList({ items, format = (v) => v, color = 'var(--c2)', empty = 'No data in this range.' }) {
  const max = Math.max(0, ...items.map((i) => i.value));
  if (!items.length) return <p className="muted pad">{empty}</p>;
  return <div className="barlist">{items.map((i) => <div key={i.name} className="bl-row"><span className="bl-n" title={i.name}>{i.name}</span><div className="bl-bar"><i style={{ width: (max ? (i.value / max) * 100 : 0) + '%', background: color }} /></div><b>{format(i.value)}</b></div>)}</div>;
}

const PAL = ['#1677FF', '#28D9FF', '#C8A45D', '#7c5cff', '#2ecf8f', '#ff6b8b', '#f59e0b', '#8fa2c2'];
export function Donut({ items, format = (v) => v, empty = 'No data in this range.' }) {
  const total = items.reduce((a, i) => a + i.value, 0);
  if (!total) return <p className="muted pad">{empty}</p>;
  let acc = 0; const R = 15.9155;
  return (
    <div className="donut">
      <svg viewBox="0 0 42 42" role="img" aria-label="Donut chart"><circle cx="21" cy="21" r={R} fill="none" stroke="var(--line)" strokeWidth="5" />
        {items.map((it, i) => { const pct = (it.value / total) * 100; const el = <circle key={it.name} cx="21" cy="21" r={R} fill="none" stroke={PAL[i % PAL.length]} strokeWidth="5" strokeDasharray={`${pct} ${100 - pct}`} strokeDashoffset={25 - acc} />; acc += pct; return el; })}</svg>
      <ul>{items.map((it, i) => <li key={it.name}><i style={{ background: PAL[i % PAL.length] }} />{it.name}<b>{format(it.value)}</b></li>)}</ul>
    </div>
  );
}
