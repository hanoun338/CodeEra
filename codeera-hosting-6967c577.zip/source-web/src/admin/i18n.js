// English is the source language. Arabic covers navigation, common actions, statuses and page titles.
// Strings without an Arabic entry fall back to English, so nothing breaks.
export const AR = {
  'Overview': 'نظرة عامة', 'Websites': 'المواقع', 'Categories': 'التصنيفات', 'Orders': 'الطلبات', 'Customers': 'العملاء', 'Sales & Analytics': 'المبيعات والتحليلات',
  'Coupons & Offers': 'الكوبونات والعروض', 'Reviews': 'التقييمات', 'Messages & Inquiries': 'الرسائل والاستفسارات', 'Homepage Editor': 'محرر الصفحة الرئيسية', 'Media Library': 'مكتبة الوسائط',
  'SEO Settings': 'إعدادات SEO', 'Appearance & Theme': 'المظهر والثيم', 'General Settings': 'الإعدادات العامة', 'Users & Permissions': 'المستخدمون والصلاحيات', 'Activity Logs': 'سجل النشاط',
  'Save': 'حفظ', 'Cancel': 'إلغاء', 'Delete': 'حذف', 'Edit': 'تعديل', 'Add': 'إضافة', 'Search': 'بحث', 'Search everything': 'ابحث في كل شيء', 'Status': 'الحالة', 'Actions': 'إجراءات', 'Name': 'الاسم',
  'Price': 'السعر', 'Date': 'التاريخ', 'Email': 'البريد الإلكتروني', 'Phone': 'الهاتف', 'Close': 'إغلاق', 'Loading…': 'جارٍ التحميل…', 'Retry': 'إعادة المحاولة', 'Sign out': 'تسجيل الخروج',
  'Sign in': 'تسجيل الدخول', 'Username': 'اسم المستخدم', 'Password': 'كلمة المرور', 'Confirm password': 'تأكيد كلمة المرور', 'Create administrator': 'إنشاء المدير',
  'Welcome to CodeEra': 'مرحبًا بك في CodeEra', 'Create the first administrator account': 'أنشئ حساب المدير الأول', 'Total websites': 'إجمالي المواقع', 'Published': 'منشور', 'Draft': 'مسودة',
  'Revenue': 'الإيرادات', 'Total orders': 'إجمالي الطلبات', 'Pending orders': 'طلبات معلقة', 'Page views': 'مشاهدات الصفحات', 'Conversion rate': 'معدل التحويل', 'Recent orders': 'أحدث الطلبات',
  'Recent activity': 'آخر النشاطات', 'Quick actions': 'إجراءات سريعة', 'Most viewed': 'الأكثر مشاهدة', 'Best selling': 'الأكثر مبيعًا', 'Add website': 'إضافة موقع', 'New': 'جديد',
  'Pending confirmation': 'بانتظار التأكيد', 'Awaiting payment': 'بانتظار الدفع', 'Processing': 'قيد التنفيذ', 'Completed': 'مكتمل', 'Cancelled': 'ملغي', 'Refunded': 'مسترد',
  'Paid': 'مدفوع', 'Unpaid': 'غير مدفوع', 'Order': 'الطلب', 'Customer': 'العميل', 'Website': 'الموقع', 'Amount': 'المبلغ', 'Payment': 'الدفع', 'Notes': 'ملاحظات', 'History': 'السجل',
  'Settings': 'الإعدادات', 'Light mode': 'الوضع الفاتح', 'Dark mode': 'الوضع الداكن', 'Language': 'اللغة', 'View site': 'عرض الموقع', 'Collapse': 'طي', 'Menu': 'القائمة',
  'Role': 'الدور', 'Users': 'المستخدمون', 'Roles & permissions': 'الأدوار والصلاحيات', 'Export CSV': 'تصدير CSV', 'Yes, delete': 'نعم، احذف', 'Are you sure?': 'هل أنت متأكد؟',
  'Saved': 'تم الحفظ', 'Saving…': 'جارٍ الحفظ…', 'Nothing here yet': 'لا يوجد شيء بعد', 'Featured': 'مميز', 'Duplicate': 'تكرار', 'Publish': 'نشر', 'Unpublish': 'إلغاء النشر',
  'Code': 'الكود', 'Type': 'النوع', 'Value': 'القيمة', 'Active': 'فعّال', 'Approve': 'قبول', 'Reject': 'رفض', 'Hide': 'إخفاء', 'Reply': 'رد', 'Priority': 'الأولوية', 'Unread': 'غير مقروء',
  'Upload': 'رفع', 'Folder': 'مجلد', 'Copy URL': 'نسخ الرابط', 'Appearance': 'المظهر', 'Action': 'الإجراء', 'User': 'المستخدم', 'Details': 'التفاصيل', 'Rows': 'صفوف', 'Page': 'صفحة', 'of': 'من',
  'Today': 'اليوم', 'Revenue over time': 'الإيرادات عبر الزمن', 'Orders over time': 'الطلبات عبر الزمن', 'Sales ranking': 'ترتيب المبيعات', 'Sales by category': 'المبيعات حسب التصنيف', 'Customer acquisition': 'اكتساب العملاء',
  'Total customers': 'إجمالي العملاء', 'Sales': 'المبيعات', 'Save changes': 'حفظ التغييرات', 'Unsaved changes': 'تغييرات غير محفوظة', 'All': 'الكل', 'Sign in to the CodeEra dashboard': 'سجّل الدخول إلى لوحة CodeEra',
};
