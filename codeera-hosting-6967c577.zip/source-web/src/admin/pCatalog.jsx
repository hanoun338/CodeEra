import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAdmin, useList, useFetch, DataTable, PageHead, Btn, Badge, FormModal, Icon, FilterSelect, useMoney, fmtDate, Empty, download } from './ui.jsx';

const ICONS = ['cart', 'globe', 'chart', 'layout', 'users', 'star', 'cog', 'tag', 'mail', 'image', 'home', 'trend'].map((i) => ({ value: i, label: i }));

export function Products() {
  const { t, can, toast, confirm, lang } = useAdmin(); const money = useMoney(); const [sp, setSp] = useSearchParams();
  const list = useList('/api/admin/products', { sort: 'created', dir: 'desc' }); const cats = useFetch('/api/admin/categories');
  const [form, setForm] = useState(null); const [sel, setSel] = useState([]); const edit = can('products.edit');
  useEffect(() => { if (sp.get('new') === '1' && edit) { setForm({}); setSp({}, { replace: true }); } else if (sp.get('open')) { openEdit(+sp.get('open')); setSp({}, { replace: true }); } }, []); // eslint-disable-line
  const openEdit = async (id) => { try { setForm(await api.get('/api/admin/products/' + id)); } catch (e) { toast(e.message, 'err'); } };
  const catOpts = (cats.data || []).map((c) => ({ value: c.id, label: c.name }));
  const fields = [
    { name: 'name', label: 'Name', required: true, half: true }, { name: 'slug', label: 'Slug', half: true, help: 'Leave blank to generate from the name.' },
    { name: 'category_id', label: 'Category', type: 'select', options: catOpts, placeholder: '— none —', half: true },
    { name: 'purchase_type', label: 'Purchase type', type: 'select', half: true, options: [{ value: 'license', label: 'Ready-made license' }, { value: 'customization', label: 'Customization' }, { value: 'source', label: 'Source code' }, { value: 'subscription', label: 'Subscription' }] },
    { name: 'short_desc', label: 'Short description', type: 'textarea', rows: 2 }, { name: 'full_desc', label: 'Full description', type: 'textarea', rows: 5 },
    { name: 'price', label: 'Price', type: 'number', required: true, half: true }, { name: 'discount_price', label: 'Sale price', type: 'number', half: true, help: 'Optional. Must be lower than the price.' },
    { name: 'thumbnail', label: 'Thumbnail', type: 'image', help: 'Leave empty to show the generated preview card.' }, { name: 'gallery', label: 'Gallery (one URL per line)', type: 'images' },
    { name: 'demo_url', label: 'Demo URL', half: true, placeholder: 'https://…', help: 'Empty = built-in demo preview.' }, { name: 'tags', label: 'Tags (one per line)', type: 'lines', half: true, rows: 2 },
    { name: 'features', label: 'Features (one per line)', type: 'lines', rows: 4 }, { name: 'technologies', label: 'Technologies (one per line)', type: 'lines', half: true }, { name: 'pages', label: 'Included pages (one per line)', type: 'lines', half: true },
    { name: 'customization', label: 'Customization options (one per line)', type: 'lines', half: true }, { name: 'included', label: "What's included (one per line)", type: 'lines', half: true },
    { name: 'faq', label: 'FAQ (one per line: question | answer)', type: 'faq' },
    { name: 'status', label: 'Status', type: 'select', half: true, options: [{ value: 'draft', label: 'Draft' }, { value: 'published', label: 'Published' }] },
    { name: 'availability', label: 'Availability', type: 'select', half: true, options: [{ value: 'available', label: 'Available' }, { value: 'sold_out', label: 'Sold out' }, { value: 'coming_soon', label: 'Coming soon' }] },
    { name: 'visibility', label: 'Visibility', type: 'select', half: true, options: [{ value: 'public', label: 'Public' }, { value: 'hidden', label: 'Hidden' }] },
    { name: 'featured', label: 'Featured', type: 'checkbox', half: true },
    { name: 'seo_title', label: 'SEO title', half: true }, { name: 'seo_desc', label: 'SEO description', half: true },
  ];
  const save = async (v) => {
    const body = { ...v, category_id: v.category_id || null };
    if (form.id) await api.put('/api/admin/products/' + form.id, body); else await api.post('/api/admin/products', body);
    toast('Saved'); setForm(null); list.reload();
  };
  const del = async (p) => { if (await confirm({ title: 'Delete website?', message: `"${p.name}" will be removed from the site. Past orders keep their record.` })) { try { await api.del('/api/admin/products/' + p.id); toast('Deleted'); list.reload(); } catch (e) { toast(e.message, 'err'); } } };
  const act = async (fn, msg) => { try { await fn(); toast(msg || 'Saved'); list.reload(); } catch (e) { toast(e.message, 'err'); } };
  const bulk = async (action) => {
    if (action === 'delete' && !(await confirm({ title: `Delete ${sel.length} website(s)?`, message: 'This cannot be undone.' }))) return;
    await act(() => api.post('/api/admin/products/bulk', { ids: sel, action })); setSel([]);
  };
  const cols = [
    { key: 'name', label: 'Website', sort: 'name', render: (p) => <div className="cell-main"><span className="thumb">{p.thumbnail ? <img src={p.thumbnail} alt="" /> : <Icon n="globe" />}</span><div><b>{p.name}</b><small className="muted block">/{p.slug}</small></div></div> },
    { key: 'cat', label: 'Category', render: (p) => p.category_name || '—' },
    { key: 'price', label: 'Price', sort: 'price', render: (p) => <>{money(p.discount_price ?? p.price)}{p.discount_price != null && <s className="muted"> {money(p.price)}</s>}</> },
    { key: 'status', label: 'Status', sort: 'status', render: (p) => <><Badge v={p.status} />{p.featured && <span className="bd bd-gold">★</span>}{p.visibility === 'hidden' && <Badge v="hidden" />}</> },
    { key: 'views', label: 'Views', sort: 'views', render: (p) => p.views }, { key: 'orders', label: 'Orders', render: (p) => p.orders_count },
    { key: 'a', label: 'Actions', stop: true, cls: 'acts', render: (p) => !edit ? null : <>
      <button className="icon-btn" title={p.status === 'published' ? t('Unpublish') : t('Publish')} aria-label={p.status === 'published' ? t('Unpublish') : t('Publish')} onClick={() => act(() => api.put('/api/admin/products/' + p.id, { ...p, status: p.status === 'published' ? 'draft' : 'published' }), p.status === 'published' ? 'Unpublished' : 'Published')}><Icon n="eye" /></button>
      <button className="icon-btn" title={t('Featured')} aria-label={t('Featured')} onClick={() => act(() => api.put('/api/admin/products/' + p.id, { ...p, featured: !p.featured }))}><Icon n="star" /></button>
      <button className="icon-btn" title={t('Duplicate')} aria-label={t('Duplicate')} onClick={() => act(() => api.post(`/api/admin/products/${p.id}/duplicate`), 'Duplicated as draft')}><Icon n="copy" /></button>
      <button className="icon-btn" title={t('Edit')} aria-label={t('Edit')} onClick={() => openEdit(p.id)}><Icon n="edit" /></button>
      <button className="icon-btn danger" title={t('Delete')} aria-label={t('Delete')} onClick={() => del(p)}><Icon n="trash" /></button></> },
  ];
  return (<>
    <PageHead title="Websites" sub="Everything you publish here appears on the public site.">
      <Btn icon="download" onClick={() => download('/api/admin/export/products.csv')}>{t('Export CSV')}</Btn>
      {edit && <Btn kind="primary" icon="plus" onClick={() => setForm({ status: 'draft', price: '' })}>{t('Add website')}</Btn>}
    </PageHead>
    {edit && sel.length > 0 && <div className="bulk card"><b>{sel.length} selected</b><Btn onClick={() => bulk('publish')}>{t('Publish')}</Btn><Btn onClick={() => bulk('unpublish')}>{t('Unpublish')}</Btn><Btn onClick={() => bulk('feature')}>{t('Featured')}</Btn><Btn kind="danger" icon="trash" onClick={() => bulk('delete')}>{t('Delete')}</Btn><button className="link-btn" onClick={() => setSel([])}>{t('Cancel')}</button></div>}
    <DataTable list={list} columns={cols} selectable={edit} selected={sel} onSelect={setSel} onRow={edit ? (p) => openEdit(p.id) : undefined}
      filters={<><FilterSelect list={list} name="status" label="Status" options={['published', 'draft']} /><FilterSelect list={list} name="category" label="Categories" options={catOpts} /><FilterSelect list={list} name="featured" label="Featured" options={[{ value: '1', label: 'Featured only' }]} /></>}
      empty={<Empty title="No websites yet" hint="Add your first website to show it on the public site." action={edit && <Btn kind="primary" icon="plus" onClick={() => setForm({})}>{t('Add website')}</Btn>} />} />
    {form && <FormModal wide title={form.id ? `${t('Edit')}: ${form.name}` : t('Add website')} fields={fields} initial={form} onSave={save} onClose={() => setForm(null)} />}
  </>);
}

export function Categories() {
  const { t, can, toast, confirm } = useAdmin(); const f = useFetch('/api/admin/categories'); const [form, setForm] = useState(null); const edit = can('categories.edit');
  const fields = [{ name: 'name', label: 'Name', required: true, half: true }, { name: 'name_ar', label: 'Arabic name', half: true }, { name: 'slug', label: 'Slug', half: true }, { name: 'sort', label: 'Order', type: 'number', half: true, default: 0 },
    { name: 'icon', label: 'Icon', type: 'select', options: ICONS, half: true }, { name: 'visible', label: 'Show on site', type: 'checkbox', half: true, default: true }, { name: 'description', label: 'Description', type: 'textarea', rows: 2 }];
  const save = async (v) => { if (form.id) await api.put('/api/admin/categories/' + form.id, v); else await api.post('/api/admin/categories', v); toast('Saved'); setForm(null); f.reload(); };
  const del = async (c) => { if (await confirm({ title: 'Delete category?', message: c.website_count ? `${c.website_count} website(s) will become uncategorised.` : `"${c.name}" will be removed.` })) { try { await api.del('/api/admin/categories/' + c.id); toast('Deleted'); f.reload(); } catch (e) { toast(e.message, 'err'); } } };
  const toggle = async (c) => { try { await api.put('/api/admin/categories/' + c.id, { ...c, visible: !c.visible }); f.reload(); } catch (e) { toast(e.message, 'err'); } };
  const rows = f.data || [];
  return (<>
    <PageHead title="Categories">{edit && <Btn kind="primary" icon="plus" onClick={() => setForm({ visible: true, icon: 'globe', sort: rows.length })}>{t('Add')}</Btn>}</PageHead>
    <div className="card tbl-card">
      {f.error ? <div className="empty err"><b>{f.error}</b><button className="btn" onClick={f.refetch}>{t('Retry')}</button></div> : !f.data ? <div className="skel-wrap"><div className="skel" /><div className="skel" /></div> : rows.length === 0 ? <Empty title="No categories" /> :
        <div className="tbl-scroll"><table className="tbl"><thead><tr><th>#</th><th>{t('Name')}</th><th>Slug</th><th>Websites</th><th>{t('Status')}</th><th className="acts">{t('Actions')}</th></tr></thead>
          <tbody>{rows.map((c) => <tr key={c.id}><td>{c.sort}</td><td><div className="cell-main"><span className="thumb"><Icon n={c.icon} /></span><div><b>{c.name}</b>{c.name_ar && <small className="muted block" dir="rtl">{c.name_ar}</small>}</div></div></td><td className="muted">{c.slug}</td><td>{c.website_count}</td>
            <td><Badge v={c.visible ? 'published' : 'hidden'} tone={c.visible ? 'green' : 'gray'} /></td>
            <td className="acts">{edit && <><button className="icon-btn" aria-label={c.visible ? 'Hide' : 'Show'} title={c.visible ? t('Hide') : 'Show'} onClick={() => toggle(c)}><Icon n="eye" /></button><button className="icon-btn" aria-label={t('Edit')} onClick={() => setForm(c)}><Icon n="edit" /></button><button className="icon-btn danger" aria-label={t('Delete')} onClick={() => del(c)}><Icon n="trash" /></button></>}</td></tr>)}</tbody></table></div>}
    </div>
    {form && <FormModal title={form.id ? t('Edit') + ': ' + form.name : t('Add') + ' ' + t('Categories')} fields={fields} initial={form} onSave={save} onClose={() => setForm(null)} />}
  </>);
}
