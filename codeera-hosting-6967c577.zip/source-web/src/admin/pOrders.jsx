import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAdmin, useList, useFetch, DataTable, PageHead, Btn, Badge, FormModal, Modal, Icon, FilterSelect, useMoney, fmtDate, fmtDateTime, Empty, download, Skeleton, ErrorState, STATUS_LABEL } from './ui.jsx';

const ORDER_STATUSES = ['new', 'pending_confirmation', 'awaiting_payment', 'processing', 'completed', 'cancelled', 'refunded'];
const PAY = ['unpaid', 'pending', 'paid', 'failed', 'refunded'];

function OrderDetail({ id, onClose, onChanged }) {
  const { t, lang, can, toast, confirm } = useAdmin(); const money = useMoney(); const f = useFetch('/api/admin/orders/' + id); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false); const edit = can('orders.edit');
  const o = f.data;
  const patch = async (body, msg) => { setBusy(true); try { await api.put('/api/admin/orders/' + id, body); toast(msg || 'Saved'); f.reload(); onChanged(); } catch (e) { toast(e.message, 'err'); } setBusy(false); };
  const addNote = async () => { if (!note.trim()) return; setBusy(true); try { await api.post(`/api/admin/orders/${id}/notes`, { text: note }); setNote(''); f.reload(); } catch (e) { toast(e.message, 'err'); } setBusy(false); };
  const setStatus = async (s) => { if (['cancelled', 'refunded'].includes(s) && !(await confirm({ title: `Mark order as ${STATUS_LABEL[s].toLowerCase()}?`, message: 'It stops counting toward revenue.', confirmLabel: 'Yes, change', danger: true }))) return; patch({ status: s }, 'Status updated'); };
  const phone = (o?.customer_phone || '').replace(/[^\d]/g, '');
  return (
    <Modal wide title={o ? `${t('Order')} ${o.code}` : t('Order')} onClose={onClose} footer={<button className="btn" onClick={onClose}>{t('Close')}</button>}>
      {f.error ? <ErrorState error={f.error} onRetry={f.refetch} /> : !o ? <Skeleton /> : (
        <div className="detail">
          <div className="d-col">
            <div className="kv"><span>{t('Customer')}</span><b>{o.customer_name || '—'}</b></div>
            <div className="kv"><span>{t('Email')}</span><b>{o.customer_email || '—'}</b></div>
            <div className="kv"><span>{t('Phone')}</span><b>{o.customer_phone || '—'}</b></div>
            <div className="kv"><span>{t('Website')}</span><b>{o.product_name}</b></div>
            <div className="kv"><span>{t('Amount')}</span><b>{money(o.amount)}{o.discount > 0 && <small className="muted"> (−{money(o.discount)} {o.coupon_code})</small>}</b></div>
            <div className="kv"><span>{t('Date')}</span><b>{fmtDateTime(o.created_at, lang)}</b></div>
            <div className="kv"><span>Payment method</span><b>{o.payment_method || '—'}</b></div>
            {o.customization && <div className="kv col"><span>Customization requests</span><p>{o.customization}</p></div>}
            <div className="row-gap" style={{ marginTop: 12 }}>
              {o.customer_email && <a className="btn sm" href={'mailto:' + o.customer_email}><Icon n="mail" size={15} />Email</a>}
              {phone && <a className="btn sm" href={'https://wa.me/' + phone} target="_blank" rel="noopener noreferrer">WhatsApp</a>}
            </div>
          </div>
          <div className="d-col">
            <div className="fld"><label>{t('Status')}</label><select value={o.status} disabled={!edit || busy} onChange={(e) => setStatus(e.target.value)}>{ORDER_STATUSES.map((s) => <option key={s} value={s}>{t(STATUS_LABEL[s])}</option>)}</select></div>
            <div className="fld"><label>{t('Payment')}</label><div className="row-gap"><Badge v={o.payment_status} />
              {edit && o.payment_status !== 'paid' && <Btn kind="primary" icon="check" busy={busy} onClick={async () => { if (await confirm({ title: 'Confirm payment received?', message: `Marks ${o.code} as paid (${money(o.amount)}). This counts toward revenue.`, confirmLabel: 'Yes, confirm', danger: false })) patch({ payment_status: 'paid' }, 'Payment confirmed'); }}>Confirm payment</Btn>}
              {edit && <select value={o.payment_status} disabled={busy} onChange={(e) => patch({ payment_status: e.target.value })} aria-label="Payment status">{PAY.map((s) => <option key={s} value={s}>{t(STATUS_LABEL[s])}</option>)}</select>}</div></div>
            <h4>{t('Notes')} <small className="muted">(internal)</small></h4>
            <ul className="feed">{o.notes.length === 0 && <li className="muted">No notes yet.</li>}{o.notes.map((n, i) => <li key={i}>{n.text}<small className="muted block">{n.by} · {fmtDateTime(n.at, lang)}</small></li>)}</ul>
            {edit && <div className="row-gap"><input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add an internal note" onKeyDown={(e) => e.key === 'Enter' && addNote()} /><Btn onClick={addNote} busy={busy} disabled={!note.trim()}>{t('Add')}</Btn></div>}
            <h4>{t('History')}</h4>
            <ul className="feed">{[...o.history].reverse().map((h, i) => <li key={i}>{h.text}<small className="muted block">{h.by} · {fmtDateTime(h.at, lang)}</small></li>)}</ul>
          </div>
        </div>)}
    </Modal>
  );
}

export function Orders() {
  const { t, can, toast, lang, confirm } = useAdmin(); const money = useMoney(); const [sp, setSp] = useSearchParams();
  const list = useList('/api/admin/orders', { sort: 'created', dir: 'desc' }); const prods = useFetch('/api/admin/products', { pageSize: 100 });
  const [open, setOpen] = useState(null); const [create, setCreate] = useState(false); const edit = can('orders.edit');
  useEffect(() => { if (sp.get('open')) { setOpen(+sp.get('open')); setSp({}, { replace: true }); } }, []); // eslint-disable-line
  const cols = [
    { key: 'code', label: 'Order', sort: 'code', render: (o) => <b>{o.code}</b> }, { key: 'c', label: 'Customer', render: (o) => <>{o.customer_name || '—'}<small className="muted block">{o.customer_email || o.customer_phone}</small></> },
    { key: 'w', label: 'Website', render: (o) => o.product_name }, { key: 'amount', label: 'Amount', sort: 'amount', render: (o) => money(o.amount) },
    { key: 'pm', label: 'Payment', render: (o) => <><Badge v={o.payment_status} /><small className="muted block">{o.payment_method}</small></> },
    { key: 'created', label: 'Date', sort: 'created', render: (o) => fmtDate(o.created_at, lang) }, { key: 'status', label: 'Status', sort: 'status', render: (o) => <Badge v={o.status} /> },
  ];
  const fields = [{ name: 'product_id', label: 'Website', type: 'select', required: true, options: (prods.data?.rows || []).map((p) => ({ value: p.id, label: p.name })), placeholder: 'Choose…' },
    { name: 'customer_name', label: 'Customer name', required: true, half: true }, { name: 'customer_email', label: 'Email', type: 'email', half: true }, { name: 'customer_phone', label: 'Phone', half: true },
    { name: 'amount', label: 'Amount', type: 'number', half: true, help: 'Empty = website price.' }, { name: 'payment_method', label: 'Payment method', half: true }, { name: 'customization', label: 'Customization requests', type: 'textarea', rows: 3 }];
  return (<>
    <PageHead title="Orders" sub="Requests from the public site arrive here with status New.">
      <Btn icon="download" onClick={() => download('/api/admin/export/orders.csv')}>{t('Export CSV')}</Btn>{edit && <Btn kind="primary" icon="plus" onClick={() => setCreate(true)}>Create order</Btn>}
    </PageHead>
    <DataTable list={list} columns={cols} onRow={(o) => setOpen(o.id)}
      filters={<><FilterSelect list={list} name="status" label="Status" options={ORDER_STATUSES} /><FilterSelect list={list} name="payment_status" label="Payment" options={PAY} />
        <input type="date" className="flt" aria-label="From date" value={list.params.from || ''} onChange={(e) => list.set({ from: e.target.value })} /><input type="date" className="flt" aria-label="To date" value={list.params.to || ''} onChange={(e) => list.set({ to: e.target.value })} /></>}
      empty={<Empty title="No orders yet" hint="Orders show up here when visitors request a website." />} />
    {open && <OrderDetail id={open} onClose={() => setOpen(null)} onChanged={list.reload} />}
    {create && <FormModal title="Create order" fields={fields} initial={{}} onClose={() => setCreate(false)} onSave={async (v) => { const r = await api.post('/api/admin/orders', v); toast('Order ' + r.code + ' created'); setCreate(false); list.reload(); }} />}
  </>);
}

export function Customers() {
  const { t, can, toast, confirm, lang } = useAdmin(); const money = useMoney(); const [sp, setSp] = useSearchParams();
  const list = useList('/api/admin/customers', { sort: 'created', dir: 'desc' }); const [form, setForm] = useState(null); const [view, setView] = useState(null); const edit = can('customers.edit');
  useEffect(() => { if (sp.get('open')) { openView(+sp.get('open')); setSp({}, { replace: true }); } }, []); // eslint-disable-line
  const openView = async (id) => { try { setView(await api.get('/api/admin/customers/' + id)); } catch (e) { toast(e.message, 'err'); } };
  const fields = [{ name: 'name', label: 'Name', required: true }, { name: 'email', label: 'Email', type: 'email', half: true }, { name: 'phone', label: 'Phone', half: true }, { name: 'notes', label: 'Notes', type: 'textarea' }];
  const save = async (v) => { if (form.id) await api.put('/api/admin/customers/' + form.id, v); else await api.post('/api/admin/customers', v); toast('Saved'); setForm(null); setView(null); list.reload(); };
  const del = async (c) => { if (await confirm({ title: 'Delete customer?', message: `"${c.name}" will be removed. Their orders stay in the order list.` })) { try { await api.del('/api/admin/customers/' + c.id); toast('Deleted'); setView(null); list.reload(); } catch (e) { toast(e.message, 'err'); } } };
  const cols = [{ key: 'name', label: 'Name', sort: 'name', render: (c) => <div className="cell-main"><span className="avatar sm">{c.name[0]}</span><b>{c.name}</b></div> }, { key: 'e', label: 'Email', render: (c) => c.email || '—' }, { key: 'p', label: 'Phone', render: (c) => c.phone || '—' },
    { key: 'orders', label: 'Orders', sort: 'orders', render: (c) => c.orders_count }, { key: 'spent', label: 'Total purchases', sort: 'spent', render: (c) => money(c.total_spent) }, { key: 'created', label: 'Registered', sort: 'created', render: (c) => fmtDate(c.created_at, lang) }];
  return (<>
    <PageHead title="Customers"><Btn icon="download" onClick={() => download('/api/admin/export/customers.csv')}>{t('Export CSV')}</Btn>{edit && <Btn kind="primary" icon="plus" onClick={() => setForm({})}>{t('Add')}</Btn>}</PageHead>
    <DataTable list={list} columns={cols} onRow={(c) => openView(c.id)} empty={<Empty title="No customers yet" hint="Customers are created automatically from orders." />} />
    {view && <Modal wide title={view.name} onClose={() => setView(null)} footer={<>{edit && <><Btn kind="danger" icon="trash" onClick={() => del(view)}>{t('Delete')}</Btn><Btn icon="edit" onClick={() => setForm(view)}>{t('Edit')}</Btn></>}<button className="btn" onClick={() => setView(null)}>{t('Close')}</button></>}>
      <div className="detail"><div className="d-col"><div className="kv"><span>{t('Email')}</span><b>{view.email || '—'}</b></div><div className="kv"><span>{t('Phone')}</span><b>{view.phone || '—'}</b></div><div className="kv"><span>Registered</span><b>{fmtDate(view.created_at, lang)}</b></div><div className="kv"><span>Last activity</span><b>{fmtDateTime(view.last_activity, lang)}</b></div><div className="kv"><span>Total purchases</span><b>{money(view.total_spent)}</b></div>{view.notes && <div className="kv col"><span>{t('Notes')}</span><p>{view.notes}</p></div>}</div>
        <div className="d-col"><h4>Order history</h4>{view.orders.length === 0 ? <p className="muted">No orders.</p> : <ul className="feed">{view.orders.map((o) => <li key={o.id}><b>{o.code}</b> · {o.product_name} · {money(o.amount)} <Badge v={o.status} /><small className="muted block">{fmtDate(o.created_at, lang)}</small></li>)}</ul>}
          <h4>Messages</h4>{view.messages.length === 0 ? <p className="muted">No messages.</p> : <ul className="feed">{view.messages.map((m) => <li key={m.id}>{m.subject || m.type}<small className="muted block">{fmtDate(m.created_at, lang)}</small></li>)}</ul>}</div></div></Modal>}
    {form && <FormModal title={form.id ? t('Edit') + ': ' + form.name : t('Add')} fields={fields} initial={form} onSave={save} onClose={() => setForm(null)} />}
  </>);
}
