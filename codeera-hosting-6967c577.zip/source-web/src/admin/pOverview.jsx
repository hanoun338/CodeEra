import React from 'react';
import { Link } from 'react-router-dom';
import { useAdmin, useFetch, PageHead, Stat, Skeleton, ErrorState, Badge, Icon, useMoney, fmtDateTime, Empty } from './ui.jsx';
import { LineChart, BarList } from './charts.jsx';

export function Overview() {
  const { t, lang, can, user } = useAdmin(); const money = useMoney(); const f = useFetch('/api/admin/overview');
  if (f.error) return <ErrorState error={f.error} onRetry={f.refetch} />;
  if (!f.data) return <><PageHead title="Overview" /><div className="stats">{[0, 1, 2, 3].map((i) => <div key={i} className="card"><Skeleton rows={2} /></div>)}</div></>;
  const d = f.data;
  return (<>
    <PageHead title="Overview" sub={`${t('Welcome')}, ${user.name || user.username}`}>
      {can('products.edit') && <Link className="btn primary" to="/admin/websites?new=1"><Icon n="plus" size={16} />{t('Add website')}</Link>}
    </PageHead>
    <div className="stats">
      {d.products && <Stat icon="globe" label="Total websites" value={d.products.total} sub={`${d.products.published} ${t('Published')} · ${d.products.draft} ${t('Draft')}`} />}
      {d.revenue != null && <Stat icon="dollar" tone="green" label="Revenue" value={money(d.revenue)} sub={`${d.sales} paid`} />}
      {d.orders && <Stat icon="cart" tone="cyan" label="Total orders" value={d.orders.total} sub={`${d.orders.pending} ${t('Pending orders').toLowerCase()}`} />}
      {d.customers != null && <Stat icon="users" tone="gold" label="Total customers" value={d.customers} />}
      {d.views != null && <Stat icon="eye" label="Page views" value={d.views.toLocaleString()} />}
      {d.conversion != null && <Stat icon="trend" tone="cyan" label="Conversion rate" value={d.conversion + '%'} sub="orders ÷ visits" />}
    </div>
    <div className="grid2">
      {d.chart && <div className="card pad"><h3>{t('Revenue over time')} <small className="muted">· 30d</small></h3><LineChart data={d.chart.map((c) => ({ x: c.date, revenue: c.revenue, orders: c.orders }))} lines={[{ key: 'revenue', color: '#28D9FF', label: t('Revenue'), area: true }]} format={(v) => money(v)} /></div>}
      <div className="card pad"><h3>{t('Quick actions')}</h3>
        <div className="quick">
          {can('products.edit') && <Link to="/admin/websites?new=1" className="btn"><Icon n="plus" size={16} />{t('Add website')}</Link>}
          {can('orders.view') && <Link to="/admin/orders" className="btn"><Icon n="cart" size={16} />{t('Orders')}{d.badges.orders > 0 && <b className="nbadge">{d.badges.orders}</b>}</Link>}
          {can('messages.view') && <Link to="/admin/messages" className="btn"><Icon n="mail" size={16} />{t('Messages & Inquiries')}{d.badges.messages > 0 && <b className="nbadge">{d.badges.messages}</b>}</Link>}
          {can('reviews.view') && <Link to="/admin/reviews" className="btn"><Icon n="star" size={16} />{t('Reviews')}{d.badges.reviews > 0 && <b className="nbadge">{d.badges.reviews}</b>}</Link>}
          {can('coupons.edit') && <Link to="/admin/coupons" className="btn"><Icon n="coupon" size={16} />{t('Coupons & Offers')}</Link>}
          {can('homepage.view') && <Link to="/admin/homepage" className="btn"><Icon n="layout" size={16} />{t('Homepage Editor')}</Link>}
        </div>
      </div>
    </div>
    <div className="grid2">
      {d.recentOrders && <div className="card pad"><h3>{t('Recent orders')}</h3>{d.recentOrders.length === 0 ? <Empty title="No orders yet" hint="Orders requested on the public site appear here." /> :
        <table className="tbl mini"><tbody>{d.recentOrders.map((o) => <tr key={o.id}><td><Link to={'/admin/orders?open=' + o.id}>{o.code}</Link><small className="muted block">{o.customer}</small></td><td>{o.product_name}</td><td>{money(o.amount)}</td><td><Badge v={o.status} /></td></tr>)}</tbody></table>}</div>}
      {d.activity && <div className="card pad"><h3>{t('Recent activity')}</h3>{d.activity.length === 0 ? <Empty /> : <ul className="feed">{d.activity.map((a) => <li key={a.id}><b>{a.username}</b> {a.action.replace(/[._]/g, ' ')}{a.details ? <span className="muted"> · {a.details}</span> : null}<small className="muted block">{fmtDateTime(a.created_at, lang)}</small></li>)}</ul>}</div>}
    </div>
    <div className="grid2">
      {d.bestSelling && <div className="card pad"><h3>{t('Best selling')}</h3><BarList items={d.bestSelling.map((b) => ({ name: b.name, value: b.sales }))} format={(v) => v + ' sales'} empty="No paid orders yet." /></div>}
      {d.mostViewed && <div className="card pad"><h3>{t('Most viewed')}</h3><BarList items={d.mostViewed.map((b) => ({ name: b.name, value: b.views }))} color="var(--c3)" empty="No views recorded yet." /></div>}
    </div>
  </>);
}
