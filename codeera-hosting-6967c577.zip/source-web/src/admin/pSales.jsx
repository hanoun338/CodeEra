import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAdmin, useList, useFetch, DataTable, PageHead, Btn, Badge, FormModal, Modal, Icon, FilterSelect, useMoney, fmtDate, fmtDateTime, Empty, download, Skeleton, ErrorState, Stat, STATUS_LABEL } from './ui.jsx';
import { LineChart, BarList, Donut } from './charts.jsx';

const iso = (d) => d.toISOString().slice(0, 10);
export function Analytics() {
  const { t } = useAdmin(); const money = useMoney();
  const [range, setRange] = useState({ from: iso(new Date(Date.now() - 29 * 864e5)), to: iso(new Date()) });
  const f = useFetch('/api/admin/analytics', range);
  const preset = (days) => setRange({ from: iso(new Date(Date.now() - (days - 1) * 864e5)), to: iso(new Date()) });
  const d = f.data;
  const delta = (a, b) => (b ? Math.round(((a - b) / b) * 100) : a ? 100 : 0);
  return (<>
    <PageHead title="Sales & Analytics" sub="Revenue counts paid orders that are not cancelled or refunded.">
      <Btn icon="download" onClick={() => download('/api/admin/export/analytics.csv' + api.qs(range))}>{t('Export CSV')}</Btn></PageHead>
    <div className="card pad range"><div className="row-gap">{[7, 30, 90, 365].map((n) => <button key={n} className="btn sm" onClick={() => preset(n)}>{n}d</button>)}</div><div className="grow" />
      <label className="inl">From<input type="date" value={range.from} max={range.to} onChange={(e) => e.target.value && setRange({ ...range, from: e.target.value })} /></label>
      <label className="inl">To<input type="date" value={range.to} min={range.from} onChange={(e) => e.target.value && setRange({ ...range, to: e.target.value })} /></label></div>
    {f.error ? <ErrorState error={f.error} onRetry={f.refetch} /> : !d ? <Skeleton rows={8} /> : (<>
      <div className="stats">
        <Stat icon="dollar" tone="green" label="Revenue" value={money(d.totals.revenue)} sub={`${delta(d.totals.revenue, d.totals.previousRevenue)}% vs previous period`} />
        <Stat icon="cart" tone="cyan" label="Total orders" value={d.totals.orders} sub={`${delta(d.totals.orders, d.totals.previousOrders)}% vs previous period`} />
        <Stat icon="eye" label="Page views" value={d.totals.visits} /><Stat icon="trend" tone="gold" label="Conversion rate" value={d.totals.conversion + '%'} />
      </div>
      <div className="grid2">
        <div className="card pad"><h3>{t('Revenue over time')}</h3><LineChart data={d.series.map((s, i) => ({ x: s.date, revenue: s.revenue }))} lines={[{ key: 'revenue', color: '#28D9FF', label: t('Revenue'), area: true }]} format={(v) => money(v)} /></div>
        <div className="card pad"><h3>{t('Orders over time')}</h3><LineChart data={d.series.map((s) => ({ x: s.date, orders: s.orders }))} lines={[{ key: 'orders', color: '#1677FF', label: t('Orders'), area: true }]} /></div>
      </div>
      <div className="card pad"><h3>Revenue comparison</h3><LineChart data={d.series.map((s, i) => ({ x: s.date, current: s.revenue, previous: d.previous[i]?.revenue || 0 }))} lines={[{ key: 'current', color: '#28D9FF', label: 'This period' }, { key: 'previous', color: '#C8A45D', label: 'Previous period', dash: '5 4' }]} format={(v) => money(v)} /></div>
      <div className="grid2">
        <div className="card pad"><h3>{t('Sales ranking')}</h3><BarList items={d.ranking.map((r) => ({ name: r.name, value: r.revenue }))} format={money} /></div>
        <div className="card pad"><h3>{t('Sales by category')}</h3><Donut items={d.byCategory.map((r) => ({ name: r.name, value: r.revenue }))} format={money} /></div>
      </div>
      <div className="grid2">
        <div className="card pad"><h3>{t('Most viewed')}</h3><BarList items={d.mostViewed.map((r) => ({ name: r.name, value: r.views }))} color="var(--c3)" /></div>
        <div className="card pad"><h3>{t('Customer acquisition')}</h3><LineChart data={d.customers.map((s) => ({ x: s.date, customers: s.customers }))} lines={[{ key: 'customers', color: '#2ecf8f', label: 'New customers', area: true }]} /></div>
      </div></>)}
  </>);
}

export function Coupons() {
  const { t, can, toast, confirm, lang } = useAdmin(); const money = useMoney(); const list = useList('/api/admin/coupons'); const prods = useFetch('/api/admin/products', { pageSize: 100 }); const [form, setForm] = useState(null); const edit = can('coupons.edit');
  const fields = [{ name: 'code', label: 'Code', required: true, half: true, placeholder: 'WELCOME10' }, { name: 'type', label: 'Type', type: 'select', half: true, options: [{ value: 'percent', label: 'Percentage (%)' }, { value: 'fixed', label: 'Fixed amount' }] },
    { name: 'value', label: 'Value', type: 'number', required: true, half: true }, { name: 'min_purchase', label: 'Minimum purchase', type: 'number', half: true, default: 0 },
    { name: 'expires_at', label: 'Expiry date', type: 'date', half: true }, { name: 'usage_limit', label: 'Usage limit', type: 'number', half: true, help: 'Empty = unlimited.' },
    { name: 'active', label: 'Enabled', type: 'checkbox', default: true }];
  const save = async (v) => {
    const body = { ...v, product_ids: v.product_ids || [] };
    if (form.id) await api.put('/api/admin/coupons/' + form.id, body); else await api.post('/api/admin/coupons', body); toast('Saved'); setForm(null); list.reload();
  };
  const del = async (c) => { if (await confirm({ title: 'Delete coupon?', message: `${c.code} will stop working.` })) { try { await api.del('/api/admin/coupons/' + c.id); toast('Deleted'); list.reload(); } catch (e) { toast(e.message, 'err'); } } };
  const toggle = async (c) => { try { await api.put('/api/admin/coupons/' + c.id, { ...c, active: !c.active }); list.reload(); } catch (e) { toast(e.message, 'err'); } };
  const cols = [{ key: 'code', label: 'Code', sort: 'code', render: (c) => <b>{c.code}</b> }, { key: 'v', label: 'Discount', render: (c) => c.type === 'percent' ? c.value + '%' : money(c.value) },
    { key: 'min', label: 'Min. purchase', render: (c) => (c.min_purchase ? money(c.min_purchase) : '—') }, { key: 'scope', label: 'Applies to', render: (c) => (c.product_ids.length ? c.product_ids.length + ' website(s)' : 'All websites') },
    { key: 'used', label: 'Used', sort: 'used', render: (c) => `${c.used}${c.usage_limit ? ' / ' + c.usage_limit : ''}` }, { key: 'perf', label: 'Performance', render: (c) => <>{money(c.revenue)}<small className="muted block">−{money(c.discount_given)} given</small></> },
    { key: 'exp', label: 'Expires', render: (c) => (c.expires_at ? <span className={c.expires_at < iso(new Date()) ? 'err-t' : ''}>{fmtDate(c.expires_at, lang)}</span> : '—') },
    { key: 'on', label: 'Status', stop: true, render: (c) => <button className="link-btn" disabled={!edit} onClick={() => toggle(c)} aria-label="Toggle coupon"><Badge v={c.active ? 'published' : 'draft'} tone={c.active ? 'green' : 'gray'} /></button> },
    { key: 'a', label: 'Actions', cls: 'acts', stop: true, render: (c) => edit && <><button className="icon-btn" aria-label={t('Edit')} onClick={() => setForm(c)}><Icon n="edit" /></button><button className="icon-btn danger" aria-label={t('Delete')} onClick={() => del(c)}><Icon n="trash" /></button></> }];
  const pickProducts = (
    <div className="fld"><label>Restrict to websites</label><div className="chips">{(prods.data?.rows || []).map((p) => { const on = (form?.product_ids || []).includes(p.id); return <button type="button" key={p.id} className={'chip' + (on ? ' on' : '')} onClick={() => setForm((f) => ({ ...f, product_ids: on ? f.product_ids.filter((x) => x !== p.id) : [...(f.product_ids || []), p.id] }))}>{p.name}</button>; })}</div><small className="muted">None selected = all websites.</small></div>
  );
  return (<>
    <PageHead title="Coupons & Offers">{edit && <Btn kind="primary" icon="plus" onClick={() => setForm({ type: 'percent', active: true, product_ids: [] })}>{t('Add')}</Btn>}</PageHead>
    <DataTable list={list} columns={cols} empty={<Empty title="No coupons yet" hint="Create a percentage or fixed discount for customers." />} />
    {form && <CouponForm key={form.id || 'new'} form={form} setForm={setForm} fields={fields} save={save} pickProducts={pickProducts} />}
  </>);
}
function CouponForm({ form, setForm, fields, save, pickProducts }) {
  return <FormModal title={form.id ? 'Edit coupon' : 'New coupon'} fields={fields} initial={form} onSave={(v) => save({ ...v, product_ids: form.product_ids })} onClose={() => setForm(null)}>{pickProducts}</FormModal>;
}

export function Reviews() {
  const { t, can, toast, confirm, lang, refreshBadges } = useAdmin(); const list = useList('/api/admin/reviews', { sort: 'created', dir: 'desc' }); const [reply, setReply] = useState(null); const edit = can('reviews.edit');
  const set = async (r, status) => { try { await api.put('/api/admin/reviews/' + r.id, { status }); toast('Saved'); list.reload(); refreshBadges(); } catch (e) { toast(e.message, 'err'); } };
  const del = async (r) => { if (await confirm({ title: 'Delete review?', message: 'This cannot be undone.' })) { try { await api.del('/api/admin/reviews/' + r.id); list.reload(); refreshBadges(); } catch (e) { toast(e.message, 'err'); } } };
  const st = list.data?.stats;
  const cols = [{ key: 'r', label: 'Rating', sort: 'rating', render: (r) => <span className="stars">{'★'.repeat(r.rating)}<span className="dim">{'★'.repeat(5 - r.rating)}</span></span> },
    { key: 'text', label: 'Review', render: (r) => <><b>{r.name}</b> <small className="muted">on {r.product_name || 'deleted website'}</small><p className="clamp">{r.text}</p>{r.reply && <p className="reply"><Icon n="mail" size={13} /> {r.reply}</p>}</> },
    { key: 'status', label: 'Status', render: (r) => <Badge v={r.status} /> }, { key: 'created', label: 'Date', sort: 'created', render: (r) => fmtDate(r.created_at, lang) },
    { key: 'a', label: 'Actions', cls: 'acts', stop: true, render: (r) => edit && <>{r.status !== 'approved' && <button className="icon-btn ok" title={t('Approve')} aria-label={t('Approve')} onClick={() => set(r, 'approved')}><Icon n="check" /></button>}{r.status === 'pending' && <button className="icon-btn danger" title={t('Reject')} aria-label={t('Reject')} onClick={() => set(r, 'rejected')}><Icon n="x" /></button>}{r.status === 'approved' && <button className="icon-btn" title={t('Hide')} aria-label={t('Hide')} onClick={() => set(r, 'hidden')}><Icon n="eye" /></button>}<button className="icon-btn" title={t('Reply')} aria-label={t('Reply')} onClick={() => setReply(r)}><Icon n="mail" /></button><button className="icon-btn danger" aria-label={t('Delete')} onClick={() => del(r)}><Icon n="trash" /></button></> }];
  return (<>
    <PageHead title="Reviews" />
    {st && <div className="stats"><Stat icon="star" tone="gold" label="Average rating" value={st.avg || '—'} sub={`${st.total} reviews`} /><Stat icon="check" tone="green" label="Approved" value={st.approved} /><Stat icon="bell" label="Pending" value={st.pending} /></div>}
    <DataTable list={list} columns={cols} filters={<><FilterSelect list={list} name="status" label="Status" options={['pending', 'approved', 'rejected', 'hidden']} /><FilterSelect list={list} name="rating" label="Rating" options={[5, 4, 3, 2, 1].map((n) => ({ value: n, label: n + ' ★' }))} /></>} empty={<Empty title="No reviews yet" hint="Visitors can review a website on its page. New reviews wait here for approval." />} />
    {reply && <FormModal title="Reply to review" fields={[{ name: 'reply', label: 'Public reply', type: 'textarea' }]} initial={reply} onClose={() => setReply(null)} onSave={async (v) => { await api.put('/api/admin/reviews/' + reply.id, { reply: v.reply }); toast('Saved'); setReply(null); list.reload(); }} />}
  </>);
}

const TYPES = [{ value: 'contact', label: 'Contact' }, { value: 'custom_request', label: 'Custom website request' }, { value: 'support', label: 'Support' }, { value: 'whatsapp', label: 'WhatsApp inquiry' }];
export function Messages() {
  const { t, can, toast, confirm, lang, refreshBadges } = useAdmin(); const [sp, setSp] = useSearchParams();
  const list = useList('/api/admin/messages', { sort: 'created', dir: 'desc' }); const [open, setOpen] = useState(null); const [note, setNote] = useState(''); const [rep, setRep] = useState(''); const [ch, setCh] = useState('whatsapp'); const edit = can('messages.edit');
  const load = async (id) => { try { const m = await api.get('/api/admin/messages/' + id); setOpen(m); if (!m.read && edit) { await api.put('/api/admin/messages/' + id, { read: true }); list.reload(); refreshBadges(); } } catch (e) { toast(e.message, 'err'); } };
  useEffect(() => { if (sp.get('open')) { load(+sp.get('open')); setSp({}, { replace: true }); } }, []); // eslint-disable-line
  const upd = async (body) => { try { await api.put('/api/admin/messages/' + open.id, body); await load(open.id); list.reload(); toast('Saved'); } catch (e) { toast(e.message, 'err'); } };
  const post = async (path, body, clear) => { try { await api.post(`/api/admin/messages/${open.id}/${path}`, body); clear(''); await load(open.id); list.reload(); refreshBadges(); toast('Saved'); } catch (e) { toast(e.message, 'err'); } };
  const del = async () => { if (await confirm({ title: 'Delete message?', message: 'This cannot be undone.' })) { try { await api.del('/api/admin/messages/' + open.id); setOpen(null); list.reload(); refreshBadges(); } catch (e) { toast(e.message, 'err'); } } };
  const cols = [{ key: 'n', label: 'Name', render: (m) => <span className={m.read ? '' : 'unread'}>{!m.read && <i className="dot" />}<b>{m.name}</b><small className="muted block">{m.email || m.phone}</small></span> }, { key: 's', label: 'Subject', render: (m) => <span className="clamp">{m.subject || m.body}</span> },
    { key: 'type', label: 'Type', render: (m) => t(TYPES.find((x) => x.value === m.type)?.label || m.type) }, { key: 'pr', label: 'Priority', sort: 'priority', render: (m) => <Badge v={m.priority} /> }, { key: 'st', label: 'Status', render: (m) => <Badge v={m.status} /> }, { key: 'created', label: 'Date', sort: 'created', render: (m) => fmtDate(m.created_at, lang) }];
  const phone = (open?.phone || '').replace(/[^\d]/g, '');
  return (<>
    <PageHead title="Messages & Inquiries" />
    <DataTable list={list} columns={cols} onRow={(m) => load(m.id)} filters={<><FilterSelect list={list} name="type" label="Type" options={TYPES} /><FilterSelect list={list} name="status" label="Status" options={['new', 'in_progress', 'replied', 'closed']} /><FilterSelect list={list} name="priority" label="Priority" options={['high', 'normal', 'low']} />
      <label className="chk"><input type="checkbox" checked={list.params.unread === '1'} onChange={(e) => list.set({ unread: e.target.checked ? '1' : '' })} />{t('Unread')}</label></>} empty={<Empty title="No messages yet" hint="Contact form and custom website requests arrive here." />} />
    {open && <Modal wide title={open.subject || open.name} onClose={() => setOpen(null)} footer={<>{edit && <Btn kind="danger" icon="trash" onClick={del}>{t('Delete')}</Btn>}<button className="btn" onClick={() => setOpen(null)}>{t('Close')}</button></>}>
      <div className="detail"><div className="d-col"><div className="kv"><span>{t('Name')}</span><b>{open.name}</b></div><div className="kv"><span>{t('Email')}</span><b>{open.email || '—'}</b></div><div className="kv"><span>{t('Phone')}</span><b>{open.phone || '—'}</b></div>
        {open.project_type && <div className="kv"><span>Project</span><b>{open.project_type}</b></div>}{open.budget && <div className="kv"><span>Budget</span><b>{open.budget}</b></div>}<div className="kv"><span>{t('Date')}</span><b>{fmtDateTime(open.created_at, lang)}</b></div>
        <div className="msg-body">{open.body}</div>
        <div className="row-gap">{open.email && <a className="btn sm" href={'mailto:' + open.email}><Icon n="mail" size={15} />Email</a>}{phone && <a className="btn sm" href={'https://wa.me/' + phone} target="_blank" rel="noopener noreferrer">WhatsApp</a>}</div></div>
        <div className="d-col">
          {edit && <div className="row-gap"><div className="fld grow"><label>{t('Status')}</label><select value={open.status} onChange={(e) => upd({ status: e.target.value })}>{['new', 'in_progress', 'replied', 'closed'].map((s) => <option key={s} value={s}>{t(STATUS_LABEL[s])}</option>)}</select></div><div className="fld grow"><label>{t('Priority')}</label><select value={open.priority} onChange={(e) => upd({ priority: e.target.value })}>{['low', 'normal', 'high'].map((s) => <option key={s} value={s}>{t(STATUS_LABEL[s])}</option>)}</select></div></div>}
          <h4>Replies sent</h4><ul className="feed">{open.replies.length === 0 && <li className="muted">None logged yet.</li>}{open.replies.map((r, i) => <li key={i}>{r.text}<small className="muted block">{r.by} · {r.channel} · {fmtDateTime(r.at, lang)}</small></li>)}</ul>
          {edit && <><textarea rows={2} value={rep} onChange={(e) => setRep(e.target.value)} placeholder="Log the reply you sent" /><div className="row-gap"><select value={ch} onChange={(e) => setCh(e.target.value)} aria-label="Channel"><option value="whatsapp">WhatsApp</option><option value="email">Email</option><option value="phone">Phone</option><option value="other">Other</option></select><Btn disabled={!rep.trim()} onClick={() => post('replies', { text: rep, channel: ch }, setRep)}>Log reply</Btn></div><small className="muted">This records that you replied. The dashboard does not send messages itself.</small></>}
          <h4>{t('Notes')}</h4><ul className="feed">{open.notes.length === 0 && <li className="muted">No notes yet.</li>}{open.notes.map((n, i) => <li key={i}>{n.text}<small className="muted block">{n.by} · {fmtDateTime(n.at, lang)}</small></li>)}</ul>
          {edit && <div className="row-gap"><input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Internal note" onKeyDown={(e) => e.key === 'Enter' && note.trim() && post('notes', { text: note }, setNote)} /><Btn disabled={!note.trim()} onClick={() => post('notes', { text: note }, setNote)}>{t('Add')}</Btn></div>}
        </div></div></Modal>}
  </>);
}
