import React, { useRef, useState } from 'react';
import { api } from '../api.js';
import { useAdmin, useList, useFetch, useSettings, SaveBar, SettingsLoader, Field, Toggle, ImageField, PageHead, Btn, Icon, Tabs, Empty, Skeleton, ErrorState, fmtDate, fmtSize, DataTable, Modal } from './ui.jsx';

const inp = (s, path, extra = {}) => { const val = path.split('.').reduce((o, k) => o?.[k], s.v); return <input value={val ?? ''} onChange={(e) => s.patch(path, extra.number ? Number(e.target.value) : e.target.value)} {...extra} />; };
const area = (s, path, rows = 3) => <textarea rows={rows} value={path.split('.').reduce((o, k) => o?.[k], s.v) ?? ''} onChange={(e) => s.patch(path, e.target.value)} />;
const get = (s, path) => path.split('.').reduce((o, k) => o?.[k], s.v);

export function HomepageEditor() {
  const { can } = useAdmin(); const s = useSettings('homepage'); const prods = useFetch('/api/admin/products', { pageSize: 100 }); const [tab, setTab] = useState('hero'); const ro = !can('homepage.edit');
  const tabs = [{ id: 'hero', label: 'Hero & announcement' }, { id: 'explore', label: 'Websites section' }, { id: 'services', label: 'Services' }, { id: 'about', label: 'About' }, { id: 'proof', label: 'Testimonials & statistics' }, { id: 'footer', label: 'Footer' }];
  return (<>
    <PageHead title="Homepage Editor" sub="Changes go live on the public site as soon as you save.">{!ro && <SaveBar s={s} />}</PageHead>
    <Tabs tabs={tabs} value={tab} onChange={setTab} />
    <SettingsLoader s={s}>{() => (<><fieldset disabled={ro} className="card pad fs">
      {tab === 'hero' && <div className="form-grid">
        <div className="fld"><Toggle label="Show announcement bar" checked={get(s, 'announcement.enabled')} onChange={(v) => s.patch('announcement.enabled', v)} /></div>
        <Field label="Announcement text" half>{inp(s, 'announcement.text')}</Field><Field label="Announcement link" half>{inp(s, 'announcement.link', { placeholder: 'https://…' })}</Field>
        <Field label="Hero label">{inp(s, 'hero.label')}</Field><Field label="Headline (line 1)" half>{inp(s, 'hero.headline1')}</Field><Field label="Headline (line 2, highlighted)" half>{inp(s, 'hero.headline2')}</Field>
        <Field label="Subtitle">{area(s, 'hero.subtitle', 2)}</Field><Field label="Primary button" half>{inp(s, 'hero.primaryCta')}</Field><Field label="Secondary button" half>{inp(s, 'hero.secondaryCta')}</Field>
        <ImageField label="Hero image (empty = the CodeEra pharaoh artwork)" value={get(s, 'hero.image')} onChange={(v) => s.patch('hero.image', v)} /></div>}
      {tab === 'explore' && <div className="form-grid">
        <Field label="Title (line 1)" half>{inp(s, 'exploreTitle1')}</Field><Field label="Title (line 2)" half>{inp(s, 'exploreTitle2')}</Field><Field label="Subtitle">{area(s, 'exploreSubtitle', 2)}</Field>
        <div className="fld"><Toggle label="Show category filters" checked={get(s, 'showCategoryFilters')} onChange={(v) => s.patch('showCategoryFilters', v)} /></div>
        <div className="fld"><Toggle label="Only show featured websites" checked={get(s, 'featuredOnly')} onChange={(v) => s.patch('featuredOnly', v)} /></div>
        <p className="muted">Mark websites as featured in the Websites page. Featured websites are listed first. Categories show or hide in the Categories page.</p></div>}
      {tab === 'services' && <div>
        {get(s, 'services').map((sv, i) => <div key={i} className="repeat"><div className="form-grid">
          <Field label="Title" half><input value={sv.t} onChange={(e) => { const a = [...get(s, 'services')]; a[i] = { ...sv, t: e.target.value }; s.patch('services', a); }} /></Field>
          <Field label="Icon" half><select value={sv.icon} onChange={(e) => { const a = [...get(s, 'services')]; a[i] = { ...sv, icon: e.target.value }; s.patch('services', a); }}>{['code', 'cart', 'dish', 'chart', 'rocket', 'building', 'pen', 'sliders', 'spark'].map((x) => <option key={x}>{x}</option>)}</select></Field>
          <Field label="Description"><textarea rows={2} value={sv.d} onChange={(e) => { const a = [...get(s, 'services')]; a[i] = { ...sv, d: e.target.value }; s.patch('services', a); }} /></Field></div>
          <div className="row-gap"><Toggle label="Visible" checked={sv.visible !== false} onChange={(v) => { const a = [...get(s, 'services')]; a[i] = { ...sv, visible: v }; s.patch('services', a); }} />
            <button type="button" className="btn sm danger" onClick={() => s.patch('services', get(s, 'services').filter((_, j) => j !== i))}><Icon n="trash" size={14} />Remove</button></div></div>)}
        <Btn icon="plus" onClick={() => s.patch('services', [...get(s, 'services'), { t: 'New service', d: '', icon: 'code', visible: true }])}>Add service</Btn></div>}
      {tab === 'about' && <div className="form-grid"><Field label="Kicker">{inp(s, 'about.kicker')}</Field><Field label="Headline (line 1)" half>{inp(s, 'about.headline1')}</Field><Field label="Headline (line 2)" half>{inp(s, 'about.headline2')}</Field><Field label="Text">{area(s, 'about.text', 4)}</Field><Field label="Arabic line">{inp(s, 'about.arabic', { dir: 'rtl' })}</Field></div>}
      {tab === 'proof' && <div className="form-grid">
        <div className="fld"><Toggle label="Show testimonials" checked={get(s, 'testimonials.enabled')} onChange={(v) => s.patch('testimonials.enabled', v)} /></div>
        <div className="fld"><Toggle label="Use approved customer reviews" checked={get(s, 'testimonials.useApprovedReviews')} onChange={(v) => s.patch('testimonials.useApprovedReviews', v)} /></div>
        <h4 className="full">Manual testimonials</h4>
        {get(s, 'testimonials.manual').map((m, i) => <div key={i} className="repeat full"><div className="form-grid"><Field label="Name" half><input value={m.name} onChange={(e) => { const a = [...get(s, 'testimonials.manual')]; a[i] = { ...m, name: e.target.value }; s.patch('testimonials.manual', a); }} /></Field><Field label="Rating" half><input type="number" min="1" max="5" value={m.rating} onChange={(e) => { const a = [...get(s, 'testimonials.manual')]; a[i] = { ...m, rating: Number(e.target.value) }; s.patch('testimonials.manual', a); }} /></Field><Field label="Text"><textarea rows={2} value={m.text} onChange={(e) => { const a = [...get(s, 'testimonials.manual')]; a[i] = { ...m, text: e.target.value }; s.patch('testimonials.manual', a); }} /></Field></div>
          <button type="button" className="btn sm danger" onClick={() => s.patch('testimonials.manual', get(s, 'testimonials.manual').filter((_, j) => j !== i))}><Icon n="trash" size={14} />Remove</button></div>)}
        <div className="full"><Btn icon="plus" onClick={() => s.patch('testimonials.manual', [...get(s, 'testimonials.manual'), { name: '', rating: 5, text: '' }])}>Add testimonial</Btn></div>
        <h4 className="full">Statistics</h4>
        <div className="fld"><Toggle label="Show statistics" checked={get(s, 'statistics.enabled')} onChange={(v) => s.patch('statistics.enabled', v)} /></div>
        <p className="muted full">Numbers come from your real data: websites published, customers, completed orders.</p></div>}
      {tab === 'footer' && <div className="form-grid"><Field label="Tagline">{inp(s, 'footer.tagline')}</Field><Field label="Footer text">{area(s, 'footer.text', 2)}</Field><p className="muted">Social links are set in General Settings.</p></div>}
    </fieldset></>)}</SettingsLoader>
  </>);
}

export function MediaLibrary() {
  const { t, can, toast, confirm, lang } = useAdmin(); const list = useList('/api/admin/media', { pageSize: 18 }); const fileRef = useRef(null); const [busy, setBusy] = useState(false); const [folder, setFolder] = useState('General'); const [sel, setSel] = useState(null); const edit = can('media.edit');
  const up = async (files) => { if (!files.length) return; setBusy(true); try { const fd = new FormData(); fd.append('folder', folder); [...files].forEach((f) => fd.append('files', f)); await api.upload('/api/admin/media', fd); toast('Uploaded'); list.reload(); } catch (e) { toast(e.message, 'err'); } setBusy(false); };
  const del = async (m, force) => { if (!force && !(await confirm({ title: 'Delete file?', message: m.original }))) return; try { await api.del('/api/admin/media/' + m.id, force ? { force: 1 } : {}); toast('Deleted'); setSel(null); list.reload(); } catch (e) { if (e.status === 409 && (await confirm({ title: 'File is in use', message: e.message, confirmLabel: 'Delete anyway' }))) del(m, true); else if (e.status !== 409) toast(e.message, 'err'); } };
  const cleanup = async () => { try { const un = await api.get('/api/admin/media/unused'); if (!un.length) { toast('No unused files'); return; } if (await confirm({ title: `Delete ${un.length} unused file(s)?`, message: 'Files not used by any website or setting will be removed.' })) { const r = await api.del('/api/admin/media/unused'); toast(`${r.deleted} deleted`); list.reload(); } } catch (e) { toast(e.message, 'err'); } };
  const rows = list.data?.rows || []; const folders = list.data?.folders || [];
  return (<>
    <PageHead title="Media Library" sub="PNG, JPG, WebP, GIF or ICO up to 5 MB. SVG is not accepted for safety.">
      {edit && <><input value={folder} onChange={(e) => setFolder(e.target.value)} aria-label="Upload folder" className="flt" placeholder="Folder" /><input ref={fileRef} type="file" hidden multiple accept="image/png,image/jpeg,image/webp,image/gif,image/x-icon" onChange={(e) => { up(e.target.files); e.target.value = ''; }} />
        <Btn kind="primary" icon="upload" busy={busy} onClick={() => fileRef.current.click()}>{busy ? t('Saving…') : t('Upload')}</Btn><Btn icon="trash" onClick={cleanup}>Delete unused</Btn></>}</PageHead>
    <div className="card pad">
      <div className="tbl-tools"><div className="search-in"><Icon n="search" /><input type="search" placeholder={t('Search')} value={list.params.q} onChange={(e) => list.set({ q: e.target.value })} /></div>
        <select className="flt" value={list.params.folder || 'all'} onChange={(e) => list.set({ folder: e.target.value })} aria-label="Folder"><option value="all">{t('All')} folders</option>{folders.map((f) => <option key={f.name} value={f.name}>{f.name} ({f.n})</option>)}</select></div>
      {list.error ? <ErrorState error={list.error} onRetry={list.refetch} /> : !list.data ? <Skeleton rows={4} /> : rows.length === 0 ? <Empty title="No media yet" hint="Upload images to use as thumbnails, logos and hero art." /> :
        <div className="media-grid big">{rows.map((m) => <button key={m.id} className="media-tile" onClick={() => setSel(m)}><img src={m.url} alt={m.original} loading="lazy" /><span>{m.original}</span></button>)}</div>}
      {list.data && list.data.pages > 1 && <div className="pager"><div className="grow" /><button className="btn sm" disabled={list.data.page <= 1} onClick={() => list.setPage(list.data.page - 1)}>‹</button><span>{list.data.page}/{list.data.pages}</span><button className="btn sm" disabled={list.data.page >= list.data.pages} onClick={() => list.setPage(list.data.page + 1)}>›</button></div>}
    </div>
    {sel && <Modal title={sel.original} onClose={() => setSel(null)} footer={<>{edit && <Btn kind="danger" icon="trash" onClick={() => del(sel)}>{t('Delete')}</Btn>}<button className="btn" onClick={() => setSel(null)}>{t('Close')}</button></>}>
      <img className="media-prev" src={sel.url} alt={sel.original} /><div className="kv"><span>{t('Type')}</span><b>{sel.mime}</b></div><div className="kv"><span>Size</span><b>{fmtSize(sel.size)}</b></div><div className="kv"><span>{t('Folder')}</span><b>{sel.folder}</b></div><div className="kv"><span>{t('Date')}</span><b>{fmtDate(sel.created_at, lang)}</b></div>
      <div className="row-gap" style={{ marginTop: 10 }}><input readOnly value={location.origin + sel.url} onFocus={(e) => e.target.select()} aria-label="URL" /><Btn icon="copy" onClick={() => { navigator.clipboard?.writeText(location.origin + sel.url).then(() => toast('URL copied'), () => toast('Select the URL and copy it', 'err')); }}>{t('Copy URL')}</Btn></div></Modal>}
  </>);
}

export function SeoSettings() {
  const { can } = useAdmin(); const s = useSettings('seo'); const st = useFetch('/api/admin/seo/status'); const ro = !can('seo.edit');
  return (<>
    <PageHead title="SEO Settings">{!ro && <SaveBar s={s} />}</PageHead>
    <SettingsLoader s={s}>{() => (<>
      <div className="grid2"><fieldset disabled={ro} className="card pad fs"><h3>Global</h3><div className="form-grid">
        <Field label="Default page title">{inp(s, 'siteTitle')}</Field><Field label="Title template" help="%s is replaced by the page name, e.g. a website's name.">{inp(s, 'titleTemplate')}</Field>
        <Field label="Meta description">{area(s, 'description', 3)}<small className="muted">{(get(s, 'description') || '').length}/160 recommended</small></Field>
        <Field label="Canonical site URL" help="Used in sitemap.xml. Example: https://codeera.example">{inp(s, 'siteUrl', { placeholder: 'https://' })}</Field></div>
        <h3>Social sharing (Open Graph)</h3><div className="form-grid"><Field label="OG title">{inp(s, 'ogTitle')}</Field><Field label="OG description">{area(s, 'ogDescription', 2)}</Field><ImageField label="Social image" value={get(s, 'ogImage')} onChange={(v) => s.patch('ogImage', v)} />
          <Field label="Twitter card" half><select value={get(s, 'twitterCard')} onChange={(e) => s.patch('twitterCard', e.target.value)}><option value="summary_large_image">Large image</option><option value="summary">Summary</option></select></Field></div></fieldset>
      <fieldset disabled={ro} className="card pad fs"><h3>Indexing</h3><div className="form-grid">
        <div className="fld"><Toggle label="Allow search engines to index the site" checked={get(s, 'robotsIndex')} onChange={(v) => s.patch('robotsIndex', v)} /></div>
        <div className="fld"><Toggle label="Generate sitemap.xml" checked={get(s, 'sitemapEnabled')} onChange={(v) => s.patch('sitemapEnabled', v)} /></div>
        <Field label="Extra robots.txt lines">{area(s, 'robotsExtra', 3)}</Field></div>
        <h3>Status</h3>{st.data ? <ul className="feed"><li>Sitemap: <b>{st.data.sitemap ? 'on' : 'off'}</b> · {st.data.sitemapUrls} URLs · <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer">open</a></li><li>Robots: <b>{st.data.robots}</b> · <a href="/robots.txt" target="_blank" rel="noopener noreferrer">open</a></li><li>Site URL: {st.data.siteUrl}</li></ul> : <Skeleton rows={2} />}
        <p className="muted">Each website also has its own SEO title and description in the Websites page. The admin area is always set to noindex.</p></fieldset></div>
    </>)}</SettingsLoader>
  </>);
}

export function AppearanceSettings() {
  const { can, t } = useAdmin(); const s = useSettings('appearance'); const ro = !can('appearance.edit');
  const colors = [['navy', 'Background'], ['dark', 'Surface'], ['blue', 'Primary blue'], ['cyan', 'Accent cyan'], ['gold', 'Gold'], ['white', 'Text']];
  const sel = (path, opts) => <select value={get(s, path)} onChange={(e) => s.patch(path, e.target.value)}>{opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>;
  return (<>
    <PageHead title="Appearance & Theme" sub="Applies to the public site.">{!ro && <SaveBar s={s} />}</PageHead>
    <SettingsLoader s={s}>{() => (<><div className="grid2"><fieldset disabled={ro} className="card pad fs"><h3>Colors</h3><div className="form-grid">
      {colors.map(([k, l]) => <Field key={k} label={l} half><div className="color-in"><input type="color" value={get(s, 'colors.' + k).slice(0, 7)} onChange={(e) => s.patch('colors.' + k, e.target.value)} aria-label={l} /><input value={get(s, 'colors.' + k)} onChange={(e) => s.patch('colors.' + k, e.target.value)} /></div></Field>)}</div>
      <Btn onClick={() => s.patch('colors', { navy: '#020817', dark: '#07152E', blue: '#1677FF', cyan: '#28D9FF', gold: '#C8A45D', white: '#F4F7FF' })}>Reset to CodeEra colors</Btn></fieldset>
    <fieldset disabled={ro} className="card pad fs"><h3>Style</h3><div className="form-grid">
      <Field label="Typography" half>{sel('font', [['inter', 'Inter (modern)'], ['serif', 'Serif (classic)'], ['mono', 'Monospace (technical)']])}</Field>
      <Field label="Button style" half>{sel('buttonStyle', [['pill', 'Pill'], ['rounded', 'Rounded'], ['square', 'Square']])}</Field>
      <Field label="Corner radius" half>{sel('radius', [['sm', 'Small'], ['md', 'Medium'], ['lg', 'Large']])}</Field>
      <Field label="Animations" half>{sel('animations', [['full', 'Full'], ['none', 'Off']])}</Field>
      <Field label="Default theme" half>{sel('defaultTheme', [['dark', 'Dark'], ['light', 'Light']])}</Field>
      <div className="fld half"><Toggle label="Let visitors switch light / dark" checked={get(s, 'allowThemeToggle')} onChange={(v) => s.patch('allowThemeToggle', v)} /></div>
      <h4 className="full">Header & footer</h4>
      <div className="fld"><Toggle label="Transparent header over the hero" checked={get(s, 'header.transparent')} onChange={(v) => s.patch('header.transparent', v)} /></div>
      <Field label="Footer layout" half>{sel('footerStyle', [['centered', 'Centered']])}</Field></div></fieldset></div>
      <div className="card pad"><h3>Preview</h3><div className="prev" style={{ background: get(s, 'colors.navy'), color: get(s, 'colors.white') }}><b style={{ fontSize: 22 }}>Code<span style={{ color: get(s, 'colors.cyan') }}>Era</span></b><p style={{ opacity: .7, margin: '6px 0 12px' }}>Ancient roots. <span style={{ color: get(s, 'colors.blue') }}>Future code.</span></p><span className="prev-btn" style={{ background: `linear-gradient(135deg,${get(s, 'colors.blue')},${get(s, 'colors.cyan')})`, borderRadius: get(s, 'buttonStyle') === 'square' ? 3 : get(s, 'buttonStyle') === 'rounded' ? 12 : 999 }}>Explore Our Work</span> <span style={{ color: get(s, 'colors.gold'), marginLeft: 12 }}>● gold accent</span></div></div></>)}</SettingsLoader>
  </>);
}

export function GeneralSettings() {
  const { can } = useAdmin(); const s = useSettings('general'); const ro = !can('settings.edit'); const [pw, setPw] = useState('');
  const savePw = () => s.save({ ...s.v, emailConfig: { ...s.v.emailConfig, password: pw } });
  return (<>
    <PageHead title="General Settings">{!ro && <SaveBar s={s} />}</PageHead>
    <SettingsLoader s={s}>{() => (<><div className="grid2">
      <fieldset disabled={ro} className="card pad fs"><h3>Site</h3><div className="form-grid">
        <Field label="Site name" half>{inp(s, 'siteName')}</Field><Field label="Currency code" half>{inp(s, 'currency')}</Field><Field label="Currency symbol" half>{inp(s, 'currencySymbol')}</Field>
        <ImageField label="Logo (empty = text logo)" value={get(s, 'logo')} onChange={(v) => s.patch('logo', v)} /><ImageField label="Favicon" value={get(s, 'favicon')} onChange={(v) => s.patch('favicon', v)} /></div>
        <h3>Contact</h3><div className="form-grid"><Field label="Email" half>{inp(s, 'email', { type: 'email' })}</Field><Field label="Phone" half>{inp(s, 'phone')}</Field><Field label="WhatsApp number" half help="Digits with country code, e.g. 201012345678. Used for every WhatsApp button.">{inp(s, 'whatsapp')}</Field><Field label="Address" half>{inp(s, 'address')}</Field></div>
        <h3>Social links</h3><div className="form-grid"><Field label="Handle" half>{inp(s, 'social.handle')}</Field><Field label="Instagram" half>{inp(s, 'social.instagram')}</Field><Field label="TikTok" half>{inp(s, 'social.tiktok')}</Field><Field label="Facebook" half>{inp(s, 'social.facebook')}</Field></div></fieldset>
      <div><fieldset disabled={ro} className="card pad fs"><h3>Payment methods</h3><p className="muted">Shown to customers when they request a website. Payments are confirmed by you in the Orders page. No payment gateway is connected.</p>
        {get(s, 'paymentMethods').map((m, i) => <div key={m.id} className="row-gap"><Toggle label={m.label} checked={m.enabled} onChange={(v) => s.patch('paymentMethods', get(s, 'paymentMethods').map((x, j) => (j === i ? { ...x, enabled: v } : x)))} /><input value={m.label} aria-label="Label" onChange={(e) => s.patch('paymentMethods', get(s, 'paymentMethods').map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} /></div>)}
        <h3>Maintenance mode</h3><div className="fld"><Toggle label="Show a maintenance page to visitors (the admin stays available)" checked={get(s, 'maintenance')} onChange={(v) => s.patch('maintenance', v)} /></div><Field label="Message">{area(s, 'maintenanceMessage', 2)}</Field></fieldset>
      <fieldset disabled={ro} className="card pad fs" style={{ marginTop: 16 }}><h3>Email configuration (SMTP)</h3><p className="muted">Stored for future use. This version does not send emails automatically.</p><div className="form-grid">
        <Field label="Host" half>{inp(s, 'emailConfig.host')}</Field><Field label="Port" half>{inp(s, 'emailConfig.port', { number: true, type: 'number' })}</Field><Field label="Username" half>{inp(s, 'emailConfig.user')}</Field><Field label="From address" half>{inp(s, 'emailConfig.from')}</Field>
        <Field label="Password" help={get(s, 'emailConfig.passwordSet') ? 'A password is saved. It can be replaced but never shown.' : 'Write-only. It is never shown again.'}><input type="password" value={pw} autoComplete="new-password" onChange={(e) => setPw(e.target.value)} placeholder="••••••••" /></Field>
        <div className="fld"><Btn disabled={!pw || ro} onClick={async () => { await savePw(); setPw(''); }}>Save password</Btn></div></div></fieldset></div></div></>)}</SettingsLoader>
  </>);
}
