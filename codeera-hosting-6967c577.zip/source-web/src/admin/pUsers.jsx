import React, { useState } from 'react';
import { api } from '../api.js';
import { useAdmin, useList, useFetch, DataTable, PageHead, Btn, Badge, FormModal, Icon, Tabs, Empty, Skeleton, ErrorState, fmtDateTime, FilterSelect } from './ui.jsx';

const AREA_LABEL = { products: 'Websites', categories: 'Categories', orders: 'Orders', customers: 'Customers', analytics: 'Sales & Analytics', coupons: 'Coupons & Offers', reviews: 'Reviews', messages: 'Messages', homepage: 'Homepage Editor', media: 'Media Library', seo: 'SEO Settings', appearance: 'Appearance', settings: 'General Settings', users: 'Users & Permissions', logs: 'Activity Logs' };

function Roles({ roles, onChange }) {
  const { t, can, toast, user } = useAdmin(); const [sel, setSel] = useState('admin'); const role = roles.roles.find((r) => r.name === sel) || roles.roles[0]; const [perms, setPerms] = useState(null); const [busy, setBusy] = useState(false);
  const cur = perms ?? role.permissions; const edit = can('users.edit') && !role.locked;
  const toggle = (p) => { let n = cur.includes(p) ? cur.filter((x) => x !== p) : [...cur, p]; if (p.endsWith('.view') && !n.includes(p)) n = n.filter((x) => x !== p.replace('.view', '.edit')); setPerms(n); };
  const save = async () => { setBusy(true); try { await api.put('/api/admin/roles/' + role.name, { permissions: cur }); toast('Saved'); setPerms(null); onChange(); } catch (e) { toast(e.message, 'err'); } setBusy(false); };
  return (
    <div className="card pad">
      <div className="row-gap"><label className="inl">Role<select value={role.name} onChange={(e) => { setSel(e.target.value); setPerms(null); }}>{roles.roles.map((r) => <option key={r.name} value={r.name}>{r.label}</option>)}</select></label><div className="grow" />{perms && <span className="save-state dirty">{t('Unsaved changes')}</span>}{edit && <Btn kind="primary" icon="check" busy={busy} disabled={!perms} onClick={save}>{t('Save changes')}</Btn>}</div>
      {role.locked && <p className="muted">Super Admin always has every permission and cannot be changed.</p>}
      <table className="tbl perm"><thead><tr><th>Area</th><th>View</th><th>Create / edit / delete</th></tr></thead><tbody>{roles.areas.map((a) => <tr key={a}><td>{t(AREA_LABEL[a] || a)}</td>
        {['view', 'edit'].map((k) => <td key={k}><input type="checkbox" aria-label={`${a} ${k}`} disabled={!edit} checked={cur.includes(a + '.' + k)} onChange={() => toggle(a + '.' + k)} /></td>)}</tr>)}</tbody></table>
      <p className="muted">These rules are enforced by the server on every request, not only by hiding menu items.</p>
    </div>
  );
}

export function UsersPage() {
  const { t, can, toast, confirm, user, lang } = useAdmin(); const f = useFetch('/api/admin/users'); const roles = useFetch('/api/admin/roles'); const [tab, setTab] = useState('users'); const [form, setForm] = useState(null); const [pwForm, setPwForm] = useState(false); const edit = can('users.edit');
  const roleOpts = (roles.data?.roles || []).map((r) => ({ value: r.name, label: r.label }));
  const fields = (isNew) => [{ name: 'username', label: 'Username', required: true, half: true, ...(isNew ? {} : { disabled: true }) }, { name: 'name', label: 'Name', required: true, half: true }, { name: 'email', label: 'Email', type: 'email', half: true },
    { name: 'role', label: 'Role', type: 'select', options: roleOpts, half: true, required: true }, { name: 'password', label: isNew ? 'Password' : 'New password (leave blank to keep)', type: 'password', required: isNew, help: 'At least 10 characters, with letters and numbers.' }, { name: 'active', label: 'Account enabled', type: 'checkbox', default: true }];
  const save = async (v) => { const body = { ...v }; if (!body.password) delete body.password; if (form.id) await api.put('/api/admin/users/' + form.id, body); else await api.post('/api/admin/users', body); toast('Saved'); setForm(null); f.reload(); };
  const del = async (u) => { if (await confirm({ title: 'Delete user?', message: `${u.username} will lose access immediately.` })) { try { await api.del('/api/admin/users/' + u.id); toast('Deleted'); f.reload(); } catch (e) { toast(e.message, 'err'); } } };
  return (<>
    <PageHead title="Users & Permissions"><Btn icon="shield" onClick={() => setPwForm(true)}>Change my password</Btn>{edit && <Btn kind="primary" icon="plus" onClick={() => setForm({ active: true, role: 'editor' })}>{t('Add')}</Btn>}</PageHead>
    <Tabs tabs={[{ id: 'users', label: 'Users' }, { id: 'roles', label: 'Roles & permissions' }]} value={tab} onChange={setTab} />
    {tab === 'users' ? <div className="card tbl-card">{f.error ? <ErrorState error={f.error} onRetry={f.refetch} /> : !f.data ? <Skeleton /> : <div className="tbl-scroll"><table className="tbl"><thead><tr><th>{t('Username')}</th><th>{t('Name')}</th><th>{t('Role')}</th><th>{t('Status')}</th><th>Last login</th><th className="acts">{t('Actions')}</th></tr></thead>
      <tbody>{f.data.map((u) => <tr key={u.id}><td><b>{u.username}</b>{u.id === user.id && <span className="bd bd-blue">you</span>}</td><td>{u.name}<small className="muted block">{u.email}</small></td><td><Badge v={u.role} tone="cyan" /></td><td><Badge v={u.active ? 'published' : 'draft'} tone={u.active ? 'green' : 'gray'} /></td><td>{fmtDateTime(u.last_login, lang)}</td>
        <td className="acts">{edit && <><button className="icon-btn" aria-label={t('Edit')} onClick={() => setForm(u)}><Icon n="edit" /></button>{u.id !== user.id && <button className="icon-btn danger" aria-label={t('Delete')} onClick={() => del(u)}><Icon n="trash" /></button>}</>}</td></tr>)}</tbody></table></div>}</div>
      : roles.data ? <Roles roles={roles.data} onChange={roles.reload} /> : roles.error ? <ErrorState error={roles.error} onRetry={roles.refetch} /> : <Skeleton />}
    {form && <FormModal title={form.id ? t('Edit') + ': ' + form.username : 'New user'} fields={fields(!form.id).map((x) => (x.disabled ? { ...x, help: 'Cannot be changed.' } : x))} initial={form} onSave={save} onClose={() => setForm(null)} />}
    {pwForm && <FormModal title="Change my password" fields={[{ name: 'current', label: 'Current password', type: 'password', required: true }, { name: 'password', label: 'New password', type: 'password', required: true, help: 'At least 10 characters, with letters and numbers.' }]} initial={{}} onClose={() => setPwForm(false)} onSave={async (v) => { await api.post('/api/admin/account/password', v); toast('Password changed'); setPwForm(false); }} />}
  </>);
}

export function Logs() {
  const { t, lang } = useAdmin(); const list = useList('/api/admin/activity', { pageSize: 25 });
  const cols = [{ key: 'd', label: 'Date', render: (a) => fmtDateTime(a.created_at, lang) }, { key: 'u', label: 'User', render: (a) => <b>{a.username}</b> }, { key: 'act', label: 'Action', render: (a) => <span className="bd bd-blue">{a.action.replace(/[._]/g, ' ')}</span> },
    { key: 'e', label: 'Item', render: (a) => (a.entity ? `${a.entity}${a.entity_id ? ' #' + a.entity_id : ''}` : '—') }, { key: 'det', label: 'Details', render: (a) => a.details || '—' }];
  return (<><PageHead title="Activity Logs" sub="Every change made in the dashboard is recorded here." />
    <DataTable list={list} columns={cols} filters={<FilterSelect list={list} name="entity" label="Item" options={['product', 'category', 'order', 'customer', 'coupon', 'review', 'message', 'media', 'settings', 'user', 'role']} />} empty={<Empty title="No activity yet" />} /></>);
}
