import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../api.js';
import { AR } from './i18n.js';

export const AdminCtx = createContext(null);
export const useAdmin = () => useContext(AdminCtx);

// ---------------------------------------------------------------- icons
const P = {
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z', globe: 'M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18', tag: 'M3 12V4h8l10 10-8 8zM7.5 7.5h.01',
  cart: 'M3 4h3l2 12h10l2-8H7M10 20h.01M17 20h.01', users: 'M9 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM2 20c0-3.5 3-6 7-6s7 2.5 7 6M17 4.5a3.5 3.5 0 010 6.5M18 14c2.5.5 4 2.5 4 6', chart: 'M4 20V10M10 20V4M16 20v-8M22 20H2',
  coupon: 'M3 9a2 2 0 002-2h14a2 2 0 002 2v6a2 2 0 00-2 2H5a2 2 0 00-2-2zM10 9l4 6M10 9.01M14 15.01', star: 'M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.3l1-6.2L3 9.7l6.2-.9z',
  mail: 'M3 6h18v12H3zM3 7l9 6 9-6', layout: 'M3 4h18v16H3zM3 9h18M9 9v11', image: 'M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 5M8.5 9.5h.01', search: 'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5',
  palette: 'M12 3a9 9 0 100 18c1.5 0 2-1 1.5-2s0-2 1.5-2h2A4 4 0 0021 11c0-4-4-8-9-8zM7.5 11h.01M10 7h.01M15 7h.01', cog: 'M12 9a3 3 0 100 6 3 3 0 000-6zM19 12l2-1-2-4-2 .5-1.5-1L15 4H9l-.5 2.5-1.5 1L5 7l-2 4 2 1v1l-2 1 2 4 2-.5 1.5 1L9 20h6l.5-2.5 1.5-1 2 .5 2-4-2-1z',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z', list: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01', plus: 'M12 5v14M5 12h14', edit: 'M4 20l1-5L16 4l4 4L9 19zM14 6l4 4',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6', copy: 'M9 9h11v11H9zM5 15V4h11', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 100 6 3 3 0 000-6z',
  check: 'M5 12l5 5 9-10', x: 'M6 6l12 12M18 6L6 18', menu: 'M4 7h16M4 12h16M4 17h16', chevron: 'M9 6l6 6-6 6', down: 'M6 9l6 6 6-6', download: 'M12 4v12M7 11l5 5 5-5M4 20h16', upload: 'M12 16V4M7 9l5-5 5 5M4 20h16',
  sun: 'M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5', moon: 'M20 14A8 8 0 0110 4a8 8 0 1010 10z',
  out: 'M9 4H4v16h5M16 8l4 4-4 4M20 12H9', bell: 'M6 16V11a6 6 0 1112 0v5l2 2H4zM10 21h4', dollar: 'M12 3v18M16 7c-1-1.5-2.5-2-4-2-2.5 0-4 1.2-4 3s1.5 2.5 4 3 4 1.2 4 3-1.5 3-4 3c-1.5 0-3-.5-4-2',
  trend: 'M3 17l6-6 4 4 8-8M15 7h6v6', link: 'M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1', home: 'M3 11l9-8 9 8M5 10v10h14V10', warn: 'M12 3l10 18H2zM12 10v5M12 18h.01',
};
export function Icon({ n, size = 18 }) {
  return <svg className="ic" viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={P[n] || P.grid} /></svg>;
}

// ---------------------------------------------------------------- formatting
export const fmtDate = (s, lang) => (s ? new Date(s).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
export const fmtDateTime = (s, lang) => (s ? new Date(s).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
export const fmtSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
export const useMoney = () => { const { currency } = useAdmin(); return (n) => (currency.symbol || '$') + Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 }); };
export const STATUS_LABEL = { new: 'New', pending_confirmation: 'Pending confirmation', awaiting_payment: 'Awaiting payment', processing: 'Processing', completed: 'Completed', cancelled: 'Cancelled', refunded: 'Refunded', unpaid: 'Unpaid', pending: 'Pending', paid: 'Paid', failed: 'Failed', draft: 'Draft', published: 'Published', approved: 'Approved', rejected: 'Rejected', hidden: 'Hidden', in_progress: 'In progress', replied: 'Replied', closed: 'Closed', low: 'Low', normal: 'Normal', high: 'High' };
const TONE = { new: 'blue', pending_confirmation: 'gold', awaiting_payment: 'gold', processing: 'cyan', completed: 'green', cancelled: 'red', refunded: 'gray', unpaid: 'gold', pending: 'gold', paid: 'green', failed: 'red', draft: 'gray', published: 'green', approved: 'green', rejected: 'red', hidden: 'gray', in_progress: 'cyan', replied: 'green', closed: 'gray', high: 'red', normal: 'blue', low: 'gray' };
export function Badge({ v, tone }) { const { t } = useAdmin(); return <span className={'bd bd-' + (tone || TONE[v] || 'gray')}>{t(STATUS_LABEL[v] || v)}</span>; }

// ---------------------------------------------------------------- toasts + confirm
export function useOverlays() {
  const [toasts, setToasts] = useState([]); const [dlg, setDlg] = useState(null); const id = useRef(0);
  const toast = useCallback((msg, kind = 'ok') => { const k = ++id.current; setToasts((x) => [...x, { k, msg, kind }]); setTimeout(() => setToasts((x) => x.filter((y) => y.k !== k)), kind === 'err' ? 6000 : 3200); }, []);
  const confirm = useCallback((o) => new Promise((resolve) => setDlg({ ...o, resolve })), []);
  const node = (<>
    <div className="toasts" role="status" aria-live="polite">{toasts.map((x) => <div key={x.k} className={'toast ' + x.kind}><Icon n={x.kind === 'err' ? 'warn' : 'check'} />{x.msg}</div>)}</div>
    {dlg && <Confirm {...dlg} onDone={(v) => { dlg.resolve(v); setDlg(null); }} />}
  </>);
  return { toast, confirm, node };
}
function Confirm({ title, message, confirmLabel, danger = true, onDone }) {
  const { t } = useAdmin();
  useEffect(() => { const k = (e) => e.key === 'Escape' && onDone(false); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onDone]);
  return (
    <div className="mdl-back" onMouseDown={(e) => e.target === e.currentTarget && onDone(false)}>
      <div className="mdl sm" role="alertdialog" aria-modal="true" aria-label={title}>
        <h3>{t(title || 'Are you sure?')}</h3><p className="muted">{message}</p>
        <div className="mdl-foot"><button className="btn" onClick={() => onDone(false)} autoFocus>{t('Cancel')}</button><button className={'btn ' + (danger ? 'danger' : 'primary')} onClick={() => onDone(true)}>{t(confirmLabel || 'Yes, delete')}</button></div>
      </div>
    </div>
  );
}

export function Modal({ title, onClose, children, footer, wide }) {
  const { t } = useAdmin(); const ref = useRef(null);
  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape') onClose(); if (e.key === 'Tab' && ref.current) { const f = ref.current.querySelectorAll('button,input,select,textarea,a[href]'); if (!f.length) return; const first = f[0], last = f[f.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); } } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  useEffect(() => { const el = ref.current?.querySelector('input,select,textarea'); el?.focus(); }, []);
  return (
    <div className="mdl-back" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={'mdl' + (wide ? ' wide' : '')} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
        <div className="mdl-head"><h3>{title}</h3><button className="icon-btn" onClick={onClose} aria-label={t('Close')}><Icon n="x" /></button></div>
        <div className="mdl-body">{children}</div>
        {footer && <div className="mdl-foot">{footer}</div>}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- states
export const Skeleton = ({ rows = 5 }) => <div className="skel-wrap" aria-busy="true" aria-label="Loading">{Array.from({ length: rows }).map((_, i) => <div key={i} className="skel" style={{ width: 100 - (i % 3) * 12 + '%' }} />)}</div>;
export function Empty({ title, hint, action }) { const { t } = useAdmin(); return <div className="empty"><Icon n="list" size={30} /><b>{t(title || 'Nothing here yet')}</b>{hint && <p className="muted">{hint}</p>}{action}</div>; }
export function ErrorState({ error, onRetry }) { const { t } = useAdmin(); return <div className="empty err"><Icon n="warn" size={30} /><b>{error}</b>{onRetry && <button className="btn" onClick={onRetry}>{t('Retry')}</button>}</div>; }

// ---------------------------------------------------------------- data hooks
export function useFetch(url, params, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: '' }); const n = useRef(0);
  const key = JSON.stringify(params || {});
  const load = useCallback(async (silent) => {
    const k = ++n.current; if (!silent) setState((s) => ({ ...s, loading: true, error: '' }));
    try { const data = await api.get(url, params); if (k === n.current) setState({ data, loading: false, error: '' }); }
    catch (e) { if (k === n.current) { if (e.status === 401) window.dispatchEvent(new Event('ce-unauth')); setState((s) => ({ ...s, loading: false, error: e.message })); } }
  }, [url, key, ...deps]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  return { ...state, reload: () => load(true), refetch: () => load(false) };
}
export function useDebounced(v, ms = 300) { const [d, setD] = useState(v); useEffect(() => { const t = setTimeout(() => setD(v), ms); return () => clearTimeout(t); }, [v, ms]); return d; }

// list state: search, sort, filters, page
export function useList(url, defaults = {}) {
  const [p, setP] = useState({ page: 1, pageSize: 15, q: '', ...defaults }); const q = useDebounced(p.q);
  const f = useFetch(url, { ...p, q });
  const set = (patch) => setP((x) => ({ ...x, page: 'page' in patch ? patch.page : 1, ...patch }));
  return { ...f, params: p, set, setPage: (page) => setP((x) => ({ ...x, page })) };
}

// ---------------------------------------------------------------- table
export function DataTable({ list, columns, onRow, selectable, selected = [], onSelect, empty, rowKey = 'id', toolbar, filters }) {
  const { t } = useAdmin(); const { data, loading, error, params, set, setPage, refetch } = list;
  const rows = data?.rows || [];
  const allSel = rows.length > 0 && rows.every((r) => selected.includes(r[rowKey]));
  return (
    <div className="card tbl-card">
      <div className="tbl-tools">
        <div className="search-in"><Icon n="search" /><input type="search" placeholder={t('Search')} aria-label={t('Search')} value={params.q} onChange={(e) => set({ q: e.target.value })} /></div>
        {filters}<div className="grow" />{toolbar}
      </div>
      {error ? <ErrorState error={error} onRetry={refetch} /> : loading && !data ? <Skeleton /> : rows.length === 0 ? (empty || <Empty />) : (
        <div className={'tbl-scroll' + (loading ? ' dim' : '')}>
          <table className="tbl">
            <thead><tr>
              {selectable && <th className="sel"><input type="checkbox" aria-label="Select all" checked={allSel} onChange={(e) => onSelect(e.target.checked ? rows.map((r) => r[rowKey]) : [])} /></th>}
              {columns.map((c) => <th key={c.key} className={c.cls}>{c.sort ? <button className="th-sort" onClick={() => set({ sort: c.sort, dir: params.sort === c.sort && params.dir === 'asc' ? 'desc' : 'asc' })} aria-label={'Sort by ' + c.label}>{t(c.label)}{params.sort === c.sort ? (params.dir === 'asc' ? ' ↑' : ' ↓') : ''}</button> : t(c.label)}</th>)}
            </tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r[rowKey]} className={onRow ? 'click' : ''} onClick={onRow ? () => onRow(r) : undefined} onKeyDown={onRow ? (e) => e.key === 'Enter' && onRow(r) : undefined} tabIndex={onRow ? 0 : undefined}>
                {selectable && <td className="sel" onClick={(e) => e.stopPropagation()}><input type="checkbox" aria-label="Select row" checked={selected.includes(r[rowKey])} onChange={(e) => onSelect(e.target.checked ? [...selected, r[rowKey]] : selected.filter((x) => x !== r[rowKey]))} /></td>}
                {columns.map((c) => <td key={c.key} className={c.cls} onClick={c.stop ? (e) => e.stopPropagation() : undefined}>{c.render ? c.render(r) : r[c.key]}</td>)}
              </tr>))}</tbody>
          </table>
        </div>
      )}
      {data && data.total > 0 && (
        <div className="pager"><span className="muted">{t('Rows')} {(data.page - 1) * data.pageSize + 1}–{Math.min(data.total, data.page * data.pageSize)} {t('of')} {data.total}</span><div className="grow" />
          <select aria-label="Rows per page" value={params.pageSize} onChange={(e) => set({ pageSize: +e.target.value })}>{[10, 15, 25, 50, 100].map((n) => <option key={n}>{n}</option>)}</select>
          <button className="btn sm" disabled={data.page <= 1} onClick={() => setPage(data.page - 1)} aria-label="Previous page"><Icon n="chevron" size={14} /></button>
          <span>{t('Page')} {data.page}/{data.pages}</span>
          <button className="btn sm" disabled={data.page >= data.pages} onClick={() => setPage(data.page + 1)} aria-label="Next page"><Icon n="chevron" size={14} /></button>
        </div>
      )}
    </div>
  );
}
export const FilterSelect = ({ list, name, label, options }) => { const { t } = useAdmin(); return <select className="flt" aria-label={label} value={list.params[name] || ''} onChange={(e) => list.set({ [name]: e.target.value })}><option value="">{t(label)}</option>{options.map((o) => <option key={o.value ?? o} value={o.value ?? o}>{t(o.label ?? STATUS_LABEL[o] ?? o)}</option>)}</select>; };

// ---------------------------------------------------------------- page chrome
export function PageHead({ title, sub, children }) { const { t } = useAdmin(); return <div className="page-head"><div><h1>{t(title)}</h1>{sub && <p className="muted">{sub}</p>}</div><div className="head-actions">{children}</div></div>; }
export const Btn = ({ icon, children, kind, busy, ...p }) => <button {...p} disabled={p.disabled || busy} className={'btn ' + (kind || '') + (p.className ? ' ' + p.className : '')}>{icon && <Icon n={icon} size={16} />}{children}</button>;
export function Stat({ icon, label, value, sub, tone = 'blue' }) { const { t } = useAdmin(); return <div className={'stat card tone-' + tone}><span className="stat-ic"><Icon n={icon} /></span><div><div className="stat-l">{t(label)}</div><div className="stat-v">{value}</div>{sub && <div className="stat-s muted">{sub}</div>}</div></div>; }
export const download = (url) => { const a = document.createElement('a'); a.href = url; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); };

// ---------------------------------------------------------------- forms
const toLines = (v) => (Array.isArray(v) ? v.join('\n') : v || '');
export function FormModal({ title, fields, initial, onSave, onClose, wide, saveLabel, children }) {
  const { t, toast } = useAdmin();
  const [v, setV] = useState(() => { const o = { ...initial }; fields.forEach((f) => { if (f.type === 'lines' || f.type === 'images') o[f.name] = toLines(o[f.name]); if (f.type === 'faq') o[f.name] = (o[f.name] || []).map((x) => x.q + ' | ' + x.a).join('\n'); if (o[f.name] === undefined || o[f.name] === null) o[f.name] = f.type === 'checkbox' ? !!f.default : f.default ?? ''; }); return o; });
  const [errs, setErrs] = useState({}); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [pick, setPick] = useState(null);
  const set = (n, val) => { setV((x) => ({ ...x, [n]: val })); setErrs((e) => ({ ...e, [n]: '' })); };
  const submit = async (e) => {
    e?.preventDefault(); const bad = {};
    fields.forEach((f) => { if (f.show && !f.show(v)) return; const val = v[f.name]; if (f.required && (val === '' || val == null)) bad[f.name] = t('Required'); if (f.type === 'number' && val !== '' && val != null && Number.isNaN(Number(val))) bad[f.name] = 'Enter a number'; });
    setErrs(bad); if (Object.keys(bad).length) { document.querySelector('.fld.bad input,.fld.bad select,.fld.bad textarea')?.focus(); return; }
    const out = { ...v };
    fields.forEach((f) => { if (f.type === 'lines' || f.type === 'images') out[f.name] = String(v[f.name] || '').split('\n').map((x) => x.trim()).filter(Boolean); if (f.type === 'faq') out[f.name] = String(v[f.name] || '').split('\n').map((x) => x.trim()).filter(Boolean).map((l) => { const i = l.indexOf('|'); return i < 0 ? { q: l, a: '' } : { q: l.slice(0, i).trim(), a: l.slice(i + 1).trim() }; }); });
    setBusy(true); setErr('');
    try { await onSave(out); } catch (er) { setErr(er.message); setBusy(false); return; } setBusy(false);
  };
  return (
    <Modal title={title} onClose={onClose} wide={wide} footer={<><span className="save-state">{err && <span className="err-t">{err}</span>}</span><button className="btn" onClick={onClose}>{t('Cancel')}</button><button className="btn primary" disabled={busy} onClick={submit}>{busy ? t('Saving…') : t(saveLabel || 'Save')}</button></>}>
      <form onSubmit={submit} className="form-grid" noValidate>
        {fields.filter((f) => !f.show || f.show(v)).map((f) => (
          <div key={f.name} className={'fld' + (f.half ? ' half' : '') + (errs[f.name] ? ' bad' : '')}>
            {f.type === 'checkbox' ? <label className="chk"><input type="checkbox" checked={!!v[f.name]} onChange={(e) => set(f.name, e.target.checked)} />{t(f.label)}</label> : <>
              <label htmlFor={'f-' + f.name}>{t(f.label)}{f.required && <b className="req"> *</b>}</label>
              {f.type === 'textarea' || f.type === 'lines' || f.type === 'faq' || f.type === 'images' ? <textarea id={'f-' + f.name} rows={f.rows || (f.type === 'textarea' ? 4 : 3)} value={v[f.name]} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
                : f.type === 'select' ? <select id={'f-' + f.name} value={v[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)}>{f.placeholder && <option value="">{f.placeholder}</option>}{f.options.map((o) => <option key={o.value} value={o.value}>{t(o.label)}</option>)}</select>
                : f.type === 'image' ? <div className="img-in"><input id={'f-' + f.name} value={v[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} placeholder="https://… or choose from library" />{v[f.name] && <img src={v[f.name]} alt="" />}<button type="button" className="btn sm" onClick={() => setPick({ name: f.name, multi: false })}><Icon n="image" size={15} />Library</button></div>
                : <input id={'f-' + f.name} type={f.type === 'number' ? 'number' : f.type || 'text'} step={f.type === 'number' ? 'any' : undefined} value={v[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} autoComplete={f.type === 'password' ? 'new-password' : 'off'} disabled={f.disabled} />}
              {f.type === 'images' && <button type="button" className="btn sm" style={{ marginTop: 6 }} onClick={() => setPick({ name: f.name, multi: true })}><Icon n="image" size={15} />Add from library</button>}
              {f.help && <small className="muted">{f.help}</small>}{errs[f.name] && <small className="err-t">{errs[f.name]}</small>}
            </>}
          </div>))}
        {children}
        <button type="submit" hidden />
      </form>
      {pick && <MediaPicker onClose={() => setPick(null)} onPick={(url) => { if (pick.multi) set(pick.name, (v[pick.name] ? v[pick.name] + '\n' : '') + url); else set(pick.name, url); setPick(null); toast('Image added'); }} />}
    </Modal>
  );
}

export function MediaPicker({ onClose, onPick }) {
  const { t, toast, can } = useAdmin(); const list = useList('/api/admin/media', { pageSize: 12 }); const fileRef = useRef(null); const [busy, setBusy] = useState(false);
  const up = async (files) => {
    if (!files.length) return; setBusy(true);
    try { const fd = new FormData(); [...files].forEach((f) => fd.append('files', f)); const r = await api.upload('/api/admin/media', fd); toast('Uploaded'); list.reload(); if (r.files.length === 1) onPick(r.files[0].url); } catch (e) { toast(e.message, 'err'); } setBusy(false);
  };
  const rows = list.data?.rows || [];
  return (
    <Modal title="Media library" onClose={onClose} wide footer={<button className="btn" onClick={onClose}>{t('Close')}</button>}>
      <div className="tbl-tools"><div className="search-in"><Icon n="search" /><input placeholder={t('Search')} value={list.params.q} onChange={(e) => list.set({ q: e.target.value })} /></div><div className="grow" />
        {can('media.edit') && <><input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/x-icon" multiple hidden onChange={(e) => { up(e.target.files); e.target.value = ''; }} /><Btn kind="primary" icon="upload" busy={busy} onClick={() => fileRef.current.click()}>{busy ? t('Saving…') : t('Upload')}</Btn></>}</div>
      {list.error ? <ErrorState error={list.error} onRetry={list.refetch} /> : list.loading && !list.data ? <Skeleton rows={3} /> : rows.length === 0 ? <Empty title="No images yet" hint="Upload an image to use it here." /> :
        <div className="media-grid">{rows.map((m) => <button key={m.id} type="button" className="media-tile" onClick={() => onPick(m.url)} title={m.original}><img src={m.url} alt={m.original} loading="lazy" /><span>{m.original}</span></button>)}</div>}
    </Modal>
  );
}

export function Tabs({ tabs, value, onChange }) { const { t } = useAdmin(); return <div className="tabs" role="tablist">{tabs.map((x) => <button key={x.id} role="tab" aria-selected={value === x.id} className={value === x.id ? 'on' : ''} onClick={() => onChange(x.id)}>{t(x.label)}</button>)}</div>; }

// Settings form state with a save indicator and unsaved-changes flag
export function useSettings(group) {
  const { toast } = useAdmin(); const f = useFetch('/api/admin/settings/' + group);
  const [v, setV] = useState(null); const [dirty, setDirty] = useState(false); const [busy, setBusy] = useState(false);
  useEffect(() => { if (f.data) { setV(f.data); setDirty(false); } }, [f.data]);
  const patch = (path, val) => { setV((s) => { const n = JSON.parse(JSON.stringify(s)); let o = n; const ks = path.split('.'); ks.slice(0, -1).forEach((k) => { o = o[k]; }); o[ks.at(-1)] = val; return n; }); setDirty(true); };
  const save = async (extra) => { setBusy(true); try { await api.put('/api/admin/settings/' + group, extra || v); toast('Saved'); setDirty(false); f.reload(); } catch (e) { toast(e.message, 'err'); } setBusy(false); };
  return { ...f, v, patch, dirty, busy, save, setV: (x) => { setV(x); setDirty(true); } };
}
export function SaveBar({ s }) { const { t } = useAdmin(); return <div className="savebar"><span className={'save-state' + (s.dirty ? ' dirty' : '')}>{s.busy ? t('Saving…') : s.dirty ? t('Unsaved changes') : t('Saved')}</span><Btn kind="primary" busy={s.busy} disabled={!s.dirty} icon="check" onClick={() => s.save()}>{t('Save changes')}</Btn></div>; }
export function SettingsLoader({ s, children }) { if (s.error) return <ErrorState error={s.error} onRetry={s.refetch} />; if (!s.v) return <Skeleton />; return typeof children === "function" ? children() : children; }
export const Field = ({ label, children, help, half }) => { const { t } = useAdmin(); return <div className={'fld' + (half ? ' half' : '')}><label>{t(label)}</label>{children}{help && <small className="muted">{help}</small>}</div>; };
export const Toggle = ({ label, checked, onChange }) => { const { t } = useAdmin(); return <label className="chk"><input type="checkbox" checked={!!checked} onChange={(e) => onChange(e.target.checked)} />{t(label)}</label>; };
export function ImageField({ label, value, onChange }) { const [open, setOpen] = useState(false); const { t } = useAdmin(); return <Field label={label}><div className="img-in"><input value={value || ''} onChange={(e) => onChange(e.target.value)} placeholder="https://… or choose from library" />{value && <img src={value} alt="" />}<button type="button" className="btn sm" onClick={() => setOpen(true)}><Icon n="image" size={15} />{t('Library')}</button></div>{open && <MediaPicker onClose={() => setOpen(false)} onPick={(u) => { onChange(u); setOpen(false); }} />}</Field>; }
