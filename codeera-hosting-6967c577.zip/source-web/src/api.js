let csrf = '';
export const setCsrf = (v) => { csrf = v || ''; };

async function call(method, url, body, isForm) {
  const opts = { method, credentials: 'same-origin', headers: {} };
  if (csrf && method !== 'GET') opts.headers['x-csrf-token'] = csrf;
  if (body !== undefined) {
    if (isForm) opts.body = body;
    else { opts.headers['content-type'] = 'application/json'; opts.body = JSON.stringify(body); }
  }
  let res;
  try { res = await fetch(url, opts); } catch { throw Object.assign(new Error('Cannot reach the server. Check your connection.'), { status: 0 }); }
  const type = res.headers.get('content-type') || '';
  const data = type.includes('json') ? await res.json().catch(() => ({})) : await res.text();
  if (!res.ok) throw Object.assign(new Error((data && data.error) || 'Request failed.'), { status: res.status });
  return data;
}
const qs = (o = {}) => {
  const p = new URLSearchParams();
  Object.entries(o).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') p.set(k, v); });
  const s = p.toString(); return s ? '?' + s : '';
};
export const api = {
  get: (u, params) => call('GET', u + qs(params)),
  post: (u, b) => call('POST', u, b ?? {}),
  put: (u, b) => call('PUT', u, b ?? {}),
  del: (u, params) => call('DELETE', u + qs(params)),
  upload: (u, form) => call('POST', u, form, true),
  qs,
};
export const pub = {
  get: (u) => api.get('/api/public' + u),
  post: (u, b) => api.post('/api/public' + u, b),
};
