import React, { lazy, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Site } from './site/Site.jsx';
const Admin = lazy(() => import('./admin/AdminApp.jsx'));

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route path="/admin/*" element={<Suspense fallback={<div style={{ minHeight: '100vh', background: '#020817' }} />}><Admin /></Suspense>} />
      <Route path="*" element={<Site />} />
    </Routes>
  </BrowserRouter>
);
