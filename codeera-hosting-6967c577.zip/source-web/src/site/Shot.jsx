import React from 'react';

// A drawn browser preview of a catalog website. variant 0..2 gives gallery variety.
export function Shot({ p, variant = 0, big = false }) {
  const a = p.accent || '#28D9FF';
  if (p.thumbnail && variant === 0) return <div className={'sh sh-img' + (big ? ' big' : '')}><img src={p.thumbnail} alt={p.name} loading="lazy" /></div>;
  p = { ...p, hue: p.hue || '#0a1f44', kind: p.kind || 'business' };
  const bar = (w, o = 0.5, h = 6) => <i className="sh-bar" style={{ width: w, height: h, opacity: o }} />;
  let body;
  const k = p.kind;
  if (variant === 1) {
    body = (
      <div className="sh-grid3">{[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="sh-tile" style={{ background: `linear-gradient(${140 + i * 20}deg, ${a}33, transparent)` }}>{bar('60%', .6)}{bar('40%', .3)}</div>)}</div>
    );
  } else if (variant === 2) {
    body = (
      <div className="sh-form">{bar('50%', .8, 10)}{bar('90%', .25, 18)}{bar('90%', .25, 18)}{bar('90%', .25, 18)}<b className="sh-btn" style={{ background: a }} /></div>
    );
  } else if (k === 'dashboard') {
    body = (
      <div className="sh-dash"><div className="sh-side">{[0, 1, 2, 3, 4].map((i) => bar('70%', .35))}</div>
        <div className="sh-main"><div className="sh-kpis">{[0, 1, 2].map((i) => <div key={i} className="sh-kpi">{bar('50%', .5)}{bar('70%', .9, 10)}</div>)}</div>
          <div className="sh-chart">{[40, 62, 48, 80, 66, 92, 74, 100].map((h, i) => <b key={i} style={{ height: h + '%', background: `linear-gradient(${a}, ${a}22)` }} />)}</div></div></div>
    );
  } else if (k === 'booking') {
    body = (
      <div className="sh-book"><div className="sh-cal">{Array.from({ length: 28 }).map((_, i) => <b key={i} style={{ background: i === 11 ? a : 'rgba(255,255,255,.08)' }} />)}</div>
        <div className="sh-slots">{[0, 1, 2, 3].map((i) => <div key={i} className="sh-slot" style={{ borderColor: i === 1 ? a : 'rgba(255,255,255,.15)' }} />)}</div></div>
    );
  } else if (k === 'shop') {
    body = (
      <div className="sh-shop">{bar('46%', .9, 10)}<div className="sh-grid4">{[0, 1, 2, 3].map((i) => <div key={i} className="sh-prod"><b style={{ background: `radial-gradient(circle at 40% 35%, ${a}, ${a}22 70%)` }} />{bar('70%', .6)}{bar('40%', .3)}</div>)}</div></div>
    );
  } else if (k === 'portfolio') {
    body = (
      <div className="sh-mason">{[60, 90, 70, 100, 80, 64].map((h, i) => <b key={i} style={{ height: h, background: `linear-gradient(${120 + i * 35}deg, ${a}${i % 2 ? '55' : '99'}, #0006)` }} />)}</div>
    );
  } else if (k === 'restaurant') {
    body = (
      <div className="sh-hero"><div className="sh-copy">{bar('72%', .95, 12)}{bar('52%', .45)}<b className="sh-btn" style={{ background: a }} /></div><div className="sh-plate" style={{ borderColor: a }}><span style={{ background: `radial-gradient(circle, ${a}, #7a4a1a)` }} /></div></div>
    );
  } else if (k === 'custom') {
    body = (
      <div className="sh-code">{[80, 55, 70, 40, 62, 30, 75].map((w, i) => <div key={i} style={{ paddingLeft: (i % 3) * 14 }}>{bar(w + '%', i % 2 ? .35 : .7, 6)}</div>)}</div>
    );
  } else {
    body = (
      <div className="sh-hero"><div className="sh-copy">{bar('78%', .95, 14)}{bar('60%', .5, 8)}<b className="sh-btn" style={{ background: a }} /></div><div className="sh-orb" style={{ background: `radial-gradient(circle at 35% 30%, ${a}, transparent 70%)` }} /></div>
    );
  }
  const cards = (k === 'restaurant' || k === 'business' || k === 'landing') && variant === 0;
  return (
    <div className={'sh' + (big ? ' big' : '')} style={{ background: `linear-gradient(160deg, ${p.hue}, #020817)` }}>
      <div className="sh-top"><u /><u /><u /><span>{p.name.toLowerCase().replace(/ /g, '')}.com</span></div>
      <div className="sh-nav"><b style={{ color: a }}>{p.name}</b><em>{bar('14px', .4, 4)}{bar('14px', .4, 4)}{bar('14px', .4, 4)}</em></div>
      <div className="sh-body">{body}</div>
      {cards && <div className="sh-cards">{[0, 1, 2].map((i) => <div key={i} style={{ background: `linear-gradient(${150 + i * 30}deg, ${a}44, rgba(255,255,255,.04))` }}>{bar('60%', .6)}{bar('35%', .3)}</div>)}</div>}
    </div>
  );
}

const P = {
  code: 'M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16',
  cart: 'M3 4h3l2 12h10l2-8H7M10 20a1 1 0 100 .01M17 20a1 1 0 100 .01',
  dish: 'M3 14h18a9 9 0 01-18 0zM12 5v3M9 20h6',
  chart: 'M4 20V10M10 20V4M16 20v-8M22 20H2',
  rocket: 'M12 3c4 2 6 6 5 11l-3 3H10l-3-3c-1-5 1-9 5-11zM9 18l-2 3M15 18l2 3M12 9a1.5 1.5 0 100 .01',
  building: 'M4 21V6l8-3 8 3v15M9 21v-5h6v5M8 10h2M14 10h2M8 13h2M14 13h2',
  pen: 'M4 20l1-5L16 4l4 4L9 19zM14 6l4 4',
  sliders: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M6 14v6',
  spark: 'M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z',
};
export function Icon({ n }) {
  return <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d={P[n] || P.code} /></svg>;
}
