import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import { Routes, Route, Link, useNavigate, useParams, useLocation } from 'react-router-dom';
import { pub } from '../api.js';
import { Hero, Reveal, scrollToId } from './parts.jsx';
import { Icon, Shot } from './Shot.jsx';
import './site.css';

const Ctx = createContext(null);
const useSite = () => useContext(Ctx);
const FONTS = { inter: "'Inter','Segoe UI','Noto Sans Arabic',system-ui,sans-serif", serif: "Georgia,'Times New Roman','Noto Naskh Arabic',serif", mono: "ui-monospace,'SFMono-Regular',Menlo,monospace" };
const RADIUS = { sm: '8px', md: '14px', lg: '20px' };

export function money(n, cfg) { const s = cfg?.general?.currencySymbol || '$'; const v = Number(n); return s + (Number.isInteger(v) ? v : v.toFixed(2)); }

function Provider({ children }) {
  const [cfg, setCfg] = useState(null);
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    try { const [c, p] = await Promise.all([pub.get('/config'), pub.get('/products')]); setCfg(c); setProducts(p); setError(''); } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  const [theme, setTheme] = useState(() => localStorage.getItem('ce-theme') || '');
  const mode = theme || cfg?.appearance?.defaultTheme || 'dark';
  const toggleTheme = () => { const n = mode === 'dark' ? 'light' : 'dark'; setTheme(n); localStorage.setItem('ce-theme', n); };
  return <Ctx.Provider value={{ cfg, products, error, reload: load, mode, toggleTheme }}>{children}</Ctx.Provider>;
}

function useTrack(productId) {
  const { pathname } = useLocation();
  useEffect(() => { pub.post('/track', productId ? { productId } : {}).catch(() => {}); }, [pathname, productId]);
}

function Shell({ children, maintenance }) {
  const { cfg, mode, toggleTheme } = useSite();
  const nav = useNavigate(); const loc = useLocation();
  const [menu, setMenu] = useState(false); const [scrolled, setScrolled] = useState(false); const [js, setJs] = useState(false);
  useEffect(() => { setJs(true); const f = () => setScrolled(window.scrollY > 40); window.addEventListener('scroll', f); return () => window.removeEventListener('scroll', f); }, []);
  const ap = cfg.appearance; const c = ap.colors; const g = cfg.general; const hp = cfg.homepage;
  const style = { '--ce-navy': c.navy, '--ce-dark': c.dark, '--ce-blue': c.blue, '--ce-cyan': c.cyan, '--ce-gold': c.gold, '--ce-white': c.white, '--ce-radius': RADIUS[ap.radius] || '20px', fontFamily: FONTS[ap.font] || FONTS.inter };
  const go = (id) => { setMenu(false); if (loc.pathname !== '/') { nav('/'); setTimeout(() => scrollToId(id), 120); } else scrollToId(id); };
  const links = [['Home', 'home'], ['Explore Websites', 'explore'], ['Services', 'services'], ['About', 'about'], ['Contact', 'contact']];
  const cls = ['ce-root', js && 'ce-js', mode === 'light' && 'ce-light', ap.animations === 'none' && 'ce-noanim', 'btn-' + ap.buttonStyle].filter(Boolean).join(' ');
  return (
    <div className={cls} style={style} id="top">
      {hp.announcement.enabled && hp.announcement.text && <div className="ce-announce">{hp.announcement.link ? <a href={hp.announcement.link}>{hp.announcement.text}</a> : hp.announcement.text}</div>}
      <header className={'ce-nav' + (scrolled || loc.pathname !== '/' || maintenance ? ' is-scrolled' : '')}>
        <Link to="/" className="ce-logo" onClick={() => window.scrollTo(0, 0)}>{g.logo ? <img src={g.logo} alt={g.siteName} className="ce-logoimg" /> : <>Code<span>Era</span></>}</Link>
        {!maintenance && <nav className="ce-links">{links.map(([n, id]) => <button type="button" key={id} onClick={() => go(id)}>{n}</button>)}
          {ap.allowThemeToggle && <button type="button" onClick={toggleTheme} aria-label="Toggle light or dark mode">{mode === 'dark' ? '☾' : '☀'}</button>}</nav>}
        {!maintenance && <button type="button" className="ce-burger" aria-label="Menu" aria-expanded={menu} onClick={() => setMenu(!menu)}><i /><i /></button>}
        {menu && <div className="ce-sheet">{links.map(([n, id]) => <button type="button" key={id} onClick={() => go(id)}>{n}</button>)}{ap.allowThemeToggle && <button type="button" onClick={toggleTheme}>{mode === 'dark' ? 'Light mode' : 'Dark mode'}</button>}</div>}
      </header>
      {children}
      <footer className="ce-footer"><b>{g.siteName === 'CodeEra' ? <>Code<span>Era</span></> : g.siteName}</b><p>{hp.footer.tagline}</p>
        {hp.footer.text && <small>{hp.footer.text}</small>}
        <div className="ce-social">{g.social.instagram && <a href={g.social.instagram} target="_blank" rel="noopener noreferrer">Instagram</a>}{g.social.tiktok && <a href={g.social.tiktok} target="_blank" rel="noopener noreferrer">TikTok</a>}{g.social.facebook && <a href={g.social.facebook} target="_blank" rel="noopener noreferrer">Facebook</a>}{g.social.handle && <span>@{g.social.handle}</span>}</div></footer>
    </div>
  );
}

function Card({ p, cfg, onDemo, onBuy }) {
  const price = p.sale ?? p.price;
  return (
    <article className="ce-card">
      <Link to={'/website/' + p.slug} className="ce-card-shot" aria-label={'Details for ' + p.name}><Shot p={p} /></Link>
      <div className="ce-card-body">
        <div className="ce-card-top"><span className="ce-chip">{p.category_name || 'Website'}</span>{p.concept ? <span className="ce-tag">Concept demo</span> : p.featured ? <span className="ce-tag">Featured</span> : null}</div>
        <h3>{p.name}</h3>
        <p>{p.short_desc}</p>
        <ul>{p.features.slice(0, 3).map((f) => <li key={f}>{f}</li>)}</ul>
        {p.rating ? <div className="ce-rate">★ {p.rating} <small>({p.review_count})</small></div> : null}
        <div className="ce-price">From <b>{money(price, cfg)}</b>{p.sale != null && <s>{money(p.price, cfg)}</s>} <small>{p.purchase_type === 'customization' ? 'Customization' : 'Ready-made license'}</small></div>
        <div className="ce-card-btns">
          <button type="button" className="ce-btn sm" onClick={() => onDemo(p)}>Demo</button>
          <Link className="ce-btn sm" to={'/website/' + p.slug}>Details</Link>
          <button type="button" className="ce-btn sm primary" disabled={p.availability !== 'available'} onClick={() => onBuy(p)}>{p.availability === 'sold_out' ? 'Sold out' : p.availability === 'coming_soon' ? 'Soon' : 'Request'}</button>
        </div>
      </div>
    </article>
  );
}

function Explore({ onBuy, onDemo }) {
  const { cfg, products } = useSite(); const hp = cfg.homepage;
  const [cat, setCat] = useState('All'); const [q, setQ] = useState('');
  const cats = ['All', ...cfg.categories.filter((c) => products.some((p) => p.category_id === c.id)).map((c) => c.name)];
  const list = useMemo(() => products.filter((p) => (cat === 'All' || p.category_name === cat) && (!hp.featuredOnly || p.featured) && (!q || (p.name + ' ' + p.short_desc + ' ' + p.tags.join(' ')).toLowerCase().includes(q.toLowerCase()))), [cat, q, products, hp.featuredOnly]);
  return (
    <section className="ce-sec" id="explore">
      <Reveal><p className="ce-kicker">EXPLORE OUR WORK</p><h2>{hp.exploreTitle1}<br /><em>{hp.exploreTitle2}</em></h2><p className="ce-lead">{hp.exploreSubtitle}</p></Reveal>
      <div className="ce-toolbar">
        {hp.showCategoryFilters && <div className="ce-filters" role="tablist" aria-label="Website categories">{cats.map((c) => <button key={c} type="button" role="tab" aria-selected={cat === c} className={'ce-pill' + (cat === c ? ' on' : '')} onClick={() => setCat(c)}>{c}</button>)}</div>}
        <input className="ce-search" type="search" placeholder="Search websites" aria-label="Search websites" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {list.length === 0 ? <p className="ce-empty">No websites match yet.</p> : <div className="ce-grid">{list.map((p, i) => <Reveal key={p.id} delay={(i % 4) * 60}><Card p={p} cfg={cfg} onDemo={onDemo} onBuy={onBuy} /></Reveal>)}</div>}
      <p className="ce-count">{list.length} of {products.length} websites</p>
    </section>
  );
}

function Services() {
  const { cfg } = useSite(); const items = cfg.homepage.services.filter((s) => s.visible !== false);
  if (!items.length) return null;
  return (
    <section className="ce-sec" id="services">
      <Reveal><p className="ce-kicker">SERVICES</p><h2>What we build</h2></Reveal>
      <div className="ce-svc">{items.map((s, i) => <Reveal key={s.t + i} delay={(i % 3) * 70}><div className="ce-svc-card"><span className="ce-ico"><Icon n={s.icon} /></span><h3>{s.t}</h3><p>{s.d}</p></div></Reveal>)}</div>
    </section>
  );
}

function About() {
  const { cfg } = useSite(); const a = cfg.homepage.about; const st = cfg.homepage.statistics; const tl = cfg.homepage.testimonialList;
  return (<>
    <section className="ce-about" id="about">
      <div className="ce-cols" aria-hidden="true">{[0, 1, 2, 3, 4, 5, 6].map((i) => <span key={i} style={{ animationDelay: i * 0.4 + 's', height: 120 + ((i * 37) % 80) + 'px' }} />)}</div>
      <Reveal className="ce-about-in">
        <p className="ce-kicker">{a.kicker}</p><h2>{a.headline1}<br /><em>{a.headline2}</em></h2><p className="ce-lead">{a.text}</p>
        {a.arabic && <p className="ce-ar" lang="ar" dir="rtl">{a.arabic}</p>}
        {st.enabled && <div className="ce-stats">{st.items.map((s) => <div key={s.label}><b>{s.value}</b><span>{s.label}</span></div>)}</div>}
      </Reveal>
    </section>
    {tl.length > 0 && <section className="ce-sec" id="reviews"><Reveal><p className="ce-kicker">WHAT CLIENTS SAY</p></Reveal>
      <div className="ce-svc">{tl.map((t, i) => <Reveal key={i} delay={(i % 3) * 70}><div className="ce-svc-card"><div className="ce-rate">{'★'.repeat(t.rating || 5)}</div><p>"{t.text}"</p><h3 style={{ marginTop: 12, fontSize: 15 }}>{t.name}{t.product ? <small style={{ color: 'var(--ce-mute)', fontWeight: 400 }}> · {t.product}</small> : null}</h3></div></Reveal>)}</div></section>}
  </>);
}

function Contact({ prefill }) {
  const { cfg } = useSite(); const g = cfg.general;
  const [f, setF] = useState({ name: '', email: '', phone: '', projectType: 'Ready-made website', budget: '$100 - $300', message: '', website: '' });
  const [state, setState] = useState({ busy: false, sent: false, err: '' });
  useEffect(() => { if (prefill) setF((s) => ({ ...s, message: prefill })); }, [prefill]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const ok = f.name.trim() && (f.email.trim() || f.phone.trim()) && f.message.trim().length >= 5;
  const submit = async (e) => {
    e.preventDefault(); if (!ok) return; setState({ busy: true, sent: false, err: '' });
    try { await pub.post('/messages', { ...f, type: f.projectType === 'Custom development' ? 'custom_request' : 'contact', subject: f.projectType }); setState({ busy: false, sent: true, err: '' }); }
    catch (er) { setState({ busy: false, sent: false, err: er.message }); }
  };
  const wa = 'https://wa.me/' + g.whatsapp + '?text=' + encodeURIComponent(`Hi CodeEra, I'm ${f.name}. ${f.projectType}. ${f.message}`);
  return (
    <section className="ce-sec" id="contact">
      <div className="ce-contact">
        <Reveal>
          <p className="ce-kicker">CONTACT</p><h2>Have an idea worthy <em>of the future?</em></h2><p className="ce-lead">Tell us what you want to build. We reply as soon as we can.</p>
          {g.whatsapp && <a className="ce-btn primary wa" href={'https://wa.me/' + g.whatsapp} target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a>}
          <div className="ce-social">{g.social.instagram && <a href={g.social.instagram} target="_blank" rel="noopener noreferrer">Instagram</a>}{g.social.tiktok && <a href={g.social.tiktok} target="_blank" rel="noopener noreferrer">TikTok</a>}{g.social.facebook && <a href={g.social.facebook} target="_blank" rel="noopener noreferrer">Facebook</a>}{g.social.handle && <span>@{g.social.handle}</span>}</div>
          {(g.email || g.phone) && <p className="ce-hint" style={{ marginTop: 18 }}>{g.email}{g.email && g.phone ? ' · ' : ''}{g.phone}</p>}
        </Reveal>
        <Reveal delay={100}>
          <form className="ce-form" onSubmit={submit} noValidate>
            {state.sent ? (
              <div className="ce-sent" role="status"><h3>Message received.</h3><p>Thank you. We will reply to you soon. Want a faster answer?</p>
                {g.whatsapp && <a className="ce-btn primary" href={wa} target="_blank" rel="noopener noreferrer">Also send on WhatsApp</a>}
                <button type="button" className="ce-btn" onClick={() => { setState({ busy: false, sent: false, err: '' }); setF({ ...f, message: '' }); }}>Send another</button></div>
            ) : (<>
              <label>Name<input value={f.name} onChange={set('name')} autoComplete="name" /></label>
              <div className="ce-two">
                <label>Email<input type="email" value={f.email} onChange={set('email')} autoComplete="email" /></label>
                <label>Phone / WhatsApp<input type="tel" value={f.phone} onChange={set('phone')} autoComplete="tel" /></label>
              </div>
              <div className="ce-two">
                <label>Project type<select value={f.projectType} onChange={set('projectType')}>{['Ready-made website', 'Customize a ready-made site', 'Custom development', 'Not sure yet'].map((o) => <option key={o}>{o}</option>)}</select></label>
                <label>Budget range<select value={f.budget} onChange={set('budget')}>{['Under $100', '$100 - $300', '$300 - $800', '$800+'].map((o) => <option key={o}>{o}</option>)}</select></label>
              </div>
              <label>Message<textarea rows={4} value={f.message} onChange={set('message')} /></label>
              <input className="ce-hp" tabIndex={-1} autoComplete="off" aria-hidden="true" value={f.website} onChange={set('website')} />
              {state.err && <p className="ce-err" role="alert">{state.err}</p>}
              <button type="submit" className="ce-btn primary" disabled={!ok || state.busy}>{state.busy ? 'Sending…' : "Let's build it."}</button>
              {!ok && <small className="ce-hint">Add your name, an email or phone number, and a short message.</small>}
            </>)}
          </form>
        </Reveal>
      </div>
    </section>
  );
}

function OrderModal({ p, onClose }) {
  const { cfg } = useSite(); const g = cfg.general; const methods = g.paymentMethods.filter((m) => m.enabled);
  const [f, setF] = useState({ name: '', email: '', phone: '', paymentMethod: methods[0]?.id || '', customization: '', coupon: '', website: '' });
  const [state, setState] = useState({ busy: false, err: '', done: null }); const [cp, setCp] = useState(null);
  const base = p.sale ?? p.price; const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  useEffect(() => { const k = (e) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  const check = async () => { setCp(null); try { const r = await pub.post('/coupon/check', { productId: p.id, code: f.coupon }); setCp({ ok: true, ...r }); } catch (e) { setCp({ ok: false, err: e.message }); } };
  const submit = async (e) => {
    e.preventDefault(); setState({ busy: true, err: '', done: null });
    try { const r = await pub.post('/orders', { ...f, productId: p.id }); setState({ busy: false, err: '', done: r }); } catch (er) { setState({ busy: false, err: er.message, done: null }); }
  };
  const total = cp?.ok ? cp.total : base;
  return (
    <div className="ce-modal" role="dialog" aria-modal="true" aria-label={'Request ' + p.name} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="ce-modal-in">
        <button type="button" className="ce-x" aria-label="Close" onClick={onClose}>×</button>
        {state.done ? (
          <div className="ce-sent"><h3>Request received.</h3><p>Your order code is <b>{state.done.code}</b> for {p.name} ({money(state.done.amount, cfg)}). We will contact you to confirm details and payment.</p>
            {g.whatsapp && <a className="ce-btn primary" target="_blank" rel="noopener noreferrer" href={'https://wa.me/' + g.whatsapp + '?text=' + encodeURIComponent(`Hi CodeEra, my order code is ${state.done.code} (${p.name}).`)}>Message us on WhatsApp</a>}
            <button type="button" className="ce-btn" onClick={onClose}>Close</button></div>
        ) : (
          <form className="ce-form flat" onSubmit={submit} noValidate>
            <h3 style={{ margin: 0 }}>Request {p.name}</h3>
            <p className="ce-hint" style={{ margin: 0 }}>No payment is taken on this page. We confirm your request and agree payment with you directly.</p>
            <label>Name<input value={f.name} onChange={set('name')} autoComplete="name" required /></label>
            <div className="ce-two"><label>Email<input type="email" value={f.email} onChange={set('email')} /></label><label>Phone / WhatsApp<input type="tel" value={f.phone} onChange={set('phone')} /></label></div>
            {methods.length > 0 && <label>Preferred payment<select value={f.paymentMethod} onChange={set('paymentMethod')}>{methods.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</select></label>}
            <label>Customization requests (optional)<textarea rows={3} value={f.customization} onChange={set('customization')} /></label>
            <div className="ce-coupon"><label>Coupon<input value={f.coupon} onChange={(e) => { setF({ ...f, coupon: e.target.value }); setCp(null); }} /></label><button type="button" className="ce-btn sm" disabled={!f.coupon} onClick={check}>Apply</button></div>
            {cp && (cp.ok ? <p className="ce-ok">Coupon applied: -{money(cp.discount, cfg)}</p> : <p className="ce-err">{cp.err}</p>)}
            <input className="ce-hp" tabIndex={-1} autoComplete="off" aria-hidden="true" value={f.website} onChange={set('website')} />
            {state.err && <p className="ce-err" role="alert">{state.err}</p>}
            <div className="ce-total"><span>Total</span><b>{money(total, cfg)}</b></div>
            <button className="ce-btn primary" type="submit" disabled={state.busy || !f.name.trim() || (!f.email.trim() && !f.phone.trim())}>{state.busy ? 'Sending…' : 'Send request'}</button>
          </form>
        )}
      </div>
    </div>
  );
}

function Stars({ value, onChange }) {
  return <div className="ce-stars" role="radiogroup" aria-label="Rating">{[1, 2, 3, 4, 5].map((n) => <button type="button" key={n} role="radio" aria-checked={value === n} className={n <= value ? 'on' : ''} onClick={() => onChange(n)} aria-label={n + ' stars'}>★</button>)}</div>;
}

function Details({ onBuy, onDemo }) {
  const { slug } = useParams(); const { cfg } = useSite();
  const [p, setP] = useState(null); const [err, setErr] = useState('');
  const [rv, setRv] = useState({ name: '', rating: 5, text: '', website: '' }); const [rvState, setRvState] = useState('');
  useEffect(() => { setP(null); pub.get('/products/' + slug).then(setP).catch((e) => setErr(e.message)); window.scrollTo(0, 0); }, [slug]);
  useTrack(p?.id);
  if (err) return <main className="ce-page"><Link className="ce-back" to="/">← Back to CodeEra</Link><h1 className="ce-ph">Not found</h1><p className="ce-lead">{err}</p></main>;
  if (!p) return <main className="ce-page"><div className="ce-skel" style={{ height: 380 }} /></main>;
  const price = p.sale ?? p.price;
  const submitReview = async (e) => { e.preventDefault(); setRvState('sending'); try { const r = await pub.post('/reviews', { ...rv, productId: p.id }); setRvState(r.message || 'Thanks!'); setRv({ name: '', rating: 5, text: '', website: '' }); } catch (er) { setRvState('error:' + er.message); } };
  const gallery = p.gallery.length ? p.gallery : null;
  return (
    <main className="ce-page">
      <Link className="ce-back" to="/">← Back to CodeEra</Link>
      <p className="ce-kicker">{(p.category_name || 'WEBSITE').toUpperCase()}{p.concept ? ' · CONCEPT DEMO' : ''}</p>
      <h1 className="ce-ph">{p.name}</h1>
      <div className="ce-gallery">{gallery ? gallery.slice(0, 3).map((u, i) => <div key={u} className={'sh sh-img' + (i === 0 ? ' big' : '')}><img src={u} alt="" /></div>) : [0, 1, 2].map((v) => <Shot key={v} p={p} variant={v} big={v === 0} />)}</div>
      <div className="ce-detail">
        <div>
          <h2>Overview</h2><p className="ce-lead">{p.full_desc || p.short_desc}</p>
          {p.features.length > 0 && <><h2>Features</h2><ul className="ce-list">{p.features.map((f) => <li key={f}>{f}</li>)}</ul></>}
          {p.pages.length > 0 && <><h2>Included pages</h2><div className="ce-tags">{p.pages.map((x) => <span key={x}>{x}</span>)}</div></>}
          {p.technologies.length > 0 && <><h2>Technologies</h2><div className="ce-tags">{p.technologies.map((x) => <span key={x}>{x}</span>)}</div></>}
          {p.customization.length > 0 && <><h2>Customization options</h2><ul className="ce-list">{p.customization.map((f) => <li key={f}>{f}</li>)}</ul></>}
          {p.included.length > 0 && <><h2>What's included after purchase</h2><ul className="ce-list">{p.included.map((f) => <li key={f}>{f}</li>)}</ul></>}
          {p.faq.length > 0 && <><h2>FAQ</h2>{p.faq.map((q) => <details key={q.q} className="ce-faq"><summary>{q.q}</summary><p>{q.a}</p></details>)}</>}
          <h2>Reviews</h2>
          {p.reviews.length === 0 ? <p className="ce-hint">No reviews yet.</p> : p.reviews.map((r, i) => <div key={i} className="ce-review"><div className="ce-rate">{'★'.repeat(r.rating)}<span style={{ opacity: .3 }}>{'★'.repeat(5 - r.rating)}</span> <b>{r.name}</b></div><p>{r.text}</p>{r.reply && <p className="ce-reply"><b>CodeEra:</b> {r.reply}</p>}</div>)}
          <form className="ce-form flat" onSubmit={submitReview} noValidate style={{ marginTop: 18 }}>
            <b>Leave a review</b>
            <label>Name<input value={rv.name} onChange={(e) => setRv({ ...rv, name: e.target.value })} /></label>
            <Stars value={rv.rating} onChange={(n) => setRv({ ...rv, rating: n })} />
            <label>Review<textarea rows={3} value={rv.text} onChange={(e) => setRv({ ...rv, text: e.target.value })} /></label>
            <input className="ce-hp" tabIndex={-1} autoComplete="off" aria-hidden="true" value={rv.website} onChange={(e) => setRv({ ...rv, website: e.target.value })} />
            {rvState.startsWith('error:') ? <p className="ce-err">{rvState.slice(6)}</p> : rvState && rvState !== 'sending' ? <p className="ce-ok">{rvState}</p> : null}
            <button className="ce-btn" type="submit" disabled={rvState === 'sending' || !rv.name.trim() || rv.text.trim().length < 5}>Submit review</button>
          </form>
        </div>
        <aside className="ce-aside">
          <div className="ce-price big">From <b>{money(price, cfg)}</b>{p.sale != null && <s>{money(p.price, cfg)}</s>}</div>
          <button type="button" className="ce-btn primary block" onClick={() => onDemo(p)}>Live Demo {p.demo_url ? '↗' : ''}</button>
          <button type="button" className="ce-btn block" disabled={p.availability !== 'available'} onClick={() => onBuy(p)}>{p.availability === 'available' ? 'Request this website' : p.availability === 'sold_out' ? 'Sold out' : 'Coming soon'}</button>
          <div className="ce-lic"><h4>Ready-made license</h4><p>You get a customized, licensed copy of this website for your own project. You do not automatically own the original core code or intellectual property.</p>
            <h4>Custom development</h4><p>Need changes or extra features? Request them as a separate, quoted piece of work.</p></div>
        </aside>
      </div>
    </main>
  );
}

function Demo() {
  const { slug } = useParams(); const nav = useNavigate(); const [p, setP] = useState(null); const [tab, setTab] = useState(0);
  useEffect(() => { pub.get('/products/' + slug).then(setP).catch(() => nav('/')); }, [slug, nav]);
  if (!p) return <div className="ce-skel" style={{ height: '100vh' }} />;
  const pages = p.pages.length ? p.pages : ['Home'];
  return (
    <div className="ce-demo">
      <div className="ce-demo-bar"><span><b>DEMO</b> Sample content only. Not a real business.</span><Link className="ce-btn sm" to={'/website/' + p.slug}>← Return to CodeEra</Link></div>
      <div className="ce-demo-nav"><b style={{ color: p.accent || undefined }}>{p.name}</b>{pages.map((x, i) => <button key={x} type="button" className={tab === i ? 'on' : ''} onClick={() => setTab(i)}>{x}</button>)}</div>
      <div className="ce-demo-stage"><Shot p={p} variant={tab % 3} big /><p>{pages[tab]} page</p></div>
    </div>
  );
}

function Home({ onBuy, onDemo, prefill }) {
  const { cfg } = useSite(); useTrack();
  const nav = (id) => scrollToId(id);
  return (<>
    <Hero onNav={nav} hp={cfg.homepage} heroImg={cfg.homepage.hero.image} />
    <Explore onBuy={onBuy} onDemo={onDemo} /><Services /><About /><Contact prefill={prefill} />
  </>);
}

function Maintenance() {
  const { cfg } = useSite();
  return <main className="ce-page" style={{ textAlign: 'center', paddingTop: 180 }}><h1 className="ce-ph">{cfg.general.siteName}</h1><p className="ce-lead" style={{ margin: '0 auto' }}>{cfg.general.maintenanceMessage}</p></main>;
}

export function Site({ children }) {
  return <Provider><SiteInner>{children}</SiteInner></Provider>;
}
function SiteInner() {
  const { cfg, error, reload, mode } = useSite(); const nav = useNavigate();
  const [order, setOrder] = useState(null); const [prefill, setPrefill] = useState('');
  useEffect(() => { document.documentElement.classList.toggle('ce-html-light', mode === 'light'); document.body.style.background = mode === 'light' ? '#f3f6fc' : (cfg?.appearance?.colors?.navy || '#020817'); }, [mode, cfg]);
  if (error) return <div className="ce-fail"><h1>CodeEra</h1><p>We could not load the site right now.</p><button className="ce-btn" onClick={reload}>Try again</button></div>;
  if (!cfg) return <div className="ce-boot" aria-busy="true"><span /></div>;
  const onDemo = (p) => { if (p.demo_url) window.open(p.demo_url, '_blank', 'noopener'); else nav('/demo/' + p.slug); };
  const onBuy = (p) => { setPrefill(''); setOrder(p); };
  if (cfg.general.maintenance) return <Shell maintenance><Maintenance /></Shell>;
  return (
    <Routes>
      <Route path="/demo/:slug" element={<div className="ce-root ce-js"><Demo /></div>} />
      <Route path="*" element={<Shell>
        <Routes>
          <Route path="/website/:slug" element={<Details onBuy={onBuy} onDemo={onDemo} />} />
          <Route path="/" element={<Home onBuy={onBuy} onDemo={onDemo} prefill={prefill} />} />
          <Route path="*" element={<main className="ce-page"><h1 className="ce-ph">Page not found</h1><Link className="ce-back" to="/">← Back to CodeEra</Link></main>} />
        </Routes>
        {order && <OrderModal p={order} onClose={() => setOrder(null)} />}
      </Shell>} />
    </Routes>
  );
}
