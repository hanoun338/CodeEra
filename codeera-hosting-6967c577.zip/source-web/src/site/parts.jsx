import React, { useEffect, useRef, useState } from 'react';
import hero from './hero.jpg';

export const EYES = [{ x: 0.4425, y: 0.243 }, { x: 0.5185, y: 0.22 }];
export const reduced = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export function scrollToId(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'start' });
}

export function Reveal({ children, className = '', delay = 0 }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!('IntersectionObserver' in window)) { el.classList.add('in'); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { el.classList.add('in'); io.disconnect(); } }), { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <div ref={ref} className={'rv ' + className} style={{ transitionDelay: delay + 'ms' }}>{children}</div>;
}

export function Particles() {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c || reduced()) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    let w = 0, h = 0, raf = 0; let mx = -999, my = -999;
    const N = window.innerWidth < 700 ? 28 : 64;
    const ps = Array.from({ length: N }, () => ({ x: Math.random(), y: Math.random(), r: Math.random() * 1.6 + 0.4, s: Math.random() * 0.00007 + 0.00002, g: Math.random() < 0.18, vx: 0, vy: 0 }));
    const size = () => { const r = c.getBoundingClientRect(); w = c.width = Math.max(1, r.width); h = c.height = Math.max(1, r.height); };
    size();
    const mv = (e) => { const r = c.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; };
    window.addEventListener('pointermove', mv); window.addEventListener('resize', size);
    const loop = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of ps) {
        p.y -= p.s * 16; if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); }
        let px = p.x * w + p.vx, py = p.y * h + p.vy;
        const dx = px - mx, dy = py - my, d = Math.hypot(dx, dy);
        if (d < 120) { p.vx += (dx / d) * 0.8; p.vy += (dy / d) * 0.8; }
        p.vx *= 0.94; p.vy *= 0.94;
        ctx.beginPath(); ctx.arc(px, py, p.r, 0, 7);
        ctx.fillStyle = p.g ? 'rgba(200,164,93,.7)' : 'rgba(40,217,255,.65)'; ctx.fill();
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('pointermove', mv); window.removeEventListener('resize', size); };
  }, []);
  return <canvas ref={ref} className="ce-particles" aria-hidden="true" />;
}

export function Hero({ onNav, hp, heroImg }) {
  const stageRef = useRef(null);
  const [awake, setAwake] = useState(reduced() ? 3 : 0);
  useEffect(() => {
    if (reduced()) return;
    const t = [setTimeout(() => setAwake(1), 500), setTimeout(() => setAwake(2), 1700), setTimeout(() => setAwake(3), 2900)];
    return () => t.forEach(clearTimeout);
  }, []);
  useEffect(() => {
    const el = stageRef.current; if (!el) return;
    let tx = -1, ty = 0.3, cx = -1, cy = 0.3, raf = 0, mx = 0, my = 0, pxv = 0, pyv = 0; const t0 = performance.now();
    const coarse = window.matchMedia('(pointer: coarse)').matches;
    const onMove = (e) => { mx = (e.clientX / window.innerWidth) * 2 - 1; my = (e.clientY / window.innerHeight) * 2 - 1; if (awake === 3 && !coarse) { tx = mx; ty = my; } };
    window.addEventListener('pointermove', onMove);
    const loop = (now) => {
      const s = el.getBoundingClientRect().width;
      if (awake < 3) { tx = -1; ty = 0.3; }
      else if (coarse || reduced()) { const k = (now - t0) / 1000; tx = Math.sin(k * 0.45) * 0.55; ty = Math.cos(k * 0.33) * 0.25; }
      cx += (tx - cx) * 0.06; cy += (ty - cy) * 0.06;
      pxv += ((reduced() ? 0 : -mx * s * 0.006) - pxv) * 0.05; pyv += ((reduced() ? 0 : -my * s * 0.004) - pyv) * 0.05;
      const r = s * 0.0042;
      el.style.setProperty('--gx', (cx * r).toFixed(2) + 'px');
      el.style.setProperty('--gy', (cy * r * 0.7).toFixed(2) + 'px');
      el.style.setProperty('--px', pxv.toFixed(2) + 'px');
      el.style.setProperty('--py', pyv.toFixed(2) + 'px');
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('pointermove', onMove); };
  }, [awake]);
  return (
    <section className="ce-hero" id="home">
      <div className={'ce-stage state-' + awake} ref={stageRef}>
        <img src={heroImg || hero} alt="A lapis pharaoh statue wired with glowing circuits" draggable={false} />
        <div className="ce-wake" />
        {!heroImg && EYES.map((e, i) => (
          <div key={i} className="ce-eye" style={{ left: e.x * 100 + '%', top: e.y * 100 + '%' }}><span className="ce-eye-glow" /><span className="ce-eye-iris" /></div>
        ))}
      </div>
      <Particles />
      <div className="ce-shade" />
      <div className="ce-copy">
        <p className="ce-label ce-in1">{hp.hero.label}</p>
        <h1 className="ce-in2">{hp.hero.headline1}<br /><em>{hp.hero.headline2}</em></h1>
        <p className="ce-sub ce-in3">{hp.hero.subtitle}</p>
        <div className="ce-cta ce-in4">
          <button type="button" className="ce-btn primary" onClick={() => onNav('explore')}>{hp.hero.primaryCta} <span aria-hidden>→</span></button>
          <button type="button" className="ce-btn" onClick={() => onNav('contact')}>{hp.hero.secondaryCta}</button>
        </div>
      </div>
      <div className="ce-foot"><span>IDEAS</span><span>TECHNOLOGY</span><span>A BRIGHTER TOMORROW</span></div>
    </section>
  );
}
